"""Trial40 independent follow and idle drift controller. Pure Python; no OS hooks.
Coordinates are physical pixels and time is monotonic seconds. Output heading is radians clockwise.
"""
import math
from collections import deque

def clampvec(x,y,limit):
    l=math.hypot(x,y)
    return (x*limit/l,y*limit/l) if l>limit else (x,y)

def angle_delta(a,b):return (a-b+math.pi)%(2*math.pi)-math.pi

class EscortGroup:
    def __init__(self,config,unit,count=3):
        if type(count) is not int or not 0<=count<=3:raise ValueError('count must be 0..3')
        self.cfg=config;self.params=config['assets'][unit][:count];self.reset()
    def reset(self):
        self.hist=deque(maxlen=256);self.last=None;self.states=[];self.heading=0.;self.v=0.;self.quiet=0.;self.idling=False;self.blend=0.;self.idle_heading=0.;self.clock=0.
    def _sample(self,t):
        a=self.hist[0]
        for b in self.hist:
            if b[0]>=t:
                f=max(0.,min(1.,(t-a[0])/(b[0]-a[0]))) if b[0]>a[0] else 0.
                return (a[1]+f*(b[1]-a[1]),a[2]+f*(b[2]-a[2]),a[3]+f*angle_delta(b[3],a[3]))
            a=b
        return a[1:]
    def _target(self,t,p,scale):
        x,y,h=self._sample(t-p['lag_s']);c,s=math.cos(h),math.sin(h)
        # Lagged leader path + independently offset station. Heading held on stop.
        back=p['back']*scale;side=p['side']*scale
        return x-back*c-side*s,y-back*s+side*c
    def _idle_target(self,xy,p,scale):
        a=self.idle_heading+p['idle_angle'];q=self.clock*2*math.pi/p['idle_period']+p['idle_phase'];c,s=math.cos(a),math.sin(a)
        radial=p['idle_radius']+p['idle_amp_x']*math.sin(q);tangent=p['idle_amp_y']*math.sin(q*.81+1.2)
        return xy[0]+scale*(radial*c-tangent*s),xy[1]+scale*(radial*s+tangent*c),a+math.pi/2+p['idle_tilt']*math.sin(q*.7)
    def _avoid(self,i,positions,center,scale):
        x,y=positions[i];ax=ay=0.;cfg=self.cfg['idle']
        for j,(ox,oy) in enumerate([*positions,center]):
            if j==i:continue
            dx,dy=x-ox,y-oy;d=math.hypot(dx,dy);r=cfg['primary_radius' if j==len(positions) else 'avoid_radius']*scale
            if d>=r:continue
            if d<1e-8:
                a=(min(i,j)+1)*2.399963;sgn=1 if i<j else -1;dx,dy=sgn*math.cos(a),sgn*math.sin(a);den=1.
            else:den=d
            f=cfg['avoid_accel']*scale*(1-d/r)**2;ax+=f*dx/den;ay+=f*dy/den
        return clampvec(ax,ay,cfg['avoid_accel']*scale)
    def update(self,t,xy,scale=1.):
        if not all(math.isfinite(z) for z in (t,*xy,scale)) or scale<=0:
            self.reset();return []
        old=self.last
        if old and (t<=old[0] or t-old[0]>self.cfg['max_gap_s'] or math.dist(xy,old[1:])>self.cfg['max_jump_px']*scale):
            self.reset();old=None
        dt=t-old[0] if old else 0.
        if old:
            dx,dy=xy[0]-old[1],xy[1]-old[2];speed=math.hypot(dx,dy)/dt
            self.v+=(speed-self.v)*(1-math.exp(-dt/.07))
            if speed>18*scale:
                h=math.atan2(dy,dx);self.heading+=angle_delta(h,self.heading)*(1-math.exp(-dt/.075))
            cfg=self.cfg['idle']
            if speed>=cfg['exit_speed']*scale or self.v>=cfg['exit_speed']*scale:
                self.quiet=0.;self.idling=False
            elif speed<=cfg['enter_speed']*scale and self.v<=cfg['enter_speed']*scale:
                self.quiet+=dt
                if not self.idling and self.quiet>=cfg['delay_s']:
                    if self.blend<.05:self.idle_heading=self.heading;self.clock=0.
                    self.idling=True
            elif not self.idling:self.quiet=0.
        self.last=(t,*xy);self.hist.append((t,*xy,self.heading))
        while len(self.hist)>2 and t-self.hist[1][0]>.5:self.hist.popleft()
        if not old:
            self.states=[[*self._target(t,p,scale),0.,0.,self.heading] for p in self.params]
        else:
            # Fixed maximum substep for stable spring integration at irregular refresh rates.
            n=max(1,math.ceil(dt/(1/120)));h=dt/n
            for j in range(n):
                ts=t-dt+(j+1)*h
                cfg=self.cfg['idle'];self.clock+=h
                self.blend+=(float(self.idling)-self.blend)*(1-math.exp(-h/(cfg['deploy_tau'] if self.idling else cfg['return_tau'])))
                center=self._sample(ts)[:2];positions=[s[:2] for s in self.states]
                for i,(p,st) in enumerate(zip(self.params,self.states)):
                    tx,ty=self._target(ts,p,scale);ix,iy,ih=self._idle_target(center,p,scale);b=self.blend;tx+=(ix-tx)*b;ty+=(iy-ty)*b
                    x,y,vx,vy,hd=st;w=p['omega']*(1-.34*b);fx,fy=self._avoid(i,positions,center,scale)
                    ax,ay=clampvec(w*w*(tx-x)-2*p['damping']*w*vx+fx,w*w*(ty-y)-2*p['damping']*w*vy+fy,self.cfg['max_acceleration_px_s2']*scale)
                    vx,vy=clampvec(vx+ax*h,vy+ay*h,self.cfg['max_speed_px_s']*scale);x+=vx*h;y+=vy*h
                    target=math.atan2(vy,vx) if math.hypot(vx,vy)>14*scale else hd
                    target+=angle_delta(ih,target)*b;hd+=angle_delta(target,hd)*(1-math.exp(-h/(p['turn_tau']*(1-b)+.42*b)))
                    st[:]=[x,y,vx,vy,hd]
        return [dict(id=i,position=(s[0],s[1]),velocity=(s[2],s[3]),speed=math.hypot(s[2],s[3]),heading=s[4],scale=p['scale']*scale,phase=p['phase'],idle_blend=self.blend) for i,(p,s) in enumerate(zip(self.params,self.states))]
