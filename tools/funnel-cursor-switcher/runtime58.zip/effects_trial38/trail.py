"""Trial38 screen-space nozzle trail. No OS hooks. Python 3.11 + Pillow.
Call update once per real motion tick with the transformed nozzle coordinate.
Draw returned cropped straight-alpha layer behind plume/body at desktop origin.
"""
import math
from collections import deque
from PIL import Image, ImageDraw, ImageFilter


def transform_anchor(anchor, pivot, world_pivot, scale=1.0, heading_rad=0.0):
    """Clockwise screen-plane orientation; same affine as body, not a 3D roll."""
    x=(anchor[0]-pivot[0])*scale; y=(anchor[1]-pivot[1])*scale
    c=math.cos(heading_rad); s=math.sin(heading_rad)
    return (world_pivot[0]+c*x-s*y, world_pivot[1]+s*x+c*y)


class Trail:
    def __init__(self, config, unit):
        self.cfg=config; self.style=config['assets'][unit]; self.reset()
    def reset(self):
        self.samples=deque(maxlen=self.cfg['max_samples']); self.prev=None; self.next_t=None; self.now=None
    def update(self, t, nozzle, speed, power):
        if not all(math.isfinite(v) for v in (t,*nozzle,speed,power)):
            self.reset(); return
        power=max(0.,min(1.,power)); active=speed>self.cfg['stop_speed_px_s'] and power>0.015
        point=(float(nozzle[0]),float(nozzle[1])); old=self.prev
        if old and (t<=old[0] or t-old[0]>self.cfg['max_input_gap_s'] or math.dist(point,old[1])>self.cfg['max_jump_px']):
            self.reset(); old=None
        self.now=t
        # Each stopped interval terminates the stroke; never bridge a gap on restart.
        if active:
            if not old or not old[3]:
                self.samples.append((t,*point,power,True)); self.next_t=t+self.cfg['sample_interval_s']
            else:
                if self.next_t is None:self.next_t=old[0]+self.cfg['sample_interval_s']
                while self.next_t<=t+1e-9:
                    f=min(1.,max(0.,(self.next_t-old[0])/(t-old[0])))
                    x=old[1][0]+(point[0]-old[1][0])*f; y=old[1][1]+(point[1]-old[1][1])*f
                    self.samples.append((self.next_t,x,y,old[2]+(power-old[2])*f,False)); self.next_t+=self.cfg['sample_interval_s']
        else:
            self.next_t=None
        self.prev=(t,point,power,active)
        while self.samples and t-self.samples[0][0]>=self.style['lifetime_s']:self.samples.popleft()
    def points(self):
        if self.now is None:return []
        pts=list(self.samples)
        # Append live endpoint for exact attachment without changing sampling cadence.
        if self.prev and self.prev[3] and pts and self.prev[0]-pts[-1][0]>1e-7:
            t,p,power,_=self.prev; pts.append((t,*p,power,False))
        return pts
    def render(self, viewport=None, scale=1.0):
        """Returns (RGBA image, (left, top)) or (None,None). Optional physical viewport bounds.
        Scale is visual size factor only; sample coordinates are already physical pixels.
        """
        pts=self.points(); st=self.style
        if len(pts)<2 or not math.isfinite(scale) or scale<=0:return None,None
        # Crop to active history, not full desktop; transparent guard margin for blur.
        pad=math.ceil(st['max_width_px']*scale*st['glow_width_factor']*2+5)
        x0=math.floor(min(p[1] for p in pts))-pad; y0=math.floor(min(p[2] for p in pts))-pad
        x1=math.ceil(max(p[1] for p in pts))+pad+1; y1=math.ceil(max(p[2] for p in pts))+pad+1
        if viewport:
            x0=max(x0,viewport[0]); y0=max(y0,viewport[1]);x1=min(x1,viewport[2]);y1=min(y1,viewport[3])
        w=x1-x0;h=y1-y0
        if w<=0 or h<=0 or w*h>self.cfg['max_render_area_px']:return None,None
        ss=2
        if w*h*ss*ss>self.cfg['max_render_area_px']:ss=1
        layers=[]
        for glow in (True,False):
            mask=Image.new('L',(w*ss,h*ss)); draw=ImageDraw.Draw(mask)
            def attrs(p):
                age=max(0.,self.now-p[0]); f=max(0.,1-age/st['lifetime_s']); power=p[3]
                width=(st['min_width_px']+(st['max_width_px']-st['min_width_px'])*power)*f**.65*scale
                if glow:width*=st['glow_width_factor']
                alpha=(st['glow_alpha'] if glow else st['core_alpha'])*power*f**st['fade_exponent']
                return (max(1,round(width*ss)),max(0,min(255,round(alpha))))
            for a,b in zip(pts,pts[1:]):
                if b[4]:continue
                wa,aa=attrs(a);wb,ab=attrs(b);wid=max(1,round((wa+wb)/2)); op=round((aa+ab)/2)
                if not op:continue
                p=(round((a[1]-x0)*ss),round((a[2]-y0)*ss));q=(round((b[1]-x0)*ss),round((b[2]-y0)*ss))
                draw.line([p,q],fill=op,width=wid)
                for (cx,cy),ww,al in [(p,wa,aa),(q,wb,ab)]:
                    r=ww/2; draw.ellipse((cx-r,cy-r,cx+r,cy+r),fill=al)
            if glow:mask=mask.filter(ImageFilter.GaussianBlur(max(.5,scale*ss*.65)))
            if ss>1:mask=mask.resize((w,h),Image.Resampling.LANCZOS)
            layer=Image.new('RGBA',(w,h),tuple(st['glow_rgb'] if glow else st['core_rgb'])+(0,));layer.putalpha(mask);layers.append(layer)
        out=Image.alpha_composite(*layers)
        return (out,(x0,y0)) if out.getchannel('A').getbbox() else (None,None)
