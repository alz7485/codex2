"""Trial52 procedural VFX, straight RGBA. Coordinates and event timing unchanged.
Screen-space light only, never changes actual mouse input or the 3D geometry.
"""
import math
from PIL import Image, ImageDraw, ImageFilter
from primary_fire import MIN_CHARGE, FIRE, AFTER, smooth
COLORS={'qubeley':((255,196,67),(255,249,222)), 'sazabi':((64,255,119),(230,255,239))}

def clamp(x):return max(0.,min(1.,x))
def render(unit,effects,viewport):
    l,t,r,b=map(int,viewport);w,h=r-l,b-t
    if w<=0 or h<=0:raise ValueError('empty viewport')
    out=Image.new('RGBA',(w,h));color,core=COLORS[unit]
    for e in effects:
        x,y=e['origin'][0]-l,e['origin'][1]-t;hd=e['heading'];dx,dy=math.cos(hd),math.sin(hd);nx,ny=-dy,dx;s=e['scale'];p=clamp(e['power']);age=max(0.,e['age']);stage=e['stage']
        if p<=0 or s<=0:continue
        # Render locally to avoid allocating monitor-sized intermediate layers per shot.
        pad=math.ceil(38*s+5); reach=160*s if stage!='charge' else 0
        ex,ey=x+dx*reach,y+dy*reach
        a=max(0,math.floor(min(x,ex)-pad));b0=max(0,math.floor(min(y,ey)-pad));c=min(w,math.ceil(max(x,ex)+pad));d0=min(h,math.ceil(max(y,ey)+pad))
        if a>=c or b0>=d0:continue
        x-=a;y-=b0;size=(c-a,d0-b0)
        glow=Image.new('RGBA',size);g=ImageDraw.Draw(glow);sharp=Image.new('RGBA',size);d=ImageDraw.Draw(sharp)
        def rgba(rgb,alpha):return (*rgb,round(255*clamp(alpha)))
        def disc(draw,xx,yy,rad,fill):
            if rad>0:draw.ellipse((xx-rad,yy-rad,xx+rad,yy+rad),fill=fill)
        def line(draw,points,width,fill):draw.line(points,fill=fill,width=max(1,round(width*s)))
        def xy(along,side=0):return (x+s*(dx*along+nx*side),y+s*(dy*along+ny*side))
        if stage=='charge':
            progress=smooth(age/MIN_CHARGE);held=max(0.,age-MIN_CHARGE);pulse=1 if age<MIN_CHARGE else 1+.08*math.sin(held*math.tau*5)
            radius=s*(1.7+4.0*progress)*pulse
            disc(g,x,y,radius*2.5,rgba(color,.55*p));disc(d,x,y,radius,rgba(color,.88*p));disc(d,x,y,radius*.47,rgba(core,.98*p))
            # One initial inward sweep, then repeat smaller converging particles while held.
            for i in range(12 if unit=='qubeley' else 10):
                if age<MIN_CHARGE:
                    f=clamp((age/MIN_CHARGE-i%3*.08)/(1-i%3*.08));strength=math.sin(math.pi*f)**.65;rr=5+23*(1-f)**1.2
                else:
                    f=(held*3.2+i/10)%1;strength=math.sin(math.pi*f)**.8;rr=6+14*(1-f)**1.4
                ang=hd+i*2.399963+(1-f)*(.9 if unit=='qubeley' else .22)
                q=(x+math.cos(ang)*rr*s,y+math.sin(ang)*rr*s);tail=(x+math.cos(ang)*(rr+2.5)*s,y+math.sin(ang)*(rr+2.5)*s)
                alpha=.85*strength*p
                line(d,[tail,q],.8,rgba(color,alpha*.7));disc(d,*q,s*(.55+.55*f),rgba(core,alpha))
        elif stage=='fire':
            # Leading tip grows rapidly, reaches full length in 40ms. Flash dies independently.
            travel=clamp(age/.04);length=12+148*(1-(1-travel)**1.5);flash=(1-clamp(age/.065))**1.5
            taper=1-.24*smooth((age-.045)/.055);end=xy(length)
            line(g,[(x,y),end],13*taper,rgba(color,.65*p));line(d,[(x,y),end],5.8*taper,rgba(color,.94*p));line(d,[(x,y),end],2.1*taper,rgba(core,p))
            disc(d,*end,s*2.1*taper,rgba(core,.92*p));disc(g,x,y,s*(5+12*flash),rgba(color,.8*p));disc(d,x,y,s*(2.8+5*flash),rgba(core,p))
            for i in range(6):
                angle=hd+i*math.tau/6+.21;rr=s*(6+13*flash);q=(x+math.cos(angle)*rr,y+math.sin(angle)*rr)
                line(d,[(x,y),q],.85,rgba(core,flash*.9*p))
            ring=s*(5+19*clamp(age/.065));g.ellipse((x-ring,y-ring,x+ring,y+ring),outline=rgba(color,.5*flash),width=max(1,round(1.6*s)))
        else:
            # Fixed beam axis; tail retracts from the muzzle toward its tip as it fades.
            f=clamp((age-FIRE)/AFTER);start=xy(160*smooth(f));end=xy(160)
            line(g,[start,end],8*p,rgba(color,.43*p));line(d,[start,end],3.9*p,rgba(color,.75*p));line(d,[start,end],1.5*p,rgba(core,.82*p));disc(d,*end,s*1.8*p,rgba(core,.7*p))
            for i in range(5):
                angle=hd+i*2.399963;rr=s*(4+14*f);disc(d,x+math.cos(angle)*rr,y+math.sin(angle)*rr,s*.7,rgba(color,.48*p*(1-f)))
        local=Image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(max(.65,2.7*s))),sharp)
        out.alpha_composite(local,(a,b0))
    return out
