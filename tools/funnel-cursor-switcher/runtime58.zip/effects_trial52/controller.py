"""Wrap the unmodified Trial50 coordinator with primary click/drag visuals."""
import sys,math
from pathlib import Path
P=Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent/'effects_trial50'));sys.path.insert(0,str(P))
from attitude import Coordinator as Base
from primary_fire import PrimaryFire
class Coordinator(Base):
    def reset(self):
        super().reset();self.primary_fire=PrimaryFire()
    def button_down(self,t):
        if self.last is None or not math.isfinite(t) or t<self.last[0] or t-self.last[0]>.15:return False
        return self.primary_fire.down(t)
    def button_up(self,t):
        if self.last is None or not math.isfinite(t) or t<self.last[0] or t-self.last[0]>.15:return False
        return self.primary_fire.up(t)
    def cancel_fire(self):self.primary_fire.cancel()
    def update(self,t,xy,scale=1.,visible=True,viewport=None):
        result=super().update(t,xy,scale,visible,viewport)
        primary=next((b for b in result['items'] if b['id']==-1),None)
        out=dict(result);out['primary_effects']=self.primary_fire.sample(t,primary) if primary else []
        return out
