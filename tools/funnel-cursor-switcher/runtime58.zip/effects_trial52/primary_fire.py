"""Trial52 primary-only visual state machine; no hooks, no mouse event consumption.
Times are monotonic seconds, coordinates physical pixels. One down/up = one shot.
"""
import math
from collections import deque

MIN_CHARGE=.12
FIRE=.10
AFTER=.16
MAX_PENDING=8

def smooth(x):
    x=max(0.,min(1.,x));return x*x*(3-2*x)

class PrimaryFire:
    def __init__(self):self.reset()
    def reset(self):
        self.held=None;self.shots=deque();self.last_event=-math.inf;self.serial=0
    def _valid(self,t):return math.isfinite(t) and t>=self.last_event
    def down(self,t):
        if not self._valid(t) or self.held is not None or len(self.shots)>=MAX_PENDING:return False
        self.last_event=t;self.serial+=1;self.held={'id':self.serial,'down':t,'release':None,'fire_at':None,'origin':None};return True
    def up(self,t):
        if not self._valid(t) or self.held is None:return False
        self.last_event=t;s=self.held;self.held=None;s['release']=t;s['fire_at']=max(t,s['down']+MIN_CHARGE);self.shots.append(s);return True
    def cancel(self):
        # Cancel all pending visuals on lost capture, visibility or discontinuity.
        self.reset()
    def sample(self,t,primary):
        if not math.isfinite(t):self.cancel();return []
        self.shots=deque(s for s in self.shots if t<s['fire_at']+FIRE+AFTER)
        out=[]
        for s in [*self.shots,*([self.held] if self.held is not None else [])]:
            if t<s['down']:continue
            age=t-s['down'];when=s['fire_at'];stage='charge' if when is None or t<when else 'fire' if t<when+FIRE else 'afterglow'
            if stage=='charge':
                # Continue charging even if a short click has already released.
                power=.12+.88*smooth(age/MIN_CHARGE);origin=tuple(primary['muzzle']);heading=primary['beam_heading'];scale=primary['scale'];phase=age
            else:
                if s['origin'] is None:s['origin']=(tuple(primary['muzzle']),primary['beam_heading'],primary['scale'])
                origin,heading,scale=s['origin'];phase=t-when
                power=1. if stage=='fire' else 1-smooth((phase-FIRE)/AFTER)
            out.append(dict(id=s['id'],stage=stage,power=power,age=phase,origin=origin,heading=heading,scale=scale,owner=-1))
        return out
