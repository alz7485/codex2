"""RGBA assets compositing. Both body and VFX use the same sampled 3D attitude."""
import json
from pathlib import Path
from PIL import Image
import numpy as np
from jets import overlay
R=Path(__file__).resolve().parents[1]
M=json.loads((R/'effects_trial50/manifest.json').read_text(encoding="utf-8"));cache={}
def cell(path,idx):
    if path not in cache:cache[path]=Image.open(R/path).convert('RGBA')
    return cache[path].crop((144*idx,0,144*(idx+1),144))
def mix(a,b,t):
    a=np.array(a,dtype=np.float32)/255;b=np.array(b,dtype=np.float32)/255
    alpha=a[:,:,3:4]*(1-t)+b[:,:,3:4]*t
    rgb=(a[:,:,:3]*a[:,:,3:4]*(1-t)+b[:,:,:3]*b[:,:,3:4]*t)/np.maximum(alpha,1e-8)
    out=np.rint(np.concatenate((rgb,alpha),axis=2)*255).clip(0,255).astype('uint8');out[out[:,:,3]==0]=0
    return Image.fromarray(out)
def composite(unit,power,phase,pose,control_jets=None):
    a=M['assets'][unit];p=max(0,min(1,power))*8;k=min(7,int(p));f=p-k
    layers=[mix(cell(a['levels'][k][phase][key],pose),cell(a['levels'][k+1][phase][key],pose),f) for key in ('back','tint')]
    if control_jets is not None:layers[0]=Image.alpha_composite(layers[0],overlay(unit,a["muzzle_anchor_px"][pose],a["rear_anchor_px"][pose],control_jets,phase))
    return Image.alpha_composite(Image.alpha_composite(layers[0],cell(a['body'],pose)),layers[1])
