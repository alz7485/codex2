"""Visual-only maneuvering exhaust; no shooting, no input hooks.
Auxiliary outlets are estimated from the projected hull, not new 3D geometry.
"""
import math
from PIL import Image,ImageDraw,ImageFilter

def clamp(x,a=0.,b=1.):return max(a,min(b,x))
class ControlJets:
    def __init__(self,unit,i):
        self.unit=unit;self.i=i;self.prev=None;self.acc=(0.,0.);self.brake=0.;self.left=0.;self.right=0.
    def step(self,dt,velocity,heading,scale,idle,turn):
        if dt<=0 or self.prev is None:
            self.prev=velocity;return {'brake':0.,'left':0.,'right':0.}
        f=1-math.exp(-dt/.085)
        self.acc=tuple(a+(clamp((v-p)/dt/scale,-9000,9000)-a)*f for a,v,p in zip(self.acc,velocity,self.prev));self.prev=velocity
        c,s=math.cos(heading),math.sin(heading);ax,ay=self.acc
        along=ax*c+ay*s;side=-ax*s+ay*c
        # Opposing acceleration: forward exhaust brakes, lateral exhaust steers.
        strength=[.86,1.,.92][self.i]
        goals=(clamp((-along-180)/2100),clamp((side-100)/1750+max(0,turn)*.10),clamp((-side-100)/1750+max(0,-turn)*.10))
        for name,goal in zip(('brake','left','right'),goals):
            old=getattr(self,name);goal*=strength*(1-.53*idle);tau=.045 if goal>old else .15
            setattr(self,name,old+(goal-old)*(1-math.exp(-dt/tau)))
        return {k:getattr(self,k) for k in ('brake','left','right')}

def overlay(unit,front,rear,state,phase=0):
    """144x144 RGBA layer; local projected side outlets, same affine as body."""
    im=Image.new('RGBA',(144,144));mask=Image.new('L',(288,288));core=Image.new('L',(288,288));d=ImageDraw.Draw(mask);e=ImageDraw.Draw(core)
    dx,dy=front[0]-rear[0],front[1]-rear[1];n=math.hypot(dx,dy);ux,uy=dx/n,dy/n;vx,vy=-uy,ux
    # Place the jets around the mid-aft projected hull, not at the weapon muzzle.
    x=rear[0]+dx*.33;y=rear[1]+dy*.33;off=10 if unit=='qubeley' else 12
    def jet(side,fx,fy,p,forward=False):
        if p<.015:return
        ox=x+side*vx*off;oy=y+side*vy*off
        l=(5+12*p)*(.92+.07*math.sin(phase*math.pi/2+side));w=1.3+2.7*p
        norm=math.hypot(fx,fy);fx/=norm;fy/=norm;nx,ny=-fy,fx
        def poly(width,length):return [(round(2*a),round(2*b)) for a,b in [(ox+nx*width,oy+ny*width),(ox-nx*width,oy-ny*width),(ox+fx*length,oy+fy*length)]]
        d.polygon(poly(w,l),fill=round(170*p));e.polygon(poly(w*.43,l*.75),fill=round(245*p))
    jet(-1,-vx-.22*ux,-vy-.22*uy,state['left']);jet(1,vx-.22*ux,vy-.22*uy,state['right'])
    for side in (-1,1):jet(side,ux+side*.65*vx,uy+side*.65*vy,state['brake'])
    colors=((40,160,255),(218,249,255)) if unit=='qubeley' else ((255,145,26),(255,247,193))
    for m,color in [(mask.filter(ImageFilter.GaussianBlur(2.3)),colors[0]),(core,colors[1])]:
        layer=Image.new('RGBA',(144,144),color+(0,));layer.putalpha(m.resize((144,144),Image.Resampling.LANCZOS));im=Image.alpha_composite(im,layer)
    return im
