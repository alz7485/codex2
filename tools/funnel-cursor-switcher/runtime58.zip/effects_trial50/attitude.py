"""Trial43 visual-only controller. True sampled 3D roll/pitch; no OS input hooks."""
import math,sys,json,copy
from pathlib import Path
from PIL import Image
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(Path(__file__).resolve().parent))
from jets import ControlJets
from coordinator import Coordinator as Base, EscortGroup, Trail, transform_anchor, load

def delta(a,b):return (a-b+math.pi)%(2*math.pi)-math.pi

def clamp(v,a,b):return max(a,min(b,v))

class FootprintGroup(EscortGroup):
    """Soft avoidance using measured silhouette bounds, not physical collision."""
    def __init__(self,c,u,n,extents):self.extents=extents;super().__init__(c,u,n)
    def _avoid(self,i,positions,center,scale):
        # Base soft separation plus projected extent of visible hull along the separation axis.
        ax,ay=super()._avoid(i,positions,center,scale);x,y=positions[i]
        cfg=self.cfg['idle'];a,b=self.extents
        for j,(ox,oy) in enumerate([*positions,center]):
            if j==i:continue
            dx,dy=x-ox,y-oy;d=math.hypot(dx,dy)
            if d<1e-6:continue
            bearing=math.atan2(dy,dx)
            def support(h,sc):
                theta=bearing-h
                return sc*(abs(math.cos(theta))*a+abs(math.sin(theta))*b)
            s1=support(self.states[i][4],self.params[i]['scale']*scale)
            s2=support(self.states[j][4],self.params[j]['scale']*scale) if j<len(positions) else support(self.heading,scale)
            limit=s1+s2+12*scale
            if d<limit:
                force=3200*scale*(1-d/limit);ax+=force*dx/d;ay+=force*dy/d
        mag=math.hypot(ax,ay);cap=cfg['avoid_accel']*scale*1.8
        return (ax*cap/mag,ay*cap/mag) if mag>cap else (ax,ay)

class AutonomousGroup(FootprintGroup):
    """Independent bounded lane changes, with no click-driven behavior."""
    def __init__(self,c,u,n,extents):
        self.unit=u
        super().__init__(c,u,n,extents)
    def _target(self,t,p,scale):
        x,y,h=self._sample(t-p['lag_s']);c,s=math.cos(h),math.sin(h)
        i=self.params.index(p)
        # Smoothly expand the formation at speed; stagger temporary relative advances.
        v=clamp(self.v/scale,0,1200)
        gate=v*v/(v*v+125**2)
        phase=t*math.tau/(3.6+i*.71)+p['phase']
        amp=(1.0 if self.unit=='qubeley' else .78)
        surge=math.sin(phase)*(.5+.5*math.sin(phase*.47+1.3*i))
        back=max(25,p['back']+gate*(v*.035-amp*(42+9*i)*surge))
        side=p['side']+gate*amp*((12+4*i)*math.sin(phase*.77+1.1*i))
        return x-scale*(back*c+side*s),y+scale*(-back*s+side*c)
    def _idle_target(self,xy,p,scale):
        x,y,h=super()._idle_target(xy,p,scale)
        i=self.params.index(p);q=self.clock*math.tau/(3.9+.63*i)+p['idle_phase']
        # Second, non-synchronous slow drift component.
        return x+scale*(2+i)*math.sin(q*.73),y+scale*(3+i)*math.cos(q*.91),h+.055*math.sin(q)

class SpatialGroup(AutonomousGroup):
    """Screen-space perspective and staggered, bounded idle excursions."""
    def _target(self,t,p,scale):
        x,y=super()._target(t,p,scale)
        i=self.params.index(p);h=self.heading
        phase=self.clock*math.tau/(5.8+1.4*i)+p['phase']
        gate=self.v**2/(self.v**2+(100*scale)**2)
        side=scale*gate*(8+4*i)*math.sin(phase)
        return x-side*math.sin(h),y+side*math.cos(h)
    def _idle_target(self,xy,p,scale):
        x,y,h=super()._idle_target(xy,p,scale)
        i=self.params.index(p)
        # Only after several seconds of stillness; one bounded excursion at a time.
        period=15.;local=(self.quiet-4.5-i*4.8)%period
        excursion=math.sin(math.pi*local/3.4)**2 if self.quiet>=4.5+i*4.8 and local<3.4 else 0.
        a=self.idle_heading+p['idle_angle'];side=excursion*(24+5*i)*(1 if i%2==0 else -1)
        radial=excursion*(9+3*i)
        x+=scale*(radial*math.cos(a)-side*math.sin(a));y+=scale*(radial*math.sin(a)+side*math.cos(a))
        return x,y,h+excursion*(.48+.12*i)*(1 if i%2==0 else -1)
    def _avoid(self,i,positions,center,scale):
        ax,ay=super()._avoid(i,positions,center,scale)
        x,y=positions[i];vx,vy=self.states[i][2:4]
        # Anticipate close approaches using relative velocities; no teleporting.
        for j,(ox,oy) in enumerate([*positions,center]):
            if i==j:continue
            ovx,ovy=self.states[j][2:4] if j<len(positions) else (self.v*math.cos(self.heading),self.v*math.sin(self.heading))
            dx,dy=x-ox,y-oy;rx,ry=vx-ovx,vy-ovy
            dot=dx*rx+dy*ry
            if dot>=0:continue
            tau=clamp(-dot/max(1,rx*rx+ry*ry),0,.18)
            px,py=dx+tau*rx,dy+tau*ry;dist=math.hypot(px,py)
            limit=(60 if j<len(positions) else 74)*scale
            if dist>=limit:continue
            # Steer away along predicted separation; stable side choice at exact crossing.
            if dist<.01:
                px,py=-ry,rx;dist=max(.01,math.hypot(px,py))
                gap=1.
            else:gap=1-dist/limit
            force=1750*scale*gap*min(1,tau/.035)
            ax+=force*px/dist;ay+=force*py/dist
        mag=math.hypot(ax,ay);cap=self.cfg['idle']['avoid_accel']*scale*2.0
        return (ax*cap/mag,ay*cap/mag) if mag>cap else (ax,ay)

class ExchangeGroup(SpatialGroup):
    """Two escorts exchange stations using separate radial lanes; remaining escort floats."""
    def reset(self):
        super().reset();self.exchange_clock=0.;self.exchange_tick=None
    def _idle_target(self,xy,p,scale):
        x,y,h=AutonomousGroup._idle_target(self,xy,p,scale)
        n=len(self.params);i=self.params.index(p)
        if self.exchange_tick is not None and self.idling and self.quiet>=5.:
            self.exchange_clock+=max(0.,min(.02,self.clock-self.exchange_tick))
        self.exchange_tick=self.clock
        if n<2:return x,y,h
        pairs=[(0,1),(1,2),(0,2)] if n==3 else [(0,1)]
        cycle=8.2;duration=5.2;step=int(self.exchange_clock/cycle);local=self.exchange_clock%cycle
        slots=list(range(n))
        # A full sequence repeats after two repetitions (3 escorts) or two swaps (2 escorts).
        for k in range(step%(2*len(pairs))):
            a,b=pairs[k%len(pairs)];slots[a],slots[b]=slots[b],slots[a]
        a,b=pairs[step%len(pairs)];angles=[q['idle_angle'] for q in self.params]
        base=angles[slots[i]];offset=0.
        if i in (a,b):
            other=b if i==a else a;f=clamp(local/duration,0,1);ease=f*f*f*(10+f*(-15+6*f));base+=delta(angles[slots[other]],base)*ease
            offset=(1 if i==a else -1)*23*math.sin(math.pi*f)**2
        angle=delta(base,p['idle_angle']);dx,dy=x-xy[0],y-xy[1];c,s=math.cos(angle),math.sin(angle)
        rx,ry=dx*c-dy*s,dx*s+dy*c;rad=max(1.,math.hypot(rx,ry));fac=1+scale*offset/rad
        return xy[0]+rx*fac,xy[1]+ry*fac,h+angle

class EdgeGroup(ExchangeGroup):
    """Continuous wall-aware targets and anticipated separation; no cursor clamp."""
    viewport=None
    def _limits(self,p,scale):
        if self.viewport is None:return None
        l,t,r,b=self.viewport
        # Conservative circular hull envelope independent of heading.
        m=(math.hypot(*self.extents)*p['scale']+6)*scale
        mx=min(m,(r-l)*.49);my=min(m,(b-t)*.49)
        return l+mx,t+my,r-mx,b-my
    def _fit(self,x,y,p,scale):
        limits=self._limits(p,scale)
        if limits is None:return x,y
        l,t,r,b=limits
        # Reflect out-of-bounds stations inward instead of collapsing them onto a wall.
        # Smooth the cusp around the wall (sqrt approximation) and preserve lane offsets.
        def soft(v,lo,hi):
            span=hi-lo
            if span<=0:return (lo+hi)/2
            z=(v-lo)%(2*span);z=span-abs(z-span)
            w=min(8*scale,span*.2)
            if z<w:return w*.5+z*z/(2*w)
            if z>span-w:return span-w*.5-(span-z)**2/(2*w)
            return z
        return l+soft(x,l,r),t+soft(y,t,b)
    def _target(self,t,p,scale):
        return self._fit(*super()._target(t,p,scale),p,scale)
    def _idle_target(self,xy,p,scale):
        x,y,h=super()._idle_target(xy,p,scale)
        x,y=self._fit(x,y,p,scale);return x,y,h
    def _avoid(self,i,positions,center,scale):
        ax,ay=super()._avoid(i,positions,center,scale)
        x,y=positions[i];vx,vy=self.states[i][2:4];p=self.params[i]
        # Smooth side-stepping before a projected encounter, rather than only radial repulsion.
        for j,(ox,oy) in enumerate([*positions,center]):
            if i==j:continue
            ovx,ovy=self.states[j][2:4] if j<len(positions) else (self.v*math.cos(self.heading),self.v*math.sin(self.heading))
            dx,dy=x-ox,y-oy;rx,ry=vx-ovx,vy-ovy;dot=dx*rx+dy*ry
            if dot>=0:continue
            tau=clamp(-dot/max(1,rx*rx+ry*ry),0,.24)
            px,py=dx+tau*rx,dy+tau*ry;dist=math.hypot(px,py)
            limit=(52 if j<len(positions) else 66)*scale
            if dist>=limit:continue
            n=math.hypot(rx,ry)
            if n<1e-6:continue
            nx,ny=-ry/n,rx/n
            if px*nx+py*ny<0:nx,ny=-nx,-ny
            f=1250*scale*(1-dist/limit)*min(1,tau/.045)
            ax+=f*nx;ay+=f*ny
        lim=self._limits(p,scale)
        if lim:
            # Maintain spacing even when mirrored targets occupy the same corner.
            for j,(ox,oy) in enumerate([*positions,center]):
                if j==i:continue
                dx,dy=x-ox,y-oy;d=math.hypot(dx,dy);radius=(66 if j<len(positions) else 78)*scale
                if 1e-6<d<radius:
                    force=6500*scale*(1-d/radius)**1.4;ax+=force*dx/d;ay+=force*dy/d

            l,t,r,b=lim
            # Inward acceleration anticipates overshoot, without snapping the sprite.
            px=x+vx*.14;py=y+vy*.14
            ax+=clamp((clamp(px,l,r)-px)*95,-2400*scale,2400*scale)
            ay+=clamp((clamp(py,t,b)-py)*95,-2400*scale,2400*scale)
        cap=self.cfg['idle']['avoid_accel']*scale*2.5;mag=math.hypot(ax,ay)
        return (ax*cap/mag,ay*cap/mag) if mag>cap else (ax,ay)

class Coordinator(Base):
    def __init__(self,unit,count=3,enhanced=True):
        self.viewport=None;self.att=load('effects_trial50/manifest.json')['assets'][unit];self.attitude_enabled=enhanced
        im=Image.open(R/self.att['body']).convert('RGBA');bounds=[im.crop((i*144,0,(i+1)*144,144)).getchannel('A').point(lambda x:255 if x>=32 else 0).getbbox() for i in range(15)]
        self.extents=(max(max(72-r[0],r[2]-72) for r in bounds),max(max(72-r[1],r[3]-72) for r in bounds))
        super().__init__(unit,count,enhanced=True)
    def reset(self):
        super().reset();self._legacy_trails=self.trails;self.att_states={};self.pulses={};self.jets={};self.escort_power={};self.att_trails=[];self.depth_states={}
        for i in range(self.count):
            cfg=copy.deepcopy(self.c);style=cfg["assets"][self.unit];style["lifetime_s"]*=[.86,1.05,1.18][i];style["core_alpha"]=round(style["core_alpha"]*[.90,1.,.82][i]);style["glow_alpha"]=round(style["glow_alpha"]*[.90,1.,.82][i]);self.att_trails.append(Trail(cfg,self.unit))
        if self.attitude_enabled:
            for p,v in zip(self.e['assets'][self.unit],self.cfg['size_balance']['measurements'][self.unit]['base_scale']):p['scale']=v
            self.group=EdgeGroup(self.e,self.unit,self.count,tuple(v*1.16 for v in self.extents));self.group.viewport=self.viewport
    def _clear_escorts(self):
        super()._clear_escorts();self.att_states.clear();self.pulses.clear();self.jets.clear();self.escort_power.clear();self.depth_states.clear()
        for tr in [*self.att_trails,*self._legacy_trails[1:]]:tr.reset()
    def update(self,t,xy,scale=1.,visible=True,viewport=None):
        # Half-open physical-pixel bounds of active monitor. Omit to preserve unrestricted mode.
        if viewport is not None:
            if len(viewport)!=4 or not all(map(math.isfinite,viewport)) or viewport[0]>=viewport[2] or viewport[1]>=viewport[3]:raise ValueError('invalid viewport')
            viewport=tuple(viewport)
        self.viewport=viewport
        if self.attitude_enabled:self.group.viewport=viewport
        old=self.last
        # Keep inherited calculation and new projected trail histories separate.
        if self.attitude_enabled and hasattr(self,"_legacy_trails"):self.trails=self._legacy_trails
        result=super().update(t,xy,scale,visible)
        self._legacy_trails=self.trails
        if self.attitude_enabled:self.trails=[self._legacy_trails[0],*self.att_trails]
        if not self.attitude_enabled or not result['items'] or (old and t==old[0]):return result
        dt=0 if result['reset'] or old is None else t-old[0]
        for k,b in enumerate(result['items'][1:],1):
            i=b['id'];hd=b['heading'];speed=b['speed'];idle=b.get('idle_blend',0.);s=self.att_states.get(i,(hd,speed,0.,0.,7))
            prevh,prevs,roll,pitch,idx=s
            turn=delta(hd,prevh)/dt if dt>0 else 0;acc=(speed-prevs)/dt/scale if dt>0 else 0
            q=self.group.clock*math.tau/(2.65+i*.61)+b['phase']
            q+=.34*math.sin(self.group.clock*math.tau/(8.7+1.9*i)+i*1.7)
            rollgoal=(1-idle)*clamp(turn*[11,17,13][i],-32,32)+idle*[19,25,16][i]*math.sin(q)
            pitchgoal=(1-idle)*clamp(acc*[.010,.015,.012][i],-18,18)+idle*[11,8,15][i]*math.sin(q*.71+1.4+i*.6)
            f=1-math.exp(-dt/((.10 if self.unit=='sazabi' else .17)+.035*i)) if dt>0 else 0
            oldroll,oldpitch=roll,pitch
            roll+=(rollgoal-roll)*f;pitch+=(pitchgoal-pitch)*f
            # Hysteresis prevents flicker at cell boundaries.
            ri,pi=divmod(idx,3)
            def select(value,i,step,center):
                if i<2*center and value>(i-center)*step+step*.58:return i+1
                if i>0 and value<(i-center)*step-step*.58:return i-1
                return i
            ri=select(roll,ri,16,2);pi=select(pitch,pi,18,1);idx=ri*3+pi
            self.att_states[i]=(hd,speed,roll,pitch,idx)
            front=self.att['muzzle_anchor_px'][idx];rear=self.att['rear_anchor_px'][idx]
            correction=math.atan2(front[1]-rear[1],front[0]-rear[0]);draw=hd
            world=b['draw_position'];wave=math.sin(self.group.clock*math.tau/(5.8+1.4*i)+[.3,2.6,4.5][i]);distance=math.dist(world,xy)/scale
            proximity=1-2*clamp((distance-55)/90,0,1);goal=.65*wave+.35*proximity
            lastz=self.depth_states.get(i,goal);depth_z=lastz+(goal-lastz)*(1-math.exp(-dt/.24)) if dt>0 else goal;self.depth_states[i]=depth_z
            depth=1+.16*depth_z;sc=b['scale']*depth;b['scale']=sc;b['depth_factor']=depth;b['depth_z']=depth_z
            control=self.jets.setdefault(i,ControlJets(self.unit,i));b['control_jets']=control.step(dt,b['velocity'],hd,scale,idle,turn)
            # Tiny auxiliary pulse follows actual filtered attitude velocity during hover.
            if dt>0:
                bank_rate=(roll-oldroll)/dt;pitch_rate=(pitch-oldpitch)/dt
                micro=idle*min(.13,abs(bank_rate)*.004+abs(pitch_rate)*.002)
                side='left' if bank_rate>=0 else 'right'
                b['control_jets'][side]=max(b['control_jets'][side],micro)
            nozzle=transform_anchor(rear,(72,72),world,sc,draw);muzzle=transform_anchor(front,(72,72),world,sc,draw)
            # Short, smoothly filtered orientation-control pulse, using the same nozzle anchor.
            pulse_goal=min(.28,abs(turn)*.025+max(0,acc)*.000045)*(1-.75*idle)
            prior=self.pulses.get(i,0.)
            pulse=prior+(pulse_goal-prior)*(1-math.exp(-dt/(.075 if pulse_goal>prior else .19))) if dt>0 else 0.
            self.pulses[i]=pulse
            # Match the main exhaust to forward acceleration, not to braking.
            ax,ay=control.acc;forward=ax*math.cos(hd)+ay*math.sin(hd)
            cruise=.68*min(1.,speed/(1250*scale))
            boost=.42*clamp((forward-100)/2200,0,1)
            brake=b['control_jets']['brake']
            goal=clamp((cruise+boost+pulse*.35)*(1-.8*brake)*(1-.65*idle),0,1)
            oldpower=self.escort_power.get(i,0.)
            tau=.055 if goal>oldpower else .10
            b['power']=oldpower+(goal-oldpower)*(1-math.exp(-dt/tau)) if dt>0 else 0.
            if b['power']<.012 and goal<.012:b['power']=0.
            self.escort_power[i]=b['power']
            self.att_trails[k-1].update(t,nozzle,speed,b["power"]*b["opacity"])
            b.update(attitude_index=idx,roll_deg=roll,pitch_deg=pitch,draw_heading=draw,nozzle=nozzle,muzzle=muzzle,beam_heading=draw+correction)
        result['draw_order']=[b['id'] for b in sorted(result['items'],key=lambda b:(b.get('depth_z',0.),b['id']))]
        return result
