"""Trial42 visual-only reference coordinator. No OS hooks or event generation.
Coordinates: physical pixels; time: monotonic seconds; angles: clockwise radians.
"""
import bisect, copy, json, math, sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for p in ('effects_trial38','effects_trial40'):
    sys.path.insert(0,str(R/p))
from trail import Trail,transform_anchor
from escort import EscortGroup

def load(name):return json.loads((R/name).read_text(encoding='utf-8'))

class Throttle:
    def __init__(self,c):self.c=c;self.v=0.;self.p=0.;self.imp=0.;self.timer=0.;self.active=False;self.heading=None
    def step(self,speed,dt,heading):
        if dt<=0:return self.p
        c=self.c;old=self.v;self.v+=(speed-self.v)*(1-math.exp(-dt/(c['speed_filter_tau_ms']/1000)))
        accel=(self.v-old)/dt;active=speed>c['stop_speed_px_s'];self.timer=max(0,self.timer-dt)
        if not active:self.timer=0;self.imp=0
        elif not self.active:self.imp=c['launch_floor'];self.timer=c['launch_ms']/1000
        elif accel>c['acceleration_threshold_px_s2']:self.imp=1.;self.timer=c['boost_ms']/1000
        elif self.heading is not None and speed>c['turn_min_speed_px_s'] and abs((heading-self.heading+180)%360-180)>c['turn_threshold_deg']:self.imp=c['turn_impulse_power'];self.timer=c['boost_ms']/1000
        self.active=active
        if active:self.heading=heading
        goal=max(c['cruise_max_power']*min(1,self.v/c['speed_for_full_cruise']),self.imp if self.timer>0 else 0) if active else 0
        tau=c['power_rise_tau_ms'] if goal>self.p else c['power_fall_tau_ms'];self.p+=(goal-self.p)*(1-math.exp(-dt/(tau/1000)))
        if not active and self.p<c['zero_power_cutoff']:self.p=0.
        return self.p

class Coordinator:
    def __init__(self,unit,count=3,enhanced=True):
        self.unit=unit;self.count=count;self.m=load('effects_trial37/manifest.json');self.c=load('effects_trial38/manifest.json');self.e=load('effects_trial40/manifest.json');self.f=load('effects_trial50/anchors.json');self.fleet=load('effects_trial36/manifest.json')['assets'][unit];self.cfg=load('effects_trial50/integration.json')
        if enhanced:self.e['idle'].update(self.cfg['avoidance'])
        self.ends=[];s=0
        for ms in self.fleet['timing_ms']:s+=ms/1000;self.ends.append(s)
        self.reset()
    def reset(self):
        self.group=EscortGroup(self.e,self.unit,self.count);self.thr=[Throttle(self.m['speed_mapping']) for _ in range(self.count+1)];self.trails=[Trail(self.c,self.unit) for _ in self.thr];self.last=None;self.heading=0.;self.special=None;self.reappear=None
    def _clear_escorts(self):
        self.group.reset()
        for k in range(1,len(self.thr)):
            self.thr[k]=Throttle(self.m['speed_mapping']);self.trails[k].reset()
    def trigger_fire(self,t,heading):
        # Compatibility only: ordinary escorts never aim, fire or recoil.
        return False
    def trigger_special(self,t,anchor):
        if self.last is None or not all(map(math.isfinite,(t,*anchor))) or t<self.last[0] or t-self.last[0]>.15:return False
        self._clear_escorts();self.trails[0].reset();self.special=(t,tuple(anchor));self.reappear=None;return True
    def update(self,t,xy,scale=1.,visible=True):
        if not visible or not all(map(math.isfinite,(t,*xy,scale))) or scale<=0:
            self.reset();return {'items':[],'fleet':None,'reset':True}
        old=self.last;reset=old is None
        if old and (t<old[0] or t-old[0]>self.e['max_gap_s'] or math.dist(xy,old[1])>self.e['max_jump_px']*scale or scale!=old[2]):
            self.reset();old=None;reset=True
        if old and t==old[0]:return self.previous
        dt=t-old[0] if old else 0.;speed=math.dist(xy,old[1])/dt if dt else 0.
        if speed>18*scale:self.heading=math.atan2(xy[1]-old[1][1],xy[0]-old[1][0])
        self.last=(t,tuple(xy),scale);fleet=None
        if self.special is not None:
            start,anchor=self.special;idx=bisect.bisect_right(self.ends,max(0,t-start))
            if idx<len(self.ends):fleet=dict(index=idx,anchor=anchor)
            else:self.special=None;self._clear_escorts();self.reappear=t
        a=[dict(id=-1,position=tuple(xy),speed=speed,heading=self.heading,scale=scale,phase=0)]
        if fleet is None:a+=self.group.update(t,xy,scale)
        out=[]
        for k,b in enumerate(a):
            b=dict(b);fade=1. if k==0 or self.reappear is None else min(1,max(0,(t-self.reappear)/self.cfg['return_fade_s']));fade=fade*fade*(3-2*fade)
            if k==0:fade=1.
            phase=int(t/.065+b['phase'])%4;pose=int(t/.09+b['phase'])%4 if b['speed']>18 else 0
            front=self.f['assets'][self.unit]['muzzle_anchor_px'][pose];rear=self.m['assets'][self.unit]['rear_anchor_px'][pose]
            correction=math.atan2(front[1]-rear[1],front[0]-rear[0]);hd=b['heading'];world=b['position'];sc=b['scale']
            power=self.thr[k].step(b['speed'],dt,math.degrees(b['heading']));nozzle=transform_anchor(rear,(72,72),world,sc,hd);muzzle=transform_anchor(front,(72,72),world,sc,hd)
            self.trails[k].update(t,nozzle,b['speed'],power*fade)
            b.update(draw_heading=hd,draw_position=world,phase_index=phase,pose_index=pose,power=power,opacity=fade,nozzle=nozzle,muzzle=muzzle,beam_heading=hd+correction)
            out.append(b)
        self.previous=dict(items=out,fleet=fleet,reset=reset);return self.previous
