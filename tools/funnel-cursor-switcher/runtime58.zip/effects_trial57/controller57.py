"""Trial57 special lifecycle and wall-aware escort formation. Visual only."""
import copy,math,sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'effects_trial56'))
from controller56 import Coordinator as Base,FIXED_HEADING
from attitude import EdgeGroup,clamp,delta,transform_anchor

class WallGroup(EdgeGroup):
    """Blend mirrored targets into distinct inward stations near walls."""
    def _fit(self,x,y,p,scale):
        x,y=super()._fit(x,y,p,scale)
        if not self.viewport or not self.hist:return x,y
        l,t,r,b=self.viewport;_,cx,cy,_=self.hist[-1]
        width=125*scale
        def weight(d):return clamp(1-d/width,0.,1.)**2
        a,bw,c,d=weight(cx-l),weight(r-cx),weight(cy-t),weight(b-cy)
        gx,gy=a-bw,c-d;strength=clamp(max(a,bw,c,d)*1.3,0,1)
        if math.hypot(gx,gy)<.02:return x,y
        i=self.params.index(p);n=len(self.params)
        angle=math.atan2(gy,gx)+(i-(n-1)/2)*.93
        rad=(105+10*(i%2))*scale
        tx,ty=cx+rad*math.cos(angle),cy+rad*math.sin(angle)
        ll,tt,rr,bb=self._limits(p,scale)
        tx,ty=clamp(tx,ll,rr),clamp(ty,tt,bb)
        return x+(tx-x)*strength,y+(ty-y)*strength

class Coordinator(Base):
    def reset(self):
        super().reset();self._departure=None;self._last_output=None;self._last_tick=None
        self.cfg['return_fade_s']=.55
        if self.attitude_enabled:
            self.group=WallGroup(self.e,self.unit,self.count,tuple(v*1.16 for v in self.extents));self.group.viewport=self.viewport
    def trigger_special(self,t,anchor):
        if self.special is not None:return False
        old=self._last_output
        if not super().trigger_special(t,anchor):return False
        self.cancel_fire()
        # Outgoing hulls only: no trail, no thrust; keep their last pose and fade in place.
        self._departure=(t,[copy.deepcopy(b) for b in (old or {}).get('items',[]) if b['id']>=0 and b['opacity']>0])
        self._last_tick=None
        return True
    def _valid_event(self,t):
        return self.special is None and super()._valid_event(t)
    def update(self,t,xy,scale=1.,visible=True,viewport=None):
        # Repeated drawing of the same sample must not advance effect state.
        key=(t,tuple(xy),scale,visible,tuple(viewport) if viewport is not None else None)
        if key==self._last_tick and self._last_output is not None:return copy.deepcopy(self._last_output)
        result=super().update(t,xy,scale,visible,viewport)
        result=dict(result);result['departing_escorts']=[]
        # A trigger can arrive at the exact timestamp of the last rendered sample.
        # The inherited flight cache still contains that sample's ordinary escorts.
        if self.special is not None and result['fleet'] is None and self.last and t==self.last[0] and t==self.special[0]:
            result['fleet']=dict(index=0,anchor=self.special[1]);result['items']=[b for b in result['items'] if b['id']==-1];result['draw_order']=[-1]
        if result['fleet'] is not None:
            result['primary_effects']=[]
            if self._departure:
                start,items=self._departure;f=clamp((t-start)/.18,0,1)
                if f<1:
                    for b in items:
                        q=copy.deepcopy(b);q['opacity']*=1-f*f*(3-2*f);q['power']=0.;q['control_jets']={k:0. for k in q.get('control_jets',{})};result['departing_escorts'].append(q)
                else:self._departure=None
        else:self._departure=None
        self._last_tick=key;self._last_output=copy.deepcopy(result)
        return result
    def configure(self,**kwargs):
        super().configure(**kwargs);self._last_tick=None
    def button_down(self,t):
        ok=super().button_down(t);self._last_tick=None;return ok
    def button_up(self,t):
        ok=super().button_up(t);self._last_tick=None;return ok
    def cancel_fire(self):
        super().cancel_fire();self._last_tick=None
