"""Trial53: independent visual shooting and primary orientation settings.
Physical input and position are never modified. Trial50 escort simulation remains unchanged.
"""
import math,sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'effects_trial50'))
sys.path.insert(0,str(P.parent/'effects_trial52'))
from attitude import Coordinator as Base
from primary_fire import PrimaryFire
from trail import Trail,transform_anchor

FIXED_HEADING=-3*math.pi/4
MODES=('follow','fixed_upper_left')

class Coordinator(Base):
    def __init__(self,unit,count=3,enhanced=True,*,click_fire_enabled=True,orientation_mode='follow'):
        self._validate(click_fire_enabled,orientation_mode)
        self.click_fire_enabled=click_fire_enabled;self.orientation_mode=orientation_mode
        super().__init__(unit,count,enhanced)
    @staticmethod
    def _validate(enabled,mode):
        if type(enabled) is not bool:raise ValueError('click_fire_enabled must be bool')
        if mode not in MODES:raise ValueError('invalid orientation_mode')
    def reset(self):
        super().reset();self.primary_fire=PrimaryFire();self.fixed_trail=Trail(self.c,self.unit);self._fixed_tick=None
    def configure(self,*,click_fire_enabled=None,orientation_mode=None):
        enabled=self.click_fire_enabled if click_fire_enabled is None else click_fire_enabled
        mode=self.orientation_mode if orientation_mode is None else orientation_mode
        self._validate(enabled,mode)
        changed=mode!=self.orientation_mode
        if not enabled or enabled!=self.click_fire_enabled or changed:self.cancel_fire()
        if changed:
            self.fixed_trail.reset();self._fixed_tick=None;self._legacy_trails[0].reset()
        self.click_fire_enabled=enabled;self.orientation_mode=mode
    def _valid_event(self,t):
        return self.click_fire_enabled and self.last is not None and math.isfinite(t) and self.last[0]<=t<=self.last[0]+.15
    def button_down(self,t):return self.primary_fire.down(t) if self._valid_event(t) else False
    def button_up(self,t):return self.primary_fire.up(t) if self._valid_event(t) else False
    def cancel_fire(self):self.primary_fire.cancel()
    def trigger_special(self,t,anchor):
        ok=super().trigger_special(t,anchor)
        if ok:self.fixed_trail.reset();self._fixed_tick=None
        return ok
    def update(self,t,xy,scale=1.,visible=True,viewport=None):
        result=super().update(t,xy,scale,visible,viewport)
        out=dict(result);primary=next((b for b in result['items'] if b['id']==-1),None)
        if primary is not None and self.orientation_mode=='fixed_upper_left':
            primary=dict(primary);pose=primary['pose_index']
            front=self.f['assets'][self.unit]['muzzle_anchor_px'][pose];rear=self.m['assets'][self.unit]['rear_anchor_px'][pose]
            correction=math.atan2(front[1]-rear[1],front[0]-rear[0]);hd=FIXED_HEADING-correction
            pt=primary['draw_position'];sc=primary['scale']
            nozzle=transform_anchor(rear,(72,72),pt,sc,hd);muzzle=transform_anchor(front,(72,72),pt,sc,hd)
            primary.update(draw_heading=hd,beam_heading=FIXED_HEADING,nozzle=nozzle,muzzle=muzzle)
            out['items']=[primary if b['id']==-1 else b for b in result['items']]
            if self._fixed_tick!=t:
                self.fixed_trail.update(t,nozzle,primary['speed'],primary['power']*primary['opacity']);self._fixed_tick=t
            self.trails=[self.fixed_trail,*self.trails[1:]]
        out['primary_effects']=self.primary_fire.sample(t,primary) if self.click_fire_enabled and primary is not None else []
        return out
