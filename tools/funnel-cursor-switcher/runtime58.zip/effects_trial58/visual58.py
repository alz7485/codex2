"""Pixel-equivalent cropped primary effects; no desktop-sized empty buffers."""
import math, sys
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'effects_trial56'))
from visual56 import render as legacy_render

def render_layer(unit,effects,viewport):
    l,t,r,b=map(int,viewport)
    if r<=l or b<=t:raise ValueError('empty viewport')
    boxes=[]
    for e in effects:
        s=e['scale']
        if e['power']<=0 or s<=0:continue
        x,y=e['origin'];pad=math.ceil(64*s+8);reach=160*s if e['stage']!='charge' else 0
        ex=x+math.cos(e['heading'])*reach;ey=y+math.sin(e['heading'])*reach
        a=max(l,math.floor(min(x,ex)-pad));c=min(r,math.ceil(max(x,ex)+pad))
        q=max(t,math.floor(min(y,ey)-pad));d=min(b,math.ceil(max(y,ey)+pad))
        if a<c and q<d:boxes.append((a,q,c,d))
    if not boxes:return None,None
    bounds=(min(z[0] for z in boxes),min(z[1] for z in boxes),max(z[2] for z in boxes),max(z[3] for z in boxes))
    im=legacy_render(unit,effects,bounds)
    return (im,bounds[:2]) if im.getchannel('A').getbbox() else (None,None)

def render(unit,effects,viewport):
    """Compatibility: full-size layer. Prefer render_layer for desktop overlays."""
    l,t,r,b=map(int,viewport)
    im,origin=render_layer(unit,effects,viewport)
    out=Image.new('RGBA',(r-l,b-t))
    if im is not None:out.paste(im,(origin[0]-l,origin[1]-t))
    return out
