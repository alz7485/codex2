"""Release entry point. Visual-only; no OS input hooks."""
import copy, math, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'effects_trial57'))
from controller57 import Coordinator as Base, FIXED_HEADING

class Coordinator(Base):
    def reset(self):
        super().reset(); self._sample_geometry=None
    def update(self,t,xy,scale=1.,visible=True,viewport=None):
        # Validate viewport before state mutation, matching existing API.
        vp=None if viewport is None else tuple(viewport)
        if vp is not None and (len(vp)!=4 or not all(map(math.isfinite,vp)) or vp[0]>=vp[2] or vp[1]>=vp[3]):
            raise ValueError('invalid viewport')
        xy=tuple(xy); geometry=(t,xy,scale,vp)
        prev=self._sample_geometry
        if visible and prev is not None:
            # Monitor/DPI boundary is a discontinuity; never carry stale trails or held fire.
            # A changed position at the exact same time has no meaningful velocity.
            if vp!=prev[3] or (t==prev[0] and (xy!=prev[1] or scale!=prev[2])):
                self.reset()
        result=super().update(t,xy,scale,visible,vp)
        if result['items']:self._sample_geometry=geometry
        else:self._sample_geometry=None
        # Isolate inherited mutable flight cache from host-side drawing operations.
        return copy.deepcopy(result)
