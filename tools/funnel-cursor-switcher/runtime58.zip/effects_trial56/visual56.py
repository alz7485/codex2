"""Trial56 procedural VFX, straight RGBA. Coordinates and event timing unchanged.
Screen-space light only, never changes actual mouse input or the 3D geometry.
"""
import math
from PIL import Image, ImageDraw, ImageFilter
import numpy as np
from controller56 import Coordinator
from fire54 import MIN_CHARGE, FIRE, AFTER, smooth
COLORS={'qubeley':((255,196,67),(255,249,222)), 'sazabi':((64,255,119),(230,255,239))}

def clamp(x):return max(0.,min(1.,x))
def render(unit,effects,viewport):
    l,t,r,b=map(int,viewport);w,h=r-l,b-t
    if w<=0 or h<=0:raise ValueError('empty viewport')
    out=Image.new('RGBA',(w,h));residual=Image.new('RGBA',(w,h));color,core=COLORS[unit]
    # Multiple clicks still launch distinct shots; only their coincident muzzle charge is shared.
    charges=[e for e in effects if e['stage']=='charge']
    selected=max(charges,key=lambda e:(e['power'],e['age'])) if charges else None
    for e in sorted([e for e in effects if e['stage']!='charge'],key=lambda e: e['stage']!='afterglow')+([selected] if selected else []):
        x,y=e['origin'][0]-l,e['origin'][1]-t;hd=e['heading'];dx,dy=math.cos(hd),math.sin(hd);nx,ny=-dy,dx;s=e['scale'];p=clamp(e['power']);age=max(0.,e['age']);stage=e['stage']
        if p<=0 or s<=0:continue
        # Render locally to avoid allocating monitor-sized intermediate layers per shot.
        pad=math.ceil(64*s+8); reach=160*s if stage!='charge' else 0
        ex,ey=x+dx*reach,y+dy*reach
        a=max(0,math.floor(min(x,ex)-pad));b0=max(0,math.floor(min(y,ey)-pad));c=min(w,math.ceil(max(x,ex)+pad));d0=min(h,math.ceil(max(y,ey)+pad))
        if a>=c or b0>=d0:continue
        x-=a;y-=b0;size=(c-a,d0-b0)
        glow=Image.new('RGBA',size);g=ImageDraw.Draw(glow);sharp=Image.new('RGBA',size);d=ImageDraw.Draw(sharp)
        def rgba(rgb,alpha):return (*rgb,round(255*clamp(alpha)))
        def disc(draw,xx,yy,rad,fill):
            if rad>0:draw.ellipse((xx-rad,yy-rad,xx+rad,yy+rad),fill=fill)
        def line(draw,points,width,fill):draw.line(points,fill=fill,width=max(1,round(width*s)))
        def xy(along,side=0):return (x+s*(dx*along+nx*side),y+s*(dy*along+ny*side))
        if stage=='charge':
            progress=smooth(age/MIN_CHARGE);held=max(0.,age-MIN_CHARGE);pulse=1 if age<MIN_CHARGE else 1+.08*math.sin(held*math.tau*5)
            radius=s*(1.7+4.0*progress)*pulse
            orbit=s*(8+2*math.sin(held*math.tau*2.1))*progress
            if orbit>0:g.ellipse((x-orbit,y-orbit,x+orbit,y+orbit),outline=rgba(color,.24*p),width=max(1,round(s)))
            disc(g,x,y,radius*2.5,rgba(color,.55*p));disc(d,x,y,radius,rgba(color,.88*p));disc(d,x,y,radius*.47,rgba(core,.98*p))
            # Inward filaments: staggered pulses, heads and tapered trails.
            count=14 if unit=='qubeley' else 12
            for i in range(count):
                if age<MIN_CHARGE:
                    f=clamp((age/MIN_CHARGE-i%4*.065)/(1-i%4*.065));rr=4+25*(1-f)**1.22
                else:
                    f=(held*(2.8 if unit=='qubeley' else 3.7)+i/count)%1;rr=5+17*(1-f)**1.4
                strength=math.sin(math.pi*f)**.8
                if strength<.005:continue
                twist=.95 if unit=='qubeley' else .18
                ang=hd+i*2.399963+(1-f)*twist
                def point(dist,theta):return (x+math.cos(theta)*dist*s,y+math.sin(theta)*dist*s)
                q=point(rr,ang);mid=point(rr+2.4,ang+.08*twist);tail=point(rr+5.8,ang+.21*twist)
                alpha=.82*strength*p
                line(g,[tail,mid,q],2.3,rgba(color,alpha*.42))
                line(d,[tail,mid],.65,rgba(color,alpha*.32));line(d,[mid,q],.85,rgba(color,alpha*.82))
                disc(d,*q,s*(.48+.58*f),rgba(core,alpha))
        elif stage=='fire':
            # Leading tip grows rapidly, reaches full length in 40ms. Flash dies independently.
            travel=clamp(age/.04);length=12+148*(1-(1-travel)**1.5);flash=(1-clamp(age/.065))**1.5
            taper=1-.24*smooth((age-.045)/.055);end=xy(length)
            wide=1.0 if unit=='qubeley' else .78
            # Layered, tapered beam envelope with a narrow hot core.
            def envelope(draw,width,fill):
                draw.polygon([xy(0,-width*.32),xy(length*.13,-width),xy(length*.80,-width*.65),xy(length,0),xy(length*.80,width*.65),xy(length*.13,width),xy(0,width*.32)],fill=fill)
            envelope(g,9*taper*wide,rgba(color,.55*p));line(g,[(x,y),end],9*taper,rgba(color,.62*p))
            envelope(d,4.5*taper*wide,rgba(color,.83*p));envelope(d,2.5*taper*wide,rgba(core,.88*p))
            line(d,[xy(0),xy(length*.96)],1.25*taper,rgba((255,255,255),p))
            # Advect small luminous knots along the fixed beam axis, entirely inside its envelope.
            flow_speed=2050 if unit=='sazabi' else 1630
            spacing=30 if unit=='sazabi' else 38
            for i in range(6):
                q=(age*flow_speed+i*spacing)% (6*spacing)
                if q>length*.94 or q<3:continue
                side=(.55 if unit=='sazabi' else 1.15)*math.sin(q*.052+i*2.1)*taper
                tail=max(0,q-(10 if unit=='sazabi' else 17))
                line(d,[xy(tail,side),xy(q,side)],1.5*taper,rgba(core,.9*p))
                disc(d,*xy(q,side),s*.8*taper,rgba((255,255,255),p))
            disc(d,*end,s*2.1*taper,rgba(core,.92*p));disc(g,x,y,s*(5+12*flash),rgba(color,.8*p));disc(d,x,y,s*(2.8+5*flash),rgba(core,p))
            for i in range(6):
                angle=hd+i*math.tau/6+.21;rr=s*(6+13*flash);q=(x+math.cos(angle)*rr,y+math.sin(angle)*rr)
                line(d,[(x,y),q],.85,rgba(core,flash*.9*p))
            # Expanding shock fronts perpendicular to beam; Qubeley soft double ring,
            # Sazabi narrow forward cone and single sharper ring.
            for j in range(2 if unit=='qubeley' else 1):
                f=clamp((age-j*.016)/.09)
                if age<j*.016 or f>=1:continue
                radius=(5+29*f);axial=radius*(.56 if unit=='qubeley' else .30);offset=4+12*f
                points=[xy(offset+axial*math.cos(i*math.tau/40),radius*math.sin(i*math.tau/40)) for i in range(41)]
                alpha=(1-f)**1.6*(.65 if j==0 else .38)
                line(g,points,2.5,rgba(color,alpha*p));line(d,points,.8,rgba(core,alpha*.62*p))
        else:
            # Fixed beam axis; tail retracts from the muzzle toward its tip as it fades.
            f=clamp((age-FIRE)/AFTER);start=xy(160*smooth(f));end=xy(160)
            line(g,[start,end],8*p,rgba(color,.43*p));line(d,[start,end],3.9*p,rgba(color,.75*p));line(d,[start,end],1.5*p,rgba(core,.82*p));disc(d,*end,s*1.8*p,rgba(core,.7*p))
            # A short-lived, deterministic spray from the fixed muzzle. No new shots.
            count=8 if unit=='qubeley' else 6
            for i in range(count):
                z=(i+.5)/count;side=(-1 if i%2 else 1)*(3+z*12)*(1+f*1.5)
                along=(6+z*26)*f+3;alpha=.56*p*(1-f)**1.3*(.6+.4*math.sin(i*2.4+1)**2)
                q=xy(along,side*f);tail=xy(max(0,along-3.5),side*max(0,f-.08))
                line(g,[tail,q],1.6,rgba(color,alpha*.5));line(d,[tail,q],.65,rgba(color,alpha*.7))
                disc(d,*q,s*(.75-.35*f),rgba(core,alpha))
        local=Image.alpha_composite(glow.filter(ImageFilter.GaussianBlur(max(.65,2.7*s))),sharp)
        if stage=='afterglow':
            # Strongest residual wins per pixel; distinct rays remain, overlaps do not brighten without bound.
            old=np.asarray(residual.crop((a,b0,c,d0)));new=np.asarray(local)
            merged=np.where((new[:,:,3]>old[:,:,3])[:,:,None],new,old)
            residual.paste(Image.fromarray(merged,'RGBA'),(a,b0))
        else:out.alpha_composite(local,(a,b0))
    return Image.alpha_composite(residual,out)
