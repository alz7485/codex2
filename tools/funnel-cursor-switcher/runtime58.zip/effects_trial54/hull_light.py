"""Approximate light spill strictly on the original hull, before scale and rotation.
No geometry changes, no alpha changes, no illumination of exhaust-only pixels.
"""
import numpy as np
from PIL import Image
from visual54 import COLORS

def illuminate(sprite,body,front,unit,effects):
    # Only active, local muzzle light; old free-flying beams do not relight a moving hull.
    energy=max([e['power']*(.32 if e['stage']=='charge' else .78*max(0,1-e['age']/.065)) for e in effects if e['stage'] in ('charge','fire')]+[0.])
    if energy<=0:return sprite
    a=np.asarray(sprite.convert('RGBA')).copy();mask=np.asarray(body.convert('RGBA'))[:,:,3].astype(np.float32)/255
    if mask.shape!=a.shape[:2]:raise ValueError('body and composite size mismatch')
    yy,xx=np.indices(mask.shape);dist=((xx-front[0])**2+(yy-front[1])**2)**.5
    weight=(energy*np.exp(-dist/18)*mask*(a[:,:,3]>0))[:,:,None]
    color=np.asarray(COLORS[unit][1],dtype=np.float32)
    a[:,:,:3]=np.rint(a[:,:,:3]*(1-weight)+color*weight).clip(0,255).astype('uint8')
    return Image.fromarray(a,'RGBA')
