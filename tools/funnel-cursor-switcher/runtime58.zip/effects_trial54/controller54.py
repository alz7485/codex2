"""Trial54: Trial53 settings and unchanged flight; primary shot queue only."""
import sys
from pathlib import Path
P=Path(__file__).resolve().parent
sys.path.insert(0,str(P.parent/'effects_trial53'))
from controller import Coordinator as Base, FIXED_HEADING
from fire54 import PrimaryFire
class Coordinator(Base):
    def reset(self):
        super().reset();self.primary_fire=PrimaryFire()
