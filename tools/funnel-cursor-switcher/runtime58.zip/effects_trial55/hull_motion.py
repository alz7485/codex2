"""Subpixel hull recoil/rocking around the muzzle. Never modify input or flight state."""
import math
from PIL import Image
from controller55 import Coordinator  # establishes legacy module paths
from hull_light import illuminate

def motion(unit,effects):
    charge=max((e for e in effects if e['stage']=='charge'),key=lambda e:e['power'],default=None)
    fire=max((e for e in effects if e['stage']=='fire'),key=lambda e:-e['age'],default=None)
    angle=0.;compression=0.
    if charge:
        angle=math.radians(.40 if unit=='qubeley' else .55)*charge['power']*math.sin(charge['age']*math.tau*13)
    if fire:
        t=max(0,fire['age']); envelope=math.sin(math.pi*min(1,t/.10))
        compression=(.012 if unit=='qubeley' else .018)*envelope
        angle+=math.radians(.30 if unit=='qubeley' else .45)*envelope*math.sin(t*math.tau*18)
    return max(-.012,min(.012,angle)),compression

def render_hull(sprite,body,front,rear,unit,effects):
    lit=illuminate(sprite,body,front,unit,effects)
    theta,k=motion(unit,effects)
    if not theta and not k:return lit
    # Inverse affine: rotate then expand along longitudinal axis about fixed muzzle.
    dx,dy=front[0]-rear[0],front[1]-rear[1];length=math.hypot(dx,dy)
    if length<=0:return lit
    ux,uy=dx/length,dy/length;cs,sn=math.cos(theta),math.sin(theta);q=1/(1-k)-1
    a,b,c,d=1+q*ux*ux,q*ux*uy,q*ux*uy,1+q*uy*uy
    A,B,C,D=a*cs-b*sn,a*sn+b*cs,c*cs-d*sn,c*sn+d*cs
    x,y=front
    return lit.transform(lit.size,Image.Transform.AFFINE,(A,B,x-A*x-B*y,C,D,y-C*x-D*y),resample=Image.Resampling.BICUBIC)
