"""Trial55 visual-only wrapper. All flight, timing and settings inherited unchanged."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'effects_trial54'))
from controller54 import Coordinator, FIXED_HEADING
