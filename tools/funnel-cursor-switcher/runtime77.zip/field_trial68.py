"""Trial68 field palette, lighting and depth. Keeps Trial67 choreography and 3D captures.
All new effects are projected 2D overlays; no OS input or cursor manipulation.
"""
from field_trial67 import Barrier as BaseBarrier, FieldFleet as BaseFleet, triangles
from field_trial66 import ROOT,EDGES,FACES,COLOR,clamp,smooth,mix,add,mul,unit,color,dot,line
import numpy as np
import re
import math
from PIL import Image,ImageDraw,ImageFilter

PALETTES = {'purple': (168,117,255), 'blue': (69,164,255), 'green': (76,235,156), 'amber': (255,184,68)}

def parse_color(value):
 if isinstance(value,str):
  if value in PALETTES:return PALETTES[value]
  if re.fullmatch(r'#[0-9a-fA-F]{6}',value):return tuple(int(value[i:i+2],16) for i in (1,3,5))
 if isinstance(value,(tuple,list)) and len(value)==3 and all(type(v)==int and 0<=v<=255 for v in value):return tuple(value)
 raise ValueError('field_color must be a preset, #RRGGBB or RGB integers')

def tint(col,target):
 # Preserve achromatic white cores; replace purple chroma while retaining tone.
 if target==COLOR:return col
 low=min(col);high=max(col);chroma=high-low
 if chroma==0:return col
 return tuple(round(clamp(low+chroma*t/255,0,255)) for t in target)

class Barrier(BaseBarrier):
 def __init__(self,root=ROOT,field_color='purple'):
  super().__init__(root);self.field_color=parse_color(field_color);self._tinted={}
 def set_field_color(self,value):
  self.field_color=parse_color(value);self._tinted.clear()
 def trigger(self,*args,**kwargs):
  ok=super().trigger(*args,**kwargs)
  if ok:self.event['field_color']=self.field_color
  return ok
 def sample(self,t):
  st=super().sample(t)
  if st is not None:st['field_color']=self.event['field_color']
  return st
 def _station(self,v):
  target=v.get('field_color',COLOR)
  if target==COLOR:return super()._station(v)
  key=(v['id'],v['pose'],target)
  if key not in self._tinted:
   if len(self._tinted)>=40:self._tinted.clear()
   a=self._image(f'trial66/poses/{v["id"]}-{v["pose"]}-base.png');b=self._image(f'trial66/poses/{v["id"]}-{v["pose"]}-lit.png')
   av=np.asarray(a,dtype=np.float32);bv=np.asarray(b,dtype=np.float32);delta=bv[:,:,:3]-av[:,:,:3]
   # Retint only the positive illumination contribution, not the paint or alpha.
   positive=np.maximum(delta,0);neutral=positive.min(axis=2,keepdims=True);energy=(positive-neutral).max(axis=2,keepdims=True)
   rgb=av[:,:,:3]+np.minimum(delta,0)+neutral+energy*np.asarray(target,dtype=np.float32)/255
   arr=np.asarray(a).copy();arr[:,:,:3]=np.clip(np.rint(rgb),0,255).astype(np.uint8);self._tinted[key]=Image.fromarray(arr,'RGBA')
  a=self._image(f'trial66/poses/{v["id"]}-{v["pose"]}-base.png');im=Image.blend(a,self._tinted[key],clamp(v['light']));im.putalpha(a.getchannel('A'));n=max(1,round(self.cell*v['scale']));return im.resize((n,n),Image.Resampling.LANCZOS)
 def _light(self,v,st):
  if st['phase'] not in ('charge','link','hold','dissolve'):return v['light']
  phase=st['age']*math.tau*2.3-v['id']*.68
  p=.78+.22*(.5+.5*math.sin(phase))
  if st['phase']=='dissolve':p*=1-smooth((st['u']-v['id']*.025)/.9)
  return clamp(v['light']*p)
 def draw(self,background,state):
  if state is None:return background.copy().convert('RGBA')
  out=background.copy().convert('RGBA');size=out.size;st=state;age=st['age'];sc=st['scale'];opacity=st['opacity'];pts=st['stations'];fa=st['field_alpha'];ep=st['edge_progress'];phase=st['phase'];u=st['u'];c=st.get('field_color',self.field_color)
  def field_color(col,alpha):return color(tint(col,c),alpha)
  if opacity==0:return out
  # Projected triangular lattice. Each cell lies within its own face before dissolution.
  if fa>0 or phase=='dissolve':
   faces=sorted(FACES,key=lambda face:sum(st['vertices'][i][2] for i in face))
   for k,face in enumerate(faces):
    a,b,p=[pts[i] for i in face];layer=Image.new('RGBA',size);d=ImageDraw.Draw(layer)
    pulse=.88+.12*math.sin(age*math.tau*2.3+k*.85)
    depth=.58+.14*k
    if phase!='dissolve':
     d.polygon([a,b,p],fill=field_color((125+12*k,76+9*k,245),(24+5*k)*fa*pulse*opacity*depth))
     for j in range(1,9):
      q=j/9
      for A,B,C in ((a,b,p),(b,p,a),(p,a,b)):
       line(d,[mix(A,B,q),mix(A,C,q)],field_color((188,148,255),16*fa*opacity*depth),max(1,sc*.7))
     for j in range(3):
      q=(age*.95+j/3+k*.075)%1;strength=math.sin(math.pi*q)**.8*fa*opacity
      A,B=mix(p,a,q),mix(p,b,q)
      line(d,[A,B],field_color((178,121,255),42*strength*depth),max(1,7*sc))
      line(d,[A,B],field_color((231,210,255),125*strength*depth),max(1,1.4*sc))
      for m in range(3):
       v=(age*.7+m/3+k*.17)%1;dot(d,mix(A,B,v),max(.6,1.9*sc),field_color((244,234,255),150*strength))
    # 36 deterministic triangles per face: bright cells during hold, peeling fragments during dissolve.
    for idx,tri in enumerate(triangles(a,b,p,6)):
     center=tuple(sum(v[j] for v in tri)/3 for j in (0,1));seed=(idx*37+k*59)%101/101
     if phase=='dissolve':
      progress=clamp((u-seed*.25)/.75);direction=unit((center[0]-st['center'][0],center[1]-st['center'][1]));offset=mul(direction,st['radius']*.38*progress**1.7);ang=(seed-.5)*2.1*progress
      cs,sn=math.cos(ang),math.sin(ang);shrink=1-.78*progress
      poly=[add(add(center,offset),((v[0]-center[0])*cs*shrink-(v[1]-center[1])*sn*shrink,(v[0]-center[0])*sn*shrink+(v[1]-center[1])*cs*shrink)) for v in tri]
      alpha=opacity*(1-progress)**1.5
      if alpha>0:d.polygon(poly,fill=field_color((163,112,255),54*alpha),outline=field_color((227,202,255),100*alpha))
     else:
      wave=max(0,math.sin(age*5.2+idx*.73+k*1.4))**6
      if wave>.12:d.polygon(tri,fill=field_color((192,151,255),45*wave*fa*opacity*depth))
    out.alpha_composite(layer)
  effects=Image.new('RGBA',size);d=ImageDraw.Draw(effects)
  # Eight edges including four base edges. Each starts at an emitter; no triangles fabricated in screen space.
  if ep>0:
   fade=1-smooth(u) if phase=='dissolve' else 1.
   for j,(a,b) in enumerate(EDGES):
    pa,pb=pts[a],pts[b];q=smooth((ep-j*.045)/.685) if phase=='link' else 1.;end=mix(pa,pb,q)
    if q<=0:continue
    for width,alpha,col in [(13,37,COLOR),(6,108,COLOR),(2.2,220,(236,219,255))]:line(d,[pa,end],field_color(col,alpha*opacity*fade),width*sc)
    # Segmented electrical filament follows the connected portion of the actual edge.
    direction=unit((pb[0]-pa[0],pb[1]-pa[1]));normal=(-direction[1],direction[0]);arc=[]
    for n in range(13):
     h=n/12;w=math.sin(math.pi*h)*math.sin(age*math.tau*11+j*2.1+n*3.8)*min(3.5*sc,st['radius']*.025)
     arc.append(add(mix(pa,end,h),mul(normal,w)))
    line(d,arc,field_color((235,214,255),155*opacity*fade),max(1,sc*1.25))
    # A short packet of light travels from an emitter along the edge.
    v=(age*2.2+j*.093)%1;head=min(v,q);tail=max(0,head-.16)
    if v<q and head>tail:
     line(d,[mix(pa,pb,tail),mix(pa,pb,head)],field_color((255,248,255),235*opacity*fade),max(1,2.6*sc))
    for k in range(2):
     v=(age*1.65+j*.137+k*.5)%1
     if v<q:dot(d,mix(pa,pb,v),max(1,2.6*sc),field_color((250,242,255),215*opacity*fade))
  if phase in ('charge','link','hold','dissolve'):
   for v in st['units']:
    p=v['anchor'];power=self._light(v,st);rr=(5+2*math.sin(age*math.tau*7+v['id']))*sc*power;dot(d,p,max(0,rr*2.8),color(c,58*power*opacity));dot(d,p,max(0,rr),field_color((249,238,255),240*power*opacity))
    for j in range(7):
     q=(age*2.7+j/7)%1;ang=j*2.39996+age*3+v['id'];r=(20*(1-q)+3)*sc;dot(d,add(p,(r*math.cos(ang),r*math.sin(ang))),max(.6,1.5*sc),field_color((218,190,255),185*power*opacity*math.sin(math.pi*q)))
   if phase=='link':
    rr=st['radius']*.75*smooth(u);p=st['center'];d.ellipse((p[0]-rr,p[1]-rr*.72,p[0]+rr,p[1]+rr*.72),outline=field_color((208,166,255),100*math.sin(math.pi*u)*opacity),width=max(1,round(2*sc)))
  # A local formation flash, not a full-screen whiteout. Continuous through link -> hold.
  flash_age=u*st['hold'] if phase=='hold' else 99
  if 0<=flash_age<.20:
   f=smooth(flash_age/.025)*math.exp(-((flash_age-.035)/.052)**2)*opacity
   for p in pts:
    dot(d,p,max(1,12*sc*f),field_color((225,201,255),120*f));dot(d,p,max(1,3.5*sc*f),field_color((255,250,255),245*f))
   for a,b in EDGES:line(d,[pts[a],pts[b]],field_color((250,240,255),180*f),max(1,3.2*sc))
   center=st['center'];rr=st['radius']*(.18+.95*clamp(flash_age/.20));d.ellipse((center[0]-rr,center[1]-.72*rr,center[0]+rr,center[1]+.72*rr),outline=field_color((220,191,255),125*f),width=max(1,round(2.5*sc)))
  if phase=='dissolve':
   for j,(a,b) in enumerate(EDGES):
    for k in range(6):
     q=(k+.5)/6;p=mix(pts[a],pts[b],q);direction=unit((p[0]-st['center'][0],p[1]-st['center'][1]));p=add(p,mul(direction,st['radius']*.28*u*u));dot(d,p,max(.5,2.4*sc*(1-u)),field_color((214,185,255),200*(1-u)**1.5*opacity))
  out.alpha_composite(effects.filter(ImageFilter.GaussianBlur(max(1,6*sc))));out.alpha_composite(effects)
  for v in sorted(st['units'],key=lambda v:st['vertices'][v['id']][2] if v['id']<5 else 0):
   v=dict(v,light=self._light(v,st),field_color=c);p=v['anchor'];alpha=v['opacity']*opacity;blend=v.get('blend',0)
   departing=phase=='depart'
   if departing:
    # Close first, then blend to the real flight pose and aim outward.
    fly=smooth((u-.18)/.30);station_v=v
    v=dict(v,heading=v['heading']+math.pi,kind='flight',blend=0.,power=v['power']*fly,trail_start=add(p,mul((math.cos(v['heading']),math.sin(v['heading'])),st['radius']*.13*fly)))
   else:fly=1.
   if v['kind']=='flight':
    im,off,fsc=self._fly_sprite(v);center=(p[0]-off[0],p[1]-off[1]);c0,d0=math.cos(v['heading']),math.sin(v['heading']);anchor=self.flight_manifest['pivot'];nozzles=[]
    for n in self.flight_pose['nozzles']:
     x,y=(n[0]-anchor[0])*fsc,(n[1]-anchor[1])*fsc;nozzles.append((center[0]+x*c0-y*d0,center[1]+x*d0+y*c0))
    jet=Image.new('RGBA',size);j=ImageDraw.Draw(jet);power=v['power']*(1-blend);tail=v['trail_start'];w=max(1,5*fsc)
    for noz in nozzles:
     end=add(noz,(-c0*42*fsc*power,-d0*42*fsc*power));line(j,[tail,noz],color((67,163,255),65*alpha*power),w);line(j,[noz,end],color((122,214,255),200*alpha*power),w);line(j,[noz,mix(noz,end,.57)],color((243,252,255),245*alpha*power),max(1,w*.3))
    out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(max(1,3*fsc))));out.alpha_composite(jet)
    if departing:self._paste(out,self._station(station_v),p,alpha*(1-fly))
    if blend<1:self._paste(out,im,center,alpha*(1-blend)*fly)
    if blend>0:self._paste(out,self._station(v),p,alpha*blend)
   else:self._paste(out,self._station(v),p,alpha)
  return out

class FieldFleet(BaseFleet):
 def __init__(self,root=ROOT,enabled=True,count=0,field_color="purple"):
  super().__init__(root,enabled,count);self.barrier=Barrier(root,field_color)
 def set_field_color(self,value):self.barrier.set_field_color(value)
