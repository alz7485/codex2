"""Trial66 visual-only square-pyramid field. Source geometry is v1.6.3.
Coordinates are absolute in the draw surface; time is monotonic seconds.
The host supplies monitor bounds and an existing special-effect trigger, never OS hooks.
"""
from pathlib import Path
import math,json
from PIL import Image,ImageDraw,ImageFilter
from escort_trial65 import FleetFlight

ROOT=Path(__file__).resolve().parent
EDGES=((0,1),(1,2),(2,3),(3,0),(0,4),(1,4),(2,4),(3,4))
FACES=((0,1,4),(1,2,4),(2,3,4),(3,0,4))
COLOR=(168,117,255)

def clamp(x,a=0.,b=1.):return max(a,min(b,x))
def smooth(x):x=clamp(x);return x*x*(3-2*x)
def mix(a,b,u):return tuple(x+(y-x)*u for x,y in zip(a,b))
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def mul(a,k):return (a[0]*k,a[1]*k)
def unit(a):
 n=math.hypot(*a);return (a[0]/n,a[1]/n) if n>1e-8 else (1.,0.)
def dirangle(a):return math.atan2(a[1],a[0])
def angle_mix(a,b,t):return a+((b-a+math.pi)%(2*math.pi)-math.pi)*t
def color(c,alpha):return (*c,round(clamp(alpha,0,255)))
def valid_bounds(b):
 return b is not None and len(b)==4 and all(math.isfinite(x) for x in b) and b[2]>b[0] and b[3]>b[1]
def exit_point(origin,direction,bounds,margin):
 l,t,r,b=bounds;x,y=origin;dx,dy=direction;cs=[]
 if dx>1e-8:cs.append((r+margin-x)/dx)
 if dx<-1e-8:cs.append((l-margin-x)/dx)
 if dy>1e-8:cs.append((b+margin-y)/dy)
 if dy<-1e-8:cs.append((t-margin-y)/dy)
 return add(origin,mul(direction,max(0,min(cs))))

def dot(d,p,r,c):
 if r>0:d.ellipse((p[0]-r,p[1]-r,p[0]+r,p[1]+r),fill=c)

def line(d,pts,col,width):
 if len(pts)>1:d.line(pts,fill=col,width=max(1,round(width)),joint='curve')

class Barrier:
 def __init__(self,root=ROOT):
  self.root=Path(root);self.data=json.loads((self.root/'trial66/field_manifest.json').read_text(encoding="utf-8"));self.verts=[tuple(v['camera_vertex']) for v in self.data['stations']];self.cell=self.data['cell'][0];self.cache={};self.event=None
  self.flight_manifest=json.loads((self.root/'trial62/flight_manifest.json').read_text(encoding="utf-8"));self.flight_pose=next(p for p in self.flight_manifest['poses'] if p['roll']==0 and p['pitch']==0);self.flight_anchor=next(p for p in json.loads((self.root/'trial63/charge_manifest.json').read_text(encoding="utf-8"))['poses'] if p['stem']==self.flight_pose['stem'])['grid']
 def cancel(self):self.event=None
 def active_at(self,t):return self.event is not None and self.event['start']<=t<self.event['start']+self.event['end']
 def trigger(self,t,anchor,bounds,radius=58,hold=1.4,scale=.58,opacity=.85):
  if not (math.isfinite(t) and len(anchor)==2 and all(math.isfinite(v) for v in anchor) and valid_bounds(bounds) and all(math.isfinite(v) for v in (radius,hold,scale,opacity)) and 8<=radius<=1000 and .1<=hold<=10 and 0<scale<=4 and 0<=opacity<=1):raise ValueError('invalid field settings')
  if self.active_at(t):return False
  # Keep the field itself on the selected monitor when practical. Never modify the OS hotspot.
  l,top,r,b=map(float,bounds);x,y=map(float,anchor);origin=(clamp(x,l,r),clamp(y,top,b));requested=radius
  # Account for the actual sprite extent as well as the projected station coordinates.
  room=min((r-l)/2.85,(b-top)/2.55);radius=min(radius,room);sprite_scale=min(scale*.82,radius/78)
  # Fit both vertex extents and the depth-scaled fixed-origin 192px sprite.
  margin=min(4.,(r-l)/16,(b-top)/16)
  base_pad=self.cell*.5*sprite_scale*(1+.10*max(v[2] for v in self.verts))
  span_x=radius*(max(v[0] for v in self.verts)-min(v[0] for v in self.verts))+2*base_pad
  span_y=radius*(max(v[1] for v in self.verts)-min(v[1] for v in self.verts))+2*base_pad
  fit_scale=min(1.,(r-l-2*margin)/span_x,(b-top-2*margin)/span_y)
  radius*=fit_scale;sprite_scale*=fit_scale;pad=base_pad*fit_scale+margin
  minx,maxx=min(v[0] for v in self.verts)*radius-pad,max(v[0] for v in self.verts)*radius+pad
  miny,maxy=min(-v[1] for v in self.verts)*radius-pad,max(-v[1] for v in self.verts)*radius+pad
  def fit(v,lo,hi,a,z):return clamp(v,a-lo,z-hi) if a-lo<=z-hi else (a+z-lo-hi)/2
  center=(fit(x,minx,maxx,l,r),fit(y,miny,maxy,top,b));stations=[(center[0]+radius*v[0],center[1]-radius*v[1]) for v in self.verts]
  headings=[]
  for i,v in enumerate(self.data['stations']):
   dirs=[unit((stations[j][0]-stations[i][0],stations[j][1]-stations[i][1])) for j in v['rails']];headings.append(dirangle(add(*dirs)))
  # 6 depart; 5 come back in from beyond the screen. Leave the sixth absent, as in v1.6.3.
  launch=[]
  for i in range(6):
   ang=-math.pi/2+i*math.tau/6;d=(math.cos(ang),math.sin(ang));launch.append(exit_point(origin,d,bounds,192*scale+16))
  entry=[]
  for i,p in enumerate(stations):
   d=(-math.cos(headings[i]),-math.sin(headings[i]));entry.append(exit_point(p,d,bounds,192*scale+16))
  ends={'launch':.64,'gap':.88,'return':1.58,'open':1.91,'charge':2.20,'link':2.52,'hold':2.52+hold,'dissolve':2.97+hold,'depart':3.30+hold}
  self.event=dict(start=t,origin=origin,center=center,stations=stations,headings=headings,launch=launch,entry=entry,radius=radius,requested_radius=requested,scale=sprite_scale,requested_scale=scale,opacity=opacity,bounds=tuple(bounds),ends=ends,end=ends['depart']);return True
 def sample(self,t):
  e=self.event
  if e is None or not self.active_at(t):return None
  age=t-e['start'];ends=e['ends'];phase=next(k for k,v in ends.items() if age<v);prev=0 if phase=='launch' else list(ends.values())[list(ends).index(phase)-1];u=clamp((age-prev)/(ends[phase]-prev));s=e['scale'];units=[]
  def flying(i,a,b,q,kind):
   d=unit((b[0]-a[0],b[1]-a[1]));p=mix(a,b,q);hd=dirangle(d);return dict(id=i,kind=kind,anchor=p,heading=hd,scale=s,pose=0,light=0,opacity=1,trail_start=mix(a,b,max(0,q-.08)),power=1)
  if phase=='launch':
   for i,b in enumerate(e['launch']):
    q=clamp((u-i*.025)/(1-i*.025));units.append(flying(i,e['origin'],b,q*q,'flight'))
  elif phase=='return':
   for i,p in enumerate(e['stations']):
    delay=(i%3)*.08;q=clamp((u-delay)/(1-delay));d=1-(1-q)**2.5;v=flying(i,e['entry'][i],p,d,'flight');v['scale']=s*(1+.10*self.verts[i][2]);v['heading']=angle_mix(v['heading'],e['headings'][i],smooth((q-.65)/.35));v['power']=1-smooth((q-.60)/.40);v['blend']=smooth((q-.76)/.24);units.append(v)
  elif phase not in ('gap',):
   for i,p in enumerate(e['stations']):
    d=1+.10*self.verts[i][2];pose=round(3*smooth(u)) if phase=='open' else 3
    light=smooth(u) if phase=='charge' else 1. if phase in ('link','hold') else (1-smooth(u)) if phase=='dissolve' else 0.
    pos=p;alpha=1.;kind='station';heading=e['headings'][i];power=0.
    if phase=='depart':
     dest=exit_point(p,(-math.cos(heading),-math.sin(heading)),e['bounds'],192*s+16);pos=mix(p,dest,u*u);alpha=1-smooth((u-.72)/.28);pose=round(3*(1-smooth(u*2)));power=smooth(u*3)
    units.append(dict(id=i,kind=kind,anchor=pos,heading=heading,scale=s*d,pose=pose,light=light,opacity=alpha,power=power))
  edge_progress=0. if phase not in ('link','hold','dissolve') else u if phase=='link' else 1.
  field_alpha=smooth((u-.32)/.68) if phase=='link' else 1. if phase=='hold' else 1-smooth(u) if phase=='dissolve' else 0.
  return dict(t=t,age=age,phase=phase,u=u,units=units,stations=e['stations'],origin=e['origin'],center=e['center'],scale=s,radius=e['radius'],opacity=e['opacity'],edge_progress=edge_progress,field_alpha=field_alpha,vertices=self.verts,hold=e['ends']['hold']-e['ends']['link'])
 def _image(self,name):
  if name not in self.cache:
   with Image.open(self.root/name) as im:self.cache[name]=im.convert('RGBA')
  return self.cache[name]
 def _station(self,v):
  a=self._image(f'trial66/poses/{v["id"]}-{v["pose"]}-base.png');b=self._image(f'trial66/poses/{v["id"]}-{v["pose"]}-lit.png');im=Image.blend(a,b,clamp(v['light']));im.putalpha(a.getchannel('A'));n=max(1,round(self.cell*v['scale']));return im.resize((n,n),Image.Resampling.LANCZOS)
 def _fly_sprite(self,v):
  stem=self.flight_pose['stem'];a=self._image(f'trial62/poses/{stem}_base.png');b=self._image(f'trial62/poses/{stem}_lit.png');im=Image.blend(a,b,clamp(v['power']));im.putalpha(a.getchannel('A'));sc=v['scale']*.75;n=max(1,round(256*sc));im=im.resize((n,n),Image.Resampling.LANCZOS).rotate(-math.degrees(v['heading']),resample=Image.Resampling.BICUBIC,expand=True);c,d=math.cos(v['heading']),math.sin(v['heading']);x,y=(self.flight_anchor[0]-128)*sc,(self.flight_anchor[1]-128)*sc;off=(x*c-y*d,x*d+y*c);return im,off,sc
 def draw(self,background,state):
  if state is None:return background.copy().convert('RGBA')
  out=background.copy().convert('RGBA');size=out.size;st=state;age=st['age'];sc=st['scale'];opacity=st['opacity'];pts=st['stations'];fa=st['field_alpha'];ep=st['edge_progress'];phase=st['phase'];u=st['u'];c=COLOR
  if opacity==0:return out
  # Faces are depth-sorted, low-alpha and independently composited. Moving iso-lines remain inside each face.
  if fa>0:
   faces=sorted(FACES,key=lambda face:sum(st['vertices'][i][2] for i in face))
   for k,face in enumerate(faces):
    a,b,p=[pts[i] for i in face];layer=Image.new('RGBA',size);d=ImageDraw.Draw(layer);pulse=.87+.13*math.sin(age*8+k*1.2);d.polygon([a,b,p],fill=color((125+12*k,76+9*k,245), (27+8*k)*fa*pulse*opacity))
    for j in range(1,8):
     q=j/8;line(d,[mix(p,a,q),mix(p,b,q)],color((196,160,255),22*fa*opacity),max(1,sc))
     line(d,[mix(a,b,q),mix(p,b,q)],color((164,130,255),16*fa*opacity),max(1,sc))
    for j in range(3):
     q=(age*1.2+j/3+k*.08)%1;line(d,[mix(p,a,q),mix(p,b,q)],color((205,182,255),82*fa*math.sin(math.pi*q)*opacity),max(1,2*sc))
    out.alpha_composite(layer)
  effects=Image.new('RGBA',size);d=ImageDraw.Draw(effects)
  # Eight edges including four base edges. Each starts at an emitter; no triangles fabricated in screen space.
  if ep>0:
   fade=1-smooth(u) if phase=='dissolve' else 1.
   for j,(a,b) in enumerate(EDGES):
    pa,pb=pts[a],pts[b];q=smooth((ep-j*.045)/.685) if phase=='link' else 1.;end=mix(pa,pb,q)
    if q<=0:continue
    for width,alpha,col in [(13,37,c),(6,108,c),(2.2,220,(236,219,255))]:line(d,[pa,end],color(col,alpha*opacity*fade),width*sc)
    for k in range(2):
     v=(age*1.65+j*.137+k*.5)%1
     if v<q:dot(d,mix(pa,pb,v),max(1,2.6*sc),color((250,242,255),215*opacity*fade))
  if phase in ('charge','link','hold','dissolve'):
   for v in st['units']:
    p=v['anchor'];power=v['light'];rr=(5+2*math.sin(age*math.tau*7+v['id']))*sc*power;dot(d,p,max(0,rr*2.8),color(c,58*power*opacity));dot(d,p,max(0,rr),color((249,238,255),240*power*opacity))
    for j in range(7):
     q=(age*2.7+j/7)%1;ang=j*2.39996+age*3+v['id'];r=(20*(1-q)+3)*sc;dot(d,add(p,(r*math.cos(ang),r*math.sin(ang))),max(.6,1.5*sc),color((218,190,255),185*power*opacity*math.sin(math.pi*q)))
   if phase=='link':
    rr=st['radius']*.75*smooth(u);p=st['center'];d.ellipse((p[0]-rr,p[1]-rr*.72,p[0]+rr,p[1]+rr*.72),outline=color((208,166,255),100*math.sin(math.pi*u)*opacity),width=max(1,round(2*sc)))
  if phase=='dissolve':
   for j,(a,b) in enumerate(EDGES):
    for k in range(6):
     q=(k+.5)/6;p=mix(pts[a],pts[b],q);direction=unit((p[0]-st['center'][0],p[1]-st['center'][1]));p=add(p,mul(direction,st['radius']*.28*u*u));dot(d,p,max(.5,2.4*sc*(1-u)),color((214,185,255),200*(1-u)**1.5*opacity))
  out.alpha_composite(effects.filter(ImageFilter.GaussianBlur(max(1,6*sc))));out.alpha_composite(effects)
  for v in sorted(st['units'],key=lambda v:st['vertices'][v['id']][2] if v['id']<5 else 0):
   p=v['anchor'];alpha=v['opacity']*opacity;blend=v.get('blend',0)
   if v['kind']=='flight':
    im,off,fsc=self._fly_sprite(v);center=(p[0]-off[0],p[1]-off[1]);c0,d0=math.cos(v['heading']),math.sin(v['heading']);anchor=self.flight_manifest['pivot'];nozzles=[]
    for n in self.flight_pose['nozzles']:
     x,y=(n[0]-anchor[0])*fsc,(n[1]-anchor[1])*fsc;nozzles.append((center[0]+x*c0-y*d0,center[1]+x*d0+y*c0))
    jet=Image.new('RGBA',size);j=ImageDraw.Draw(jet);power=v['power']*(1-blend);tail=v['trail_start'];w=max(1,5*fsc)
    for noz in nozzles:
     end=add(noz,(-c0*42*fsc*power,-d0*42*fsc*power));line(j,[tail,noz],color((67,163,255),65*alpha*power),w);line(j,[noz,end],color((122,214,255),200*alpha*power),w);line(j,[noz,mix(noz,end,.57)],color((243,252,255),245*alpha*power),max(1,w*.3))
    out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(max(1,3*fsc))));out.alpha_composite(jet)
    if blend<1:self._paste(out,im,center,alpha*(1-blend))
    if blend>0:self._paste(out,self._station(v),p,alpha*blend)
   else:self._paste(out,self._station(v),p,alpha)
  return out
 @staticmethod
 def _paste(out,im,center,alpha):
  if alpha<=0:return
  if alpha<1:
   im=im.copy();im.putalpha(im.getchannel('A').point(lambda x:round(x*alpha)))
  out.alpha_composite(im,(round(center[0]-im.width/2),round(center[1]-im.height/2)))

class FieldFleet:
 """Host integration reference. Ordinary cursor remains visible and unchanged; field anchored at trigger."""
 def __init__(self,root=ROOT,enabled=True,count=0):
  self.flight=FleetFlight(root,enabled,count);self.barrier=Barrier(root);self.last=None
 def set_count(self,count):self.flight.set_count(count)
 def set_enabled(self,enabled):self.flight.set_enabled(enabled)
 def cancel(self):self.flight.cancel();self.barrier.cancel()
 def reset(self):self.flight.reset();self.barrier.cancel();self.last=None
 def down(self,t):return False if self.barrier.active_at(t) else self.flight.down(t)
 def up(self,t):return False if self.barrier.active_at(t) else self.flight.up(t)
 def trigger_special(self,t,anchor,bounds,radius=58,hold=1.4,scale=.58,opacity=.85):
  if self.last is not None and t<self.last[0]:return False
  accepted=self.barrier.trigger(t,anchor,bounds,radius,hold,scale,opacity)
  if accepted:self.flight.cancel();self.flight.fleet.reset()
  return accepted
 def update(self,t,xy,scale=.58,fixed=False,bounds=None,escorts_visible=True):
  b=tuple(bounds) if bounds is not None else None;key=(t,scale,bool(fixed),b)
  if self.last and (t<self.last[0] or t-self.last[0]>.25 or key[1:]!=self.last[1:]):self.barrier.cancel()
  if self.barrier.event and (b!=self.barrier.event['bounds'] or scale!=self.barrier.event['requested_scale']):self.barrier.cancel()
  special=self.barrier.sample(t);normal=self.flight.update(t,xy,scale,fixed,b,escorts_visible and special is None);self.last=key;return dict(normal, special=special)
 def draw(self,background,state):
  return self.flight.draw(self.barrier.draw(background,state['special']) if state['special'] is not None else background,state)
