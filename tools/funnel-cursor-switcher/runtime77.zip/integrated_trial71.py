"""Trial71 production reference. All coordinates local physical pixels; no OS hooks."""
import math
from integrated_trial70 import Integrated as Previous, ROOT
from field_trial68 import Barrier as PreviousBarrier
from field_trial66 import valid_bounds

class Barrier(PreviousBarrier):
    def region(self, size, state):
        """Conservative rectangle includes sprite rotation, trails, glow and fragments."""
        if state is None or state['opacity']==0 or state['phase']=='gap': return None
        pts=[state['center'],*state['stations']]
        for v in state['units']:
            pts.append(v['anchor'])
            if 'trail_start' in v: pts.append(v['trail_start'])
        scale=max([state['scale'],*(v['scale'] for v in state['units'])])
        pad=math.ceil(220*scale+state['radius']*.65+24)
        x0=max(0,math.floor(min(p[0] for p in pts))-pad)
        y0=max(0,math.floor(min(p[1] for p in pts))-pad)
        x1=min(size[0],math.ceil(max(p[0] for p in pts))+pad)
        y1=min(size[1],math.ceil(max(p[1] for p in pts))+pad)
        return (x0,y0,x1,y1) if x1>x0 and y1>y0 else None
    def draw(self, background, state):
        out=background.copy().convert('RGBA')
        rect=self.region(out.size,state)
        if rect is None:return out
        x,y,r,b=rect
        if rect==(0,0,*out.size):return super().draw(out,state)
        def tr(p):return (p[0]-x,p[1]-y)
        local=dict(state,center=tr(state['center']),origin=tr(state['origin']),stations=[tr(p) for p in state['stations']])
        local['units']=[dict(v,anchor=tr(v['anchor']),**({'trail_start':tr(v['trail_start'])} if 'trail_start' in v else {})) for v in state['units']]
        patch=super().draw(out.crop(rect),local)
        out.paste(patch,(x,y))
        return out

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse)
        self.barrier=Barrier(root,field_color)
    def update(self,t,xy,size=32,fixed=False,bounds=None,*,visible=True,idle_enabled=True,context=None,escorts_visible=True):
        if bounds is not None and not valid_bounds(bounds):raise ValueError('invalid bounds')
        old=self.last;held=self.held
        s=super().update(t,xy,size,fixed,bounds,visible=visible,idle_enabled=idle_enabled,context=context,escorts_visible=escorts_visible)
        if old and held and visible and old[6] and not self.held:
            self.held=True;self.idle.reset();self.mix=0.;self.idle_frame=None;s['idle_mix']=0.
        if self.flight.speed<1 and s['power']<=.065:s['power']=0.
        if s['idle_mix']>0:
            raw=s.setdefault('_raw_power',s['power']);s['power']=raw*(1-s['idle_mix'])
            if s['idle_mix']>=1:s['trail']=[]
        return s
