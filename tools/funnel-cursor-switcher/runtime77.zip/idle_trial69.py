"""Idle presentation helper for the host; never installs cursors or consumes input."""
from pathlib import Path
import math,struct
from PIL import Image
ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'trial69/assets'; NAME='フィンファンネル'
CUR=ASSETS/'カーソル/ファンネル'/f'{NAME}.cur'; SHEET=ASSETS/'飛行アニメ/ファンネル'/f'{NAME}.待機回転.png'
HEADING=-128.0; STEPS=48
class IdleSelector:
 def __init__(self,delay=.9,period=2.4,reverse=False):
  if not math.isfinite(delay) or not .1<=delay<=8 or not math.isfinite(period) or not .8<=period<=8:raise ValueError('invalid idle timing')
  self.delay=delay;self.period=period;self.reverse=bool(reverse);self.reset()
 def reset(self):self.last=None;self.still_since=None;self.held_heading=HEADING
 def update(self,t,xy,*,fixed=True,heading=HEADING,busy=False,visible=True,enabled=True,context=None):
  """xy is the actual hotspot, heading is clockwise screen degrees, busy includes mouse button/shot/special."""
  xy=tuple(xy)
  if len(xy)!=2 or not all(math.isfinite(v) for v in (t,*xy,heading)):raise ValueError('invalid input')
  previous=self.last;key=(t,xy,bool(fixed),context);self.last=key
  blocked=busy or not visible or not enabled
  changed=(previous is None or t<previous[0] or t-previous[0]>.25 or xy!=previous[1] or key[2:]!=previous[2:])
  if blocked or changed or self.still_since is None:
   self.still_since=None if blocked else t;self.held_heading=HEADING if fixed else heading
   return None
  age=t-self.still_since-self.delay
  if age<0:return None
  frame=int(math.floor(age/self.period*STEPS+1e-9))%STEPS
  return dict(step=(-frame if self.reverse else frame)%STEPS,heading=self.held_heading,hotspot=xy,mode='native_candidate' if fixed else 'overlay',angle_delta=self.held_heading-HEADING)
class IdleArt:
 def __init__(self,root=ROOT):
  root=Path(root);base=root/'trial69/assets';self.cur=(base/'カーソル/ファンネル'/f'{NAME}.cur').read_bytes();sheet=Image.open(base/'飛行アニメ/ファンネル'/f'{NAME}.待機回転.png').convert('RGBA');assert sheet.size==(6912,144);self.frames=tuple(sheet.crop((i*144,0,(i+1)*144,144)) for i in range(STEPS));self.entries={};self.cache={}
  for i in range(struct.unpack_from('<H',self.cur,4)[0]):
   w,h,_,_,hx,hy,n,o=struct.unpack_from('<BBBBHHII',self.cur,6+i*16);s=w or 256;self.entries[s]=(hx,hy,o,n)
 def normal(self,size=32):
  hx,hy,o,n=self.entries[size];im=Image.frombytes('RGBA',(size,size),self.cur[o+40:o+40+size*size*4],'raw','BGRA',0,-1);return im,(hx,hy)
 def frame(self,step,size=32):
  key=(step%STEPS,size)
  if key not in self.cache:
   pad=round(size/4);side=size+2*pad;normal,hot=self.normal(size);anchor=(hot[0]+pad,hot[1]+pad)
   if key[0]==0:
    im=Image.new('RGBA',(side,side));im.paste(normal,(pad,pad))
   else:
    # Same normalized film gate as native 32; adapt the gate for legacy size-specific hotspot.
    factor=side/144;dx=anchor[0]-30*factor;dy=anchor[1]-36*factor
    im=self.frames[key[0]].transform((side,side),Image.Transform.AFFINE,(1/factor,0,-dx/factor,0,1/factor,-dy/factor),Image.Resampling.BICUBIC)
   if len(self.cache)>=192:self.cache.clear()
   self.cache[key]=(im,anchor)
  im,anchor=self.cache[key];return im.copy(),anchor
 def overlay(self,step,size=32,heading=HEADING):
  """Return image and hotspot local to image; composite at actual hotspot minus anchor."""
  im,anchor=self.frame(step,size);delta=heading-HEADING
  if abs(delta%360)<1e-9:return im,anchor
  n=im.width*4;center=(n//2,n//2);canvas=Image.new('RGBA',(n,n));canvas.paste(im,(center[0]-anchor[0],center[1]-anchor[1]));canvas=canvas.rotate(-delta,Image.Resampling.BICUBIC,center=center);b=canvas.getbbox();assert b;return canvas.crop(b),(center[0]-b[0],center[1]-b[1])
