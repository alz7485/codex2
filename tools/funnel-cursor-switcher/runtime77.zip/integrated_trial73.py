"""Trial73: photo-matched rack and continuous, smaller barrier stations.
No OS input changes. Photo coordinates are approximate measurements of IMG_7928.
"""
from integrated_trial72 import Integrated as Previous, Barrier as PreviousBarrier, ROOT
from integrated_trial71 import Barrier as FieldDraw
from field_trial66 import clamp,smooth,color,line,mix,add,angle_mix
from PIL import Image,ImageDraw,ImageFilter
import math

# right to left: central black housing centers (photo pixels), in-plane tilt CCW.
RACK=((656,392,13.2),(606,443,9.2),(558,537,4.8),(502,546,1.0),(446,629,-2.1),(390,629,-6.4))
PHOTO_TO_SPRITE=454/740
FIELD_BODY_FACTOR=.60

class Barrier(PreviousBarrier):
    def _rack_sprite(self,shape,angle,scale):
        key=('rack73',shape,angle,round(scale,7))
        if key not in self.cache:
            raw=self._image('trial72/'+shape+'.png');w,h=raw.size
            # Housing at y~226 in both equal-scale source images. Rotate around image center.
            im=raw.resize((max(1,round(w*scale)),max(1,round(h*scale))),Image.Resampling.LANCZOS)
            a=math.radians(angle);cs,sn=math.cos(a),math.sin(a)
            def off(x,y):
                x=(x/w-.5)*im.width;y=(y/h-.5)*im.height
                return x*cs+y*sn,-x*sn+y*cs
            hp=off(w/2,226);np=off(w/2,h-1)
            rot=im.rotate(angle,Image.Resampling.BICUBIC,expand=True)
            pivot=(rot.width/2+hp[0],rot.height/2+hp[1]);nozzle=(rot.width/2+np[0],rot.height/2+np[1])
            # bounded cache across changing size / DPI
            if sum(isinstance(k,tuple) and k[0]=='rack73' for k in self.cache)>=72:
                for k in list(self.cache):
                    if isinstance(k,tuple) and k[0]=='rack73':del self.cache[k]
            self.cache[key]=(rot,pivot,nozzle)
        return self.cache[key]
    def trigger(self,*args,**kwargs):
        if not super().trigger(*args,**kwargs):return False
        e=self.event
        # Add .24s to the opening only; later hold and dissolve durations unchanged.
        e['ends']={k:v+(.24 if k in ('open','charge','link','hold','dissolve','depart') else 0) for k,v in e['ends'].items()};e['end']=e['ends']['depart']
        l,t,r,b=e['bounds'];margin=min(4,(r-l)/20,(b-t)/20)
        specs=[]
        for i,(x,y,angle) in enumerate(RACK):
            shape='straight' if i in (0,4) else 'folded'
            im,p,n=self._rack_sprite(shape,angle,1.)
            hx,hy=(x-520)*PHOTO_TO_SPRITE,(y-510)*PHOTO_TO_SPRITE
            specs.append((i,shape,angle,hx,hy,im.size,p))
        lo_x=min(x-p[0] for _,_,_,x,y,sz,p in specs);hi_x=max(x-p[0]+sz[0] for _,_,_,x,y,sz,p in specs)
        lo_y=min(y-p[1] for _,_,_,x,y,sz,p in specs);hi_y=max(y-p[1]+sz[1] for _,_,_,x,y,sz,p in specs)
        sc=min(.46*e['requested_scale'],(r-l-2*margin)/(hi_x-lo_x+8),(b-t-2*margin)/(hi_y-lo_y+8))
        ox=clamp(e['origin'][0]-(lo_x+hi_x)*sc/2,l+margin-lo_x*sc,r-margin-hi_x*sc)
        oy=clamp(e['origin'][1]-(lo_y+hi_y)*sc/2,t+margin-lo_y*sc,b-margin-hi_y*sc)
        units=[]
        for i,shape,angle,x,y,sz,p in specs:
            im,p,n=self._rack_sprite(shape,angle,sc);top=(ox+x*sc-p[0],oy+y*sc-p[1]);anchor=(top[0]+n[0],top[1]+n[1]);
            units.append(dict(id=i,shape=shape,angle=angle,top=top,size=im.size,rack_scale=sc,nozzle=n,anchor=anchor,ignition=.10+.12*i))
        e['rack_units']=units
        return True
    def sample(self,t):
        s=super().sample(t)
        if s is None:return None
        if s.get('rack_launch'):
            # Trial72's sample assumes unrotated rectangles; replace its result.
            e=self.event;age=s['age'];units=[]
            for v in e['rack_units']:
                x,y=v['top'];w,h=v['size'];elapsed=age-v['ignition'];q=clamp((elapsed-.06)/.66);dist=(y+h-e['bounds'][1]+max(18,h*.23))*q*q
                power=smooth(elapsed/.065) if q<1 else 0.
                units.append(dict(v,top=(x,y-dist),anchor=(v['anchor'][0],v['anchor'][1]-dist),power=power,progress=q,trail_length=min(95,h*.70)*power*(.30+.70*q),opacity=1. if q<1 else 0.))
            s['units']=units;return s
        for v in s['units']:
            v['scale']*=FIELD_BODY_FACTOR
            if s['phase']=='open':v['open_step']=round(12*smooth(s['u']))
            elif s['phase']=='depart':v['open_step']=round(12*(1-smooth(s['u']*2)))
            elif s['phase']=='return':
                v['open_step']=0;v['station_heading']=self.event['headings'][v['id']]
        return s
    def _station(self,v):
        p=v.get('open_step')
        if p is None or p==12:return super()._station(v)
        # Intermediate frames are actual 3D captures, not image morphs. During opening light is zero.
        im=self._image(f'trial73/poses/{v["id"]}-{p}-base.png');n=max(1,round(self.cell*v['scale']))
        return im.resize((n,n),Image.Resampling.LANCZOS)
    def draw(self,background,state):
        if not state:return super().draw(background,state)
        if state.get('rack_launch'):
            out=background.copy().convert('RGBA');opacity=state['opacity'];jet=Image.new('RGBA',out.size);d=ImageDraw.Draw(jet)
            for v in state['units']:
                p=v['power']*v['opacity']*opacity
                if p<=0:continue
                x,y=v['anchor'];length=v['trail_length'];half=max(.8,34*v['rack_scale']*.30);a=math.radians(v['angle']);dx,dy=math.sin(a),math.cos(a);nx,ny=dy,-dx
                for f,rgba in [(1.,(42,125,255,round(105*p))),(.55,(87,201,255,round(190*p))),(.24,(234,249,255,round(245*p)))]:
                    le=length if f==1 else length*(.55+.25*f);d.polygon([(x-nx*half*f,y-ny*half*f),(x+nx*half*f,y+ny*half*f),(x+dx*le,y+dy*le)],fill=rgba)
                d.ellipse((x-half,y-half,x+half,y+half),fill=(182,235,255,round(205*p)))
            out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(3)));out.alpha_composite(jet)
            for v in reversed(state['units']):
                if not v['opacity']:continue
                im,_,_=self._rack_sprite(v['shape'],v['angle'],v['rack_scale'])
                if opacity!=1:im=im.copy();im.putalpha(im.getchannel('A').point(lambda a:round(a*opacity)))
                out.alpha_composite(im,tuple(round(a) for a in v['top']))
            return out
        if state['phase']=='return':
            # Use the same projected closed model on approach and at the first opening frame.
            # The old flight-to-station crossfade caused a visible silhouette swap.
            out=background.copy().convert('RGBA');jet=Image.new('RGBA',out.size);d=ImageDraw.Draw(jet)
            for v in state['units']:
                p=v['anchor'];power=v['power'];alpha=v['opacity']*state['opacity'];h=v['heading'];tail=v['trail_start'];w=max(1,3*v['scale'])
                if power>0:
                    end=add(p,(-math.cos(h)*35*v['scale']*power,-math.sin(h)*35*v['scale']*power));line(d,[tail,p],color((67,163,255),65*alpha*power),w);line(d,[p,end],color((122,214,255),200*alpha*power),w);line(d,[p,mix(p,end,.57)],color((243,252,255),245*alpha*power),max(1,w*.3))
            out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(2)));out.alpha_composite(jet)
            for v in sorted(state['units'],key=lambda v:state['vertices'][v['id']][2]):
                im=self._station(v);delta=(v['heading']-v['station_heading']+math.pi)%(2*math.pi)-math.pi
                if abs(delta)>1e-6:im=im.rotate(-math.degrees(delta),Image.Resampling.BICUBIC,expand=True)
                self._paste(out,im,v['anchor'],v['opacity']*state['opacity'])
            return out
        return FieldDraw.draw(self,background,state)

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse);self.barrier=Barrier(root,field_color)
