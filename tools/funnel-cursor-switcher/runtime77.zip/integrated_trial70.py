"""Hotspot-aligned overlay reference. Never changes or consumes OS input.
All coordinates in physical pixels local to the draw surface. Old centre API remains untouched.
"""
import math
from pathlib import Path
from PIL import Image
import numpy as np
from flight_trial62 import Flight,wrap,normalized,clamp
from fire_trial64 import FireFlight
from escort_trial65 import EscortFleet,inside,PARAMS
from field_trial68 import FieldFleet as Previous,Barrier
from idle_trial69 import IdleArt,IdleSelector,HEADING
from primary_fire_trial63 import smooth
ROOT=Path(__file__).resolve().parent

class SeparationFleet(EscortFleet):
 def _target(self,i,t,xy,scale,bounds):
  p=super()._target(i,t,xy,scale,bounds)
  ratio,lag,radius,offset,w,period,life=PARAMS[i]
  gap=185*scale;pair=160*scale;r=110*scale*ratio
  # Also check projected neighbours and the primary, not only whether a preferred station fits.
  others=[(s[0]+s[2]*.16,s[1]+s[3]*.16) for j,s in enumerate(self.members) if j!=i]
  current=self.members[i][:2] if i<len(self.members) else p
  if math.dist(p,xy)>=gap and all(math.dist(p,o)>=pair for o in others):return p
  a=math.atan2(p[1]-xy[1],p[0]-xy[0]);rad=max(radius*scale,math.dist(p,xy))
  candidates=[p]
  for ring in (1.,1.22):
   for k in range(16):
    ang=a+k*math.tau/16
    c=inside((xy[0]+rad*ring*math.cos(ang),xy[1]+rad*ring*math.sin(ang)),bounds,r)
    candidates.append(c)
  def score(c):
   return math.dist(c,p)**2+.24*math.dist(c,current)**2+14*max(0,gap-math.dist(c,xy))**2+8*sum(max(0,pair-math.dist(c,o))**2 for o in others)
  return min(candidates,key=score)

def alpha_blend(a,b,u):
 """Premultiplied interpolation prevents dark outlines around transparent sprites."""
 return Image.blend(a.convert('RGBa'),b.convert('RGBa'),u).convert('RGBA')

class AlignedFlight(FireFlight):
 def __init__(self,root,enabled=True,count=0):
  super().__init__(root,enabled);self.fleet=SeparationFleet(root,count);self.art=IdleArt(root);self.sizes={}
 def reset(self):
  super().reset()
  if hasattr(self,'fleet'):self.fleet.reset()
 def set_count(self,count):self.fleet.set_count(count)
 def size_scale(self,size):
  if size not in self.sizes:
   im,hot=self.art.normal(size);a=np.asarray(im.getchannel('A'));y,x=np.where(a>=64);ang=math.radians(HEADING);proj=x*math.cos(ang)+y*math.sin(ang)
   pose=self.poses[(0,0)];base=Image.open(self.root/'poses'/f"{pose['stem']}_base.png");aa=np.asarray(base.getchannel('A'));yy,xx=np.where(aa>=64)
   self.sizes[size]=float((proj.max()-proj.min()+1)/(xx.max()-xx.min()+1))
  return self.sizes[size]
 def update(self,t,hotspot,scale,fixed=False,bounds=None,escorts_visible=True):
  # Derive motion from physical hotspot, NOT from shifting rendered body centre.
  st=Flight.update(self,t,hotspot,scale,fixed);h=math.radians(HEADING) if fixed else st['heading'];cs,sn=math.cos(h),math.sin(h);pose=self.poses[(st['pitch'],st['roll'])];cp=self.charge_poses[st['pose']];fx,fy=pose['front'];cx,cy=self.manifest['pivot']
  def tr(p):
   x,y=(p[0]-fx)*scale,(p[1]-fy)*scale;return (hotspot[0]+x*cs-y*sn,hotspot[1]+x*sn+y*cs)
  nozzles=[tr(p) for p in pose['nozzles']];mid=tuple(sum(p[j] for p in nozzles)/len(nozzles) for j in (0,1));rear=tr(pose['rear_direction'])
  if self.history and self.history[-1][0]==t:self.history[-1]=(t,mid,st['power'])
  st.update(hotspot=tuple(hotspot),xy=tr((cx,cy)),heading=h,front=tuple(hotspot),nozzles=nozzles,rear=normalized((rear[0]-mid[0],rear[1]-mid[1])),trail=list(self.history),grid=tr(cp['grid']),holes=[tr(p) for p in cp['holes']],channel=[tr(p) for p in cp['channel']])
  direction=normalized((hotspot[0]-st['grid'][0],hotspot[1]-st['grid'][1]));st['shots']=self.fire.sample(t,dict(muzzle=st['front'],beam_heading=math.atan2(direction[1],direction[0]),scale=scale)) if self.enabled else []
  st['charge']=max((s['power'] for s in st['shots'] if s['stage']=='charge'),default=0.)
  st['flash']=max((s['power']*max(0,1-math.dist(s['origin'],st['front'])/max(1,30*scale))*max(0,1-s['age']/.18) for s in st['shots'] if s['stage']!='charge'),default=0.)
  st['escorts']=self.fleet.update(t,st['xy'],scale,bounds,escorts_visible);return st
 def body(self,state):
  flight=super().body(state);u=state.get('idle_mix',0.)
  if u<=0:return flight
  idle,anchor=self.art.overlay(state['idle_step'],state['cursor_size'],state['idle_heading']);x,y=state['xy'];hx,hy=state['front'];dx,dy=hx-x,hy-y
  # A symmetric canvas keeps Flight.draw's body-centre convention valid.
  half=math.ceil(max(flight.width/2,flight.height/2,abs(dx-anchor[0]),abs(dx-anchor[0]+idle.width),abs(dy-anchor[1]),abs(dy-anchor[1]+idle.height)))+2
  n=2*half;a=Image.new('RGBA',(n,n));b=a.copy();a.alpha_composite(flight,(half-round(flight.width/2),half-round(flight.height/2)));b.alpha_composite(idle,(round(half+dx-anchor[0]),round(half+dy-anchor[1])))
  return alpha_blend(a,b,u)
 def draw(self,background,state):
  return super().draw(self.fleet.draw(background,state['escorts']) if state['escorts'] else background,state)

class Integrated(Previous):
 """Host passes actual hotspot, native cursor size, optional context token and bounds.
 Use overlay as the sole visible primary. Field scale is independent of native size.
 """
 def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
  self.flight=AlignedFlight(root,enabled,count);self.barrier=Barrier(root,field_color);self.idle=IdleSelector(delay,period,reverse);self.last=None;self.mix=0.;self.idle_frame=None;self.held=False
 def reset(self):
  super().reset();self.idle.reset();self.mix=0.;self.idle_frame=None;self.held=False;self._invalidate()
 def _invalidate(self):
  if hasattr(self,'result'):del self.result
 def set_count(self,count):super().set_count(count);self._invalidate()
 def set_enabled(self,enabled):super().set_enabled(enabled);self._invalidate()
 def cancel(self):
  super().cancel();self.held=False;self.idle.reset();self.mix=0.;self.idle_frame=None;self._invalidate()
 def down(self,t):self.held=True;self._invalidate();return super().down(t)
 def up(self,t):self.held=False;self._invalidate();return super().up(t)
 def trigger_special(self,t,anchor,bounds,radius=58,hold=1.4,scale=.58,opacity=.85):
  accepted=super().trigger_special(t,anchor,bounds,radius,hold,scale,opacity)
  if accepted:self._invalidate()
  return accepted
 def update(self,t,xy,size=32,fixed=False,bounds=None,*,visible=True,idle_enabled=True,context=None,escorts_visible=True):
  xy=tuple(xy);b=tuple(bounds) if bounds is not None else None
  if size not in self.flight.art.entries:raise ValueError('unsupported CUR size')
  if len(xy)!=2 or not all(math.isfinite(v) for v in (t,*xy)):raise ValueError('invalid input')
  key=(t,xy,size,bool(fixed),b,context,bool(visible),bool(idle_enabled),bool(escorts_visible));old=self.last
  if old==key and hasattr(self,'result'):return self.result
  if old and (t<old[0] or t-old[0]>.25 or math.dist(xy,old[1])>500 or key[2:7]!=old[2:7] or (t==old[0] and xy!=old[1])):self.reset();old=None
  dt=t-old[0] if old else 0.
  if self.barrier.event and b!=self.barrier.event['bounds']:self.barrier.cancel()
  if not visible:self.cancel();self.flight.reset()
  special=self.barrier.sample(t) if visible else None
  st=self.flight.update(t,xy,self.flight.size_scale(size),fixed,b,visible and escorts_visible and special is None)
  decision=self.idle.update(t,xy,fixed=fixed,heading=math.degrees(st['heading']),busy=self.held or bool(st['shots']) or special is not None,visible=visible,enabled=idle_enabled,context=(size,b,context))
  if decision is not None:self.idle_frame=decision
  if not idle_enabled or not visible or special is not None:self.mix=0.;self.idle_frame=None
  else:self.mix=clamp(self.mix+dt/(.16 if decision is not None else .12)*(1 if decision is not None else -1),0,1)
  if self.mix==0 and decision is None:self.idle_frame=None
  frame=self.idle_frame or {'step':0,'heading':math.degrees(st['heading'])}
  st.update(special=special,visible=visible,cursor_size=size,idle_mix=smooth(self.mix),idle_step=frame['step'],idle_heading=frame['heading']);self.last=key;self.result=st;return st
 def draw(self,background,state):
  if not state['visible']:return background.copy().convert('RGBA')
  return super().draw(background,state)
