"""Trial77: final field presentation. All geometry and input control unchanged."""
import math
from PIL import Image
from integrated_trial76 import Integrated as Previous, Barrier as PreviousBarrier, ROOT
from integrated_trial71 import Barrier as RegionDraw
from field_trial66 import clamp,smooth
from field_render77 import draw_stationary

class Barrier(PreviousBarrier):
    def sample(self,t):
        s=super().sample(t)
        if s and s['phase'] in ('link','hold','dissolve'):
            e=self.event;elapsed=s['age']-e['ends']['charge']
            envelope=smooth(elapsed/.22)*(1-smooth((s['age']-e['ends']['hold'])/(e['ends']['dissolve']-e['ends']['hold'])))
            for v in s['units']:
                i=v['id'];v['rock_deg']=2.2*envelope*math.sin(math.tau*(.72+i*.065)*elapsed+i*1.7)
        return s
    def draw(self,background,state):
        if not state or state['phase'] not in ('open','charge','link','hold','dissolve'):
            return super().draw(background,state)
        out=background.copy().convert('RGBA');rect=RegionDraw.region(self,out.size,state)
        if rect is None:return out
        x,y,r,b=rect
        # Keep the crop origin even: Python round() ties must match full-frame sprite placement.
        x-=x%2;y-=y%2;rect=(x,y,r,b)
        def tr(p):return p[0]-x,p[1]-y
        local=dict(state,center=tr(state['center']),origin=tr(state['origin']),stations=[tr(p) for p in state['stations']],units=[dict(v,anchor=tr(v['anchor'])) for v in state['units']])
        out.paste(draw_stationary(self,out.crop(rect),local),(x,y));return out

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse);self.barrier=Barrier(root,field_color)
