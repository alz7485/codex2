"""Trial76: staggered settling, mechanical opening and readable field lighting.
Rack and all normal input behavior remain unchanged. No OS hooks.
"""
from integrated_trial75 import Integrated as Previous, Barrier as PreviousBarrier, ROOT, curve, point, tangent, easing
from field_trial66 import clamp,smooth,mix,add,angle_mix,exit_point
from integrated_trial71 import Barrier as RegionDraw
import math
from field_render76 import draw_stationary

# Arrival times separated without changing the phase duration or vertex layout.
DELAYS=(.00,.115,.055,.165,.085)
SETTLE=(.115,.065,.095,.045,.075)
OPEN_DELAY=(0,.045,.022,.065,.036)
PRECHARGE=.24

def mechanical(x):
    # Continuous velocity at the intermediate hinge detent, no pose reset.
    x=clamp(x)
    if x<.42:return .36*smooth(x/.42)
    return .36+.64*smooth((x-.42)/.58)

class Barrier(PreviousBarrier):
    def sample(self,t):
        s=super().sample(t)
        if s is None:return None
        e=self.event;phase=s['phase'];u=s['u']
        if phase=='return':
            duration=e['ends']['return']-e['ends']['gap']
            for v in s['units']:
                i=v['id'];elapsed=u*duration-DELAYS[i];travel=duration-DELAYS[i]-SETTLE[i];x=clamp(elapsed/travel);q=easing(x);c=e['return_curves'][i]
                v['anchor']=point(c,q);v['trail_start']=point(c,easing((elapsed-.085)/travel));dx,dy=tangent(c,q);h=e['headings'][i]
                v['heading']=angle_mix(math.atan2(dy,dx),h,smooth((x-.76)/.24));v['station_heading']=h
                v['power']=clamp(30*x*x*(1-x)**2/1.875)*(1-smooth((x-.70)/.30));v['return_progress']=x
        elif phase=='open':
            for v in s['units']:
                i=v['id'];d=OPEN_DELAY[i];q=mechanical((u-d)/(1-d));v['pose_float']=12*q
                v['light']=PRECHARGE*smooth((q-.25)/.75)
        elif phase=='depart':
            for v in s['units']:
                i=v['id'];p=e['stations'][i];h=e['headings'][i];d=(i%3)*.035
                q=clamp((u-d)/(1-d));v['pose_float']=12*(1-mechanical(q/.30))
                turn=smooth((q-.30)/.25);v['heading']=h+math.pi*turn;v['station_heading']=h
                x=clamp((q-.55)/.45);dest=exit_point(p,(-math.cos(h),-math.sin(h)),e['bounds'],192*e['scale']+16)
                v['anchor']=mix(p,dest,x*x);v['trail_start']=mix(p,dest,max(0,x-.10)**2)
                v['power']=smooth(x/.24);v['opacity']=1-smooth((x-.82)/.18)
        return s

    def _light(self,v,st):
        # Same phase of pulse through opening -> charge. Dissolve envelope already in state.
        return clamp(v['light']*(.90+.10*math.sin(st['age']*math.tau*2.3-v['id']*.68)))

    def draw(self,background,state):
        if not state or state['phase'] not in ('open','charge','link','hold','dissolve'):
            return super().draw(background,state)
        out=background.copy().convert('RGBA');rect=RegionDraw.region(self,out.size,state)
        if rect is None:return out
        x,y,r,b=rect
        def tr(p):return p[0]-x,p[1]-y
        local=dict(state,center=tr(state['center']),origin=tr(state['origin']),stations=[tr(p) for p in state['stations']],units=[dict(v,anchor=tr(v['anchor'])) for v in state['units']])
        out.paste(draw_stationary(self,out.crop(rect),local),(x,y));return out

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse);self.barrier=Barrier(root,field_color)
