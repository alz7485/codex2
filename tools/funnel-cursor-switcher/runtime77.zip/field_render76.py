"""Stationary field renderer derived from Trial68; visual only."""
from field_trial68 import tint, triangles
from field_trial66 import EDGES,FACES,COLOR,clamp,smooth,mix,add,mul,unit,color,dot,line
from PIL import Image,ImageDraw,ImageFilter
import math

def draw_stationary(self,background,state):
 if state is None:return background.copy().convert('RGBA')
 out=background.copy().convert('RGBA');size=out.size;st=state;age=st['age'];sc=st['scale'];opacity=st['opacity'];pts=st['stations'];fa=st['field_alpha'];ep=st['edge_progress'];phase=st['phase'];u=st['u'];c=st.get('field_color',self.field_color)
 def field_color(col,alpha):return color(tint(col,c),alpha)
 if opacity==0:return out
 # Projected triangular lattice. Each cell lies within its own face before dissolution.
 if fa>0 or phase=='dissolve':
  faces=sorted(FACES,key=lambda face:sum(st['vertices'][i][2] for i in face))
  for k,face in enumerate(faces):
   a,b,p=[pts[i] for i in face];layer=Image.new('RGBA',size);d=ImageDraw.Draw(layer)
   pulse=.88+.12*math.sin(age*math.tau*2.3+k*.85)
   depth=(.29,.43,.70,.92)[k]
   if phase!='dissolve':
    d.polygon([a,b,p],fill=field_color((125+12*k,76+9*k,245),(20+4*k)*fa*pulse*opacity*depth))
    for j in range(1,9):
     q=j/9
     for A,B,C in ((a,b,p),(b,p,a),(p,a,b)):
      line(d,[mix(A,B,q),mix(A,C,q)],field_color((188,148,255),12*fa*opacity*depth),max(1,sc*.7))
    for j in range(3):
     q=(age*.95+j/3+k*.075)%1;strength=math.sin(math.pi*q)**.8*fa*opacity
     A,B=mix(p,a,q),mix(p,b,q)
     line(d,[A,B],field_color((178,121,255),33*strength*depth),max(1,7*sc))
     line(d,[A,B],field_color((231,210,255),103*strength*depth),max(1,1.4*sc))
     for m in range(3):
      v=(age*.7+m/3+k*.17)%1;dot(d,mix(A,B,v),max(.6,1.9*sc),field_color((244,234,255),125*strength*depth))
   # 36 deterministic triangles per face: bright cells during hold, peeling fragments during dissolve.
   for idx,tri in enumerate(triangles(a,b,p,6)):
    center=tuple(sum(v[j] for v in tri)/3 for j in (0,1));seed=(idx*37+k*59)%101/101
    if phase=='dissolve':
     progress=clamp((u-seed*.25)/.75);direction=unit((center[0]-st['center'][0],center[1]-st['center'][1]));offset=mul(direction,st['radius']*.38*progress**1.7);ang=(seed-.5)*2.1*progress
     cs,sn=math.cos(ang),math.sin(ang);shrink=1-.78*progress
     poly=[add(add(center,offset),((v[0]-center[0])*cs*shrink-(v[1]-center[1])*sn*shrink,(v[0]-center[0])*sn*shrink+(v[1]-center[1])*cs*shrink)) for v in tri]
     alpha=opacity*(1-progress)**1.5
     if alpha>0:d.polygon(poly,fill=field_color((163,112,255),44*alpha),outline=field_color((227,202,255),85*alpha))
    else:
     wave=max(0,math.sin(age*5.2+idx*.73+k*1.4))**6
     if wave>.12:d.polygon(tri,fill=field_color((192,151,255),35*wave*fa*opacity*depth))
   out.alpha_composite(layer)
 effects=Image.new('RGBA',size);d=ImageDraw.Draw(effects)
 # Eight edges including four base edges. Each starts at an emitter; no triangles fabricated in screen space.
 if ep>0:
  fade=1-smooth(u) if phase=='dissolve' else 1.
  for j,(a,b) in enumerate(EDGES):
   pa,pb=pts[a],pts[b];q=smooth((ep-j*.045)/.685) if phase=='link' else 1.;end=mix(pa,pb,q)
   if q<=0:continue
   for width,alpha,col in [(10,30,COLOR),(4.5,88,COLOR),(1.7,208,(236,219,255))]:line(d,[pa,end],field_color(col,alpha*opacity*fade),width*sc)
   # Segmented electrical filament follows the connected portion of the actual edge.
   direction=unit((pb[0]-pa[0],pb[1]-pa[1]));normal=(-direction[1],direction[0]);arc=[]
   for n in range(13):
    h=n/12;w=math.sin(math.pi*h)*math.sin(age*math.tau*11+j*2.1+n*3.8)*min(3.5*sc,st['radius']*.025)
    arc.append(add(mix(pa,end,h),mul(normal,w)))
   line(d,arc,field_color((235,214,255),155*opacity*fade),max(1,sc*1.25))
   # A short packet of light travels from an emitter along the edge.
   v=(age*2.2+j*.093)%1;head=min(v,q);tail=max(0,head-.16)
   if v<q and head>tail:
    line(d,[mix(pa,pb,tail),mix(pa,pb,head)],field_color((255,248,255),235*opacity*fade),max(1,2.6*sc))
   for k in range(2):
    v=(age*1.65+j*.137+k*.5)%1
    if v<q:dot(d,mix(pa,pb,v),max(1,2.6*sc),field_color((250,242,255),215*opacity*fade))
 if phase in ('open','charge','link','hold','dissolve'):
  for v in st['units']:
   p=v['anchor'];power=self._light(v,st);bs=v['scale'];rr=(4.4+1.2*math.sin(age*math.tau*7+v['id']))*bs*power;dot(d,p,max(0,rr*2.2),color(c,48*power*opacity));dot(d,p,max(0,rr),field_color((249,238,255),210*power*opacity))
   for j in range(7):
    q=(age*2.7+j/7)%1;ang=j*2.39996+age*3+v['id'];r=(20*(1-q)+3)*bs;dot(d,add(p,(r*math.cos(ang),r*math.sin(ang))),max(.6,1.35*bs),field_color((218,190,255),185*power*opacity*math.sin(math.pi*q)))
  if phase=='link':
   rr=st['radius']*.75*smooth(u);p=st['center'];d.ellipse((p[0]-rr,p[1]-rr*.72,p[0]+rr,p[1]+rr*.72),outline=field_color((208,166,255),100*math.sin(math.pi*u)*opacity),width=max(1,round(2*sc)))
 # A local formation flash, not a full-screen whiteout. Continuous through link -> hold.
 flash_age=u*st['hold'] if phase=='hold' else 99
 if 0<=flash_age<.20:
  f=smooth(flash_age/.025)*math.exp(-((flash_age-.035)/.052)**2)*opacity
  for p in pts:
   dot(d,p,max(1,7*sc*f),field_color((225,201,255),90*f));dot(d,p,max(1,2.5*sc*f),field_color((255,250,255),245*f))
  for a,b in EDGES:line(d,[pts[a],pts[b]],field_color((250,240,255),135*f),max(1,3.2*sc))
  center=st['center'];rr=st['radius']*(.18+.95*clamp(flash_age/.20));d.ellipse((center[0]-rr,center[1]-.72*rr,center[0]+rr,center[1]+.72*rr),outline=field_color((220,191,255),125*f),width=max(1,round(2.5*sc)))
 if phase=='dissolve':
  for j,(a,b) in enumerate(EDGES):
   for k in range(6):
    q=(k+.5)/6;p=mix(pts[a],pts[b],q);direction=unit((p[0]-st['center'][0],p[1]-st['center'][1]));p=add(p,mul(direction,st['radius']*.28*u*u));dot(d,p,max(.5,2.4*sc*(1-u)),field_color((214,185,255),200*(1-u)**1.5*opacity))
 out.alpha_composite(effects.filter(ImageFilter.GaussianBlur(max(1,4*sc))));out.alpha_composite(effects)
 for v in sorted(st['units'],key=lambda v:st['vertices'][v['id']][2]):
  v=dict(v,light=.68*self._light(v,st),field_color=c)
  self._paste(out,self._station(v),v['anchor'],v['opacity']*opacity)
 return out

