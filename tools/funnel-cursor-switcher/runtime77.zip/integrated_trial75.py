"""Trial75: curved return, settled arrival and early color-linked ignition.
Preserve rack, field dimensions, body scale and normal cursor behavior.
"""
from integrated_trial74 import Integrated as Previous, Barrier as PreviousBarrier, ROOT
from field_trial66 import clamp,smooth,mix,add,angle_mix
from PIL import Image
import math
import numpy as np

DELAYS=(.00,.10,.055,.145,.075)
BENDS=(1,-1,1,-1,1)
PRECHARGE=.24

def curve(a,b,h,radius,sign):
    d=math.dist(a,b);n=(-math.sin(h),math.cos(h));f=(math.cos(h),math.sin(h))
    offset=min(.20*d,.55*radius)*sign
    c1=add(mix(a,b,.27),(n[0]*offset,n[1]*offset))
    c2=add(b,(-f[0]*d*.23,-f[1]*d*.23))
    return a,c1,c2,b

def point(c,q):
    a,b,d,e=c;u=1-q
    return tuple(u**3*a[i]+3*u*u*q*b[i]+3*u*q*q*d[i]+q**3*e[i] for i in (0,1))

def tangent(c,q):
    a,b,d,e=c;u=1-q
    return tuple(3*u*u*(b[i]-a[i])+6*u*q*(d[i]-b[i])+3*q*q*(e[i]-d[i]) for i in (0,1))

def easing(x):
    x=clamp(x);return x*x*x*(10+x*(-15+6*x))

class Barrier(PreviousBarrier):
    def trigger(self,*args,**kwargs):
        if not super().trigger(*args,**kwargs):return False
        e=self.event
        e['ends']={k:v+(.28 if k not in ('launch','gap') else 0) for k,v in e['ends'].items()};e['end']=e['ends']['depart']
        e['return_curves']=[curve(a,b,h,e['radius'],BENDS[i]) for i,(a,b,h) in enumerate(zip(e['entry'],e['stations'],e['headings']))]
        return True

    def sample(self,t):
        s=super().sample(t)
        if s is None:return None
        e=self.event;phase=s['phase'];u=s['u']
        if phase=='return':
            duration=e['ends']['return']-e['ends']['gap']
            for v in s['units']:
                i=v['id'];delay=DELAYS[i];travel=duration-delay-.065
                elapsed=u*duration-delay;x=clamp(elapsed/travel);q=easing(x);c=e['return_curves'][i]
                v['anchor']=point(c,q);v['trail_start']=point(c,easing((elapsed-.085)/travel));dx,dy=tangent(c,q)
                h=e['headings'][i];v['heading']=angle_mix(math.atan2(dy,dx),h,smooth((x-.79)/.21));v['station_heading']=h
                v['power']=clamp(30*x*x*(1-x)**2/1.875)*(1-smooth((x-.72)/.28));v['blend']=0.;v['open_step']=0
                v['return_progress']=x
        elif phase=='open':
            for v in s['units']:
                v['light']=PRECHARGE*smooth((v['pose_float']-3)/9)
        elif phase=='charge':
            for v in s['units']:v['light']=PRECHARGE+(1-PRECHARGE)*smooth(u)
        return s

    def _station(self,v):
        f=v.get('pose_float');light=v.get('light',0)
        if f is None or light<=0:return super()._station(v)
        f=clamp(f,0,12);a=math.floor(f);b=min(12,a+1);u=f-a
        target=v.get('field_color',(168,117,255))
        def frame(i):
            data=dict(v,open_step=i,pose=3 if i==12 else v.get('pose',0),light=light)
            data.pop('pose_float',None)
            if i==12:return super(Barrier,self)._station(data)
            base=super(Barrier,self)._station(dict(data,light=0))
            # Radial illumination inside the silhouette only, used for intermediate captures.
            arr=np.asarray(base).copy();n=base.width;yy,xx=np.ogrid[:n,:n];r2=((xx+.5-n/2)**2+(yy+.5-n/2)**2)/max(1,(n*.19)**2)
            weight=np.exp(-r2)*light*.53
            rgb=arr[:,:,:3].astype(np.float32);rgb+=(255-rgb)*weight[:,:,None]*np.asarray(target,dtype=np.float32)/255
            arr[:,:,:3]=np.clip(np.rint(rgb),0,255).astype(np.uint8)
            return Image.fromarray(arr,'RGBA')
        im=frame(a)
        if b==a or u<1e-8:return im
        return Image.blend(im.convert('RGBa'),frame(b).convert('RGBa'),u).convert('RGBA')

    def draw(self,background,state):
        if state and state['phase']=='open':
            # Reuse charge particles/core in the same field color as the following phase.
            return super().draw(background,dict(state,phase='charge'))
        return super().draw(background,state)

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse);self.barrier=Barrier(root,field_color)
