"""Fin Funnel visual-only firing, with actual 3D lighting captures. No mouse hooks.
Coordinates are body centre, not Windows hotspot; see START-HERE.
"""
import math,json
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
from flight_trial62 import Flight,clamp,normalized
from primary_fire_trial63 import PrimaryFire,MIN_CHARGE,FIRE,AFTER,smooth

class FireFlight(Flight):
 def __init__(self,root,enabled=True):
  self.project=Path(root);self.fire=PrimaryFire();self.enabled=bool(enabled);self.charge_cache={};self.charge_manifest=json.loads((self.project/'trial63/charge_manifest.json').read_text(encoding="utf-8"));self.charge_poses={p['stem']:p for p in self.charge_manifest['poses']};super().__init__(self.project/'trial62')
 def reset(self):
  super().reset();self.fire.cancel()
 def set_enabled(self,enabled):
  if bool(enabled)!=self.enabled:self.fire.cancel();self.enabled=bool(enabled)
 def down(self,t):return self.enabled and self.fire.down(t)
 def up(self,t):return self.enabled and self.fire.up(t)
 def cancel(self):self.fire.cancel()
 def update(self,t,xy,scale=.58,fixed=False):
  st=super().update(t,xy,scale,fixed);pose=self.charge_poses[st['pose']];h=st['heading'];cs,sn=math.cos(h),math.sin(h);cx,cy=self.charge_manifest['pivot']
  def trans(p):
   x,y=(p[0]-cx)*scale,(p[1]-cy)*scale;return (xy[0]+x*cs-y*sn,xy[1]+x*sn+y*cs)
  st['grid']=trans(pose['grid']);st['holes']=[trans(p) for p in pose['holes']];st['channel']=[trans(p) for p in pose['channel']]
  direction=normalized((st['front'][0]-st['grid'][0],st['front'][1]-st['grid'][1]));heading=math.atan2(direction[1],direction[0]);st['shots']=self.fire.sample(t,dict(muzzle=st['front'],beam_heading=heading,scale=scale)) if self.enabled else []
  st['charge']=max((s['power'] for s in st['shots'] if s['stage']=='charge'),default=0.)
  # Existing shots stay in world space; only a recent shot close to the body illuminates it.
  st['flash']=max((s['power']*max(0,1-math.dist(s['origin'],st['front'])/max(1,30*scale))*max(0,1-s['age']/.18) for s in st['shots'] if s['stage']!='charge'),default=0.)
  return st
 def body(self,state):
  power=clamp(max(state.get('charge',0),state.get('flash',0)),0,1)
  if power==0:return super().body(state)
  name=state['pose'];ims=self.cache.get(name)
  if ims is None:
   ims=tuple(Image.open(self.root/'poses'/f'{name}_{s}.png').convert('RGBA') for s in ('base','lit'));self.cache[name]=ims
  ch=self.charge_cache.get(name)
  if ch is None:
   ch=tuple(Image.open(self.project/'trial63/poses'/f'{name}_{s}.png').convert('RGBA') for s in ('charge','charge_lit'));self.charge_cache[name]=ch
  thrust=clamp(state['power'],0,1);base=Image.blend(*ims,thrust);lit=Image.blend(*ch,thrust);im=Image.blend(base,lit,power);im.putalpha(base.getchannel('A'));n=max(1,round(im.width*state['scale']));return im.resize((n,n),Image.Resampling.LANCZOS).rotate(-math.degrees(state['heading']),resample=Image.Resampling.BICUBIC,expand=True)
 def draw(self,background,state):
  if not state['shots']:return super().draw(background,state)
  bg=background.copy().convert('RGBA');layer=Image.new('RGBA',bg.size);d=ImageDraw.Draw(layer);t=state['t'];sc=state['scale'];p=state['charge'];grid=state['grid'];front=state['front'];ux,uy=normalized((front[0]-grid[0],front[1]-grid[1]));nx,ny=-uy,ux
  def q(o,a,b):return (o[0]+ux*a+nx*b,o[1]+uy*a+ny*b)
  def dot(draw,pt,r,col):
   x,y=pt;draw.ellipse((x-r,y-r,x+r,y+r),fill=col)
  if p>0:
   # A flowing channel field lies behind the opaque armor (actual body occludes it).
   length=math.dist(grid,front);puls=.9+.1*math.sin(t*math.tau*9)
   d.line([q(grid,2*sc,0),q(grid,length*.97,0)],fill=(111,90,255,round(45*p)),width=max(1,round(20*sc*p)))
   for i in range(16):
    u=(t*1.85+i/16)%1;angle=t*11+i*2.399;off=math.sin(angle)*(10*(1-u)+2)*sc;point=q(grid,length*u,off);tail=q(grid,max(0,length*u-11*sc),off+1.4*sc);a=round(195*p*min(1,u*8));d.line([tail,point],fill=(143,160,255,a),width=max(1,round(1.9*sc)));dot(d,point,max(.7,1.4*sc),(224,239,255,a))
   dot(d,grid,6*sc*p,(154,146,255,round(190*p)));dot(d,grid,2.7*sc*p,(242,247,255,round(240*p)))
   dot(d,front,5*sc*p*puls,(171,150,255,round(175*p)));dot(d,front,2.1*sc*p,(255,250,255,round(245*p)))
  bg.alpha_composite(layer.filter(ImageFilter.GaussianBlur(max(1,3.3*sc))));bg.alpha_composite(layer)
  im=super().draw(bg,state)
  # Each ray uses the world-space origin and projected firing direction frozen at emission.
  shots=Image.new('RGBA',im.size);d=ImageDraw.Draw(shots)
  for s in state['shots']:
   if s['stage']=='charge':continue
   a=s['age'];power=s['power'];o=s['origin'];ss=s['scale'];h=s['heading'];vx,vy=math.cos(h),math.sin(h);px,py=-vy,vx
   def b(l,w=0):return (o[0]+vx*l+px*w,o[1]+vy*l+py*w)
   length=220*ss;end=length*smooth(a/.040);start=length*smooth((a-FIRE)/AFTER) if a>FIRE else 0
   if end>start:
    for wid,color in [(22,(118,72,255,85)),(11,(156,122,255,185)),(5,(225,202,255,235)),(2,(255,251,255,255))]:
     d.line([b(start),b(end)],fill=(*color[:3],round(color[3]*power)),width=max(1,round(wid*ss*max(.25,power))))
    dot(d,b(end),max(1,3.5*ss*power),(245,234,255,round(235*power)))
   if a<.15:
    k=a/.15;radius=(5+23*k)*ss;alpha=round(185*(1-k));pts=[b(5*ss+math.cos(j*math.tau/48)*radius*.30,math.sin(j*math.tau/48)*radius) for j in range(49)];d.line(pts,fill=(190,168,255,alpha),width=max(1,round(2*ss)))
    dot(d,o,max(1,9*ss*(1-k)),(240,231,255,alpha));dot(d,o,max(1,4*ss*(1-k)),(255,255,255,alpha))
  im.alpha_composite(shots.filter(ImageFilter.GaussianBlur(max(1,3*sc))));im.alpha_composite(shots);return im
