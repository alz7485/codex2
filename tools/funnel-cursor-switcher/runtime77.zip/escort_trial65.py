"""Independent visual escorts. No input hooks, firing or changes to primary state."""
import math
from collections import deque
from pathlib import Path
from PIL import Image
from flight_trial62 import Flight, clamp, wrap, normalized
from fire_trial64 import FireFlight as Primary

PARAMS=((.68,.08,220,-1.05,6.8,2.9,.34),(.61,.16,265,1.05,5.8,3.7,.40),(.54,.24,300,0.,4.9,4.6,.47))

def limit(x,y,m):
 n=math.hypot(x,y);return (x*m/n,y*m/n) if n>m else (x,y)

def inside(p,b,r):
 if b is None:return tuple(p)
 l,t,hx,hy=b
 return (clamp(p[0],min(l+r,(l+hx)/2),max(hx-r,(l+hx)/2)),clamp(p[1],min(t+r,(t+hy)/2),max(hy-r,(t+hy)/2)))

class EscortFleet:
 def __init__(self,root,count=3):
  self.root=Path(root);self.count=0;self.set_count(count)
 def set_count(self,count):
  if type(count) is not int or not 0<=count<=3:raise ValueError('escort count must be 0..3')
  if count!=self.count or not hasattr(self,'flights'):
   self.count=count;self.flights=[Flight(self.root/'trial62') for _ in range(count)];self.reset()
 def reset(self):
  self.last=None;self.hist=deque(maxlen=128);self.members=[];self.heading=-math.pi*3/4;self.idle=0.;self.speed=0.;self.fade=0.;self.clock=0.
  for f in self.flights:f.reset()
  self.trails=[deque(maxlen=128) for _ in self.flights]
 def _lag(self,t):
  a=self.hist[0]
  for b in self.hist:
   if b[0]>=t:
    u=clamp((t-a[0])/max(1e-9,b[0]-a[0]),0,1);return (a[1]+u*(b[1]-a[1]),a[2]+u*(b[2]-a[2]))
   a=b
  return a[1:]
 def _target(self,i,t,xy,scale,bounds):
  ratio,lag,radius,offset,omega,period,life=PARAMS[i];q=self.clock*math.tau/period+i*2.1
  hx,hy=self._lag(t-lag);a=self.heading+math.pi+offset;rad=radius*scale*(1+.20*clamp(self.speed/(600*scale),0,1)); moving=(hx+rad*math.cos(a),hy+rad*math.sin(a));a=self.heading+math.pi+offset+(.22*math.sin(q*.63));rad=radius*scale*(1+.085*math.sin(q));hover=(xy[0]+rad*math.cos(a),xy[1]+rad*math.sin(a));p=tuple(moving[j]+(hover[j]-moving[j])*self.idle for j in range(2));r=110*scale*ratio
  # Choose an alternate angular station if the preferred one would be outside the screen.
  if bounds and inside(p,bounds,r)!=p:
   candidates=[inside(p,bounds,r)]
   for k in range(1,13):
    for sign in (-1,1):
     aa=a+sign*k*math.pi/12;c=(xy[0]+rad*math.cos(aa),xy[1]+rad*math.sin(aa))
     if inside(c,bounds,r)==c:candidates.append(c)
   def score(c):
    near=sum(max(0,155*scale-math.dist(c,s[:2]))**2*4 for j,s in enumerate(self.members) if j!=i)
    return math.dist(c,p)**2+near+max(0,170*scale-math.dist(c,xy))**2*9
   p=min(candidates,key=score)
  return p
 def update(self,t,xy,scale,bounds=None,visible=True):
  xy=tuple(xy);bounds=tuple(bounds) if bounds is not None else None
  if not all(math.isfinite(v) for v in (t,*xy,scale)) or not 0<scale<=4:raise ValueError('invalid input')
  if bounds is not None and (len(bounds)!=4 or not all(math.isfinite(v) for v in bounds) or bounds[0]>=bounds[2] or bounds[1]>=bounds[3]):raise ValueError('invalid bounds')
  key=(t,xy,scale,bounds,bool(visible));old=self.last
  if old==key:return self.result
  if not visible:self.reset();self.last=key;self.result=[];return []
  if old and (not old[4] or t<=old[0] or t-old[0]>.25 or math.dist(xy,old[1])>500 or scale!=old[2] or bounds!=old[3]):self.reset();old=None
  dt=t-old[0] if old else 0.;self.last=key;self.clock+=dt;self.hist.append((t,*xy))
  while len(self.hist)>2 and t-self.hist[1][0]>.6:self.hist.popleft()
  if old:
   dx,dy=xy[0]-old[1][0],xy[1]-old[1][1];speed=math.hypot(dx,dy)/dt;self.speed+=(speed-self.speed)*(1-math.exp(-dt/.12))
   if speed>12*scale:self.heading=wrap(self.heading+wrap(math.atan2(dy,dx)-self.heading)*(1-math.exp(-dt/.14)))
   self.idle+=(float(self.speed<18*scale)-self.idle)*(1-math.exp(-dt/.65));self.fade=min(1,self.fade+dt/.40)
  else:
   for i in range(self.count):self.members.append([*self._target(i,t,xy,scale,bounds),0.,0.,self.heading])
  for _ in range(max(1,math.ceil(dt*120))):
   h=dt/max(1,math.ceil(dt*120));positions=[tuple(s[:2]) for s in self.members];targets=[self._target(i,t,xy,scale,bounds) for i in range(self.count)]
   for i,s in enumerate(self.members):
    ratio,lag,radius,offset,w,period,life=PARAMS[i];x,y,vx,vy,hd=s;tx,ty=targets[i];ax=w*w*(tx-x)-1.9*w*vx;ay=w*w*(ty-y)-1.9*w*vy
    for j,o in enumerate([*positions,xy]):
     if j==i:continue
     gap=(155 if j==self.count else 140)*scale;dx,dy=x-o[0],y-o[1];dist=math.hypot(dx,dy)
     if dist<gap:
      if dist<1e-7:dx,dy=math.cos(i*2.4),math.sin(i*2.4);dist=1
      strength=3900*scale*(1-dist/gap)**2;ax+=strength*dx/dist;ay+=strength*dy/dist
    ax,ay=limit(ax,ay,2400*scale);vx,vy=limit(vx+ax*h,vy+ay*h,780*scale);nx,ny=inside((x+vx*h,y+vy*h),bounds,110*scale*ratio)
    if nx!=x+vx*h:vx=0.
    if ny!=y+vy*h:vy=0.
    s[:]=[nx,ny,vx,vy,hd]
  result=[]
  for i,(s,f) in enumerate(zip(self.members,self.flights)):
   ratio,lag,radius,offset,w,period,life=PARAMS[i];x,y,vx,vy,hd=s;sc=scale*ratio;st=f.update(t,(x,y),sc);q=self.clock*math.tau/period+i*2.1
   target=st['heading'] if math.hypot(vx,vy)>9*scale else hd;hover=self.heading+offset+.65*math.sin(q*.7);target+=wrap(hover-target)*self.idle;hd=wrap(hd+wrap(target-hd)*(1-math.exp(-dt/(.18+i*.055))));s[4]=hd
   # Reproject anchors with the selected actual 3D pose and independent heading.
   pose=f.poses[(st['pitch'],st['roll'])];c,d=math.cos(hd),math.sin(hd);cx,cy=f.manifest['pivot']
   def tr(p):
    a,b=(p[0]-cx)*sc,(p[1]-cy)*sc;return (x+a*c-b*d,y+a*d+b*c)
   nozzles=[tr(p) for p in pose['nozzles']];mid=tuple(sum(p[j] for p in nozzles)/2 for j in range(2));rear=tr(pose['rear_direction']);power=clamp(st['power']*(1-.75*self.idle)+self.idle*(.06+.055*max(0,math.sin(q*2.3))),0,1);trail=self.trails[i]
   if power>.10:trail.append((t,mid,power))
   while trail and t-trail[0][0]>life:trail.popleft()
   # Flight renderer uses 400 ms attenuation; remap age for per-unit lifetime.
   st.update(id=i,heading=hd,nozzles=nozzles,rear=normalized((rear[0]-mid[0],rear[1]-mid[1])),front=tr(pose['front']),power=power,trail=[(t-(t-a)/life*.4,b,c) for a,b,c in trail],opacity=self.fade,velocity=(vx,vy),idle=self.idle,shots=[],charge=0.)
   result.append(st)
  self.result=result;return result
 def draw(self,background,states):
  im=background.copy().convert('RGBA')
  for st in sorted(states,key=lambda a:a['scale']):
   if st['opacity']<=0:continue
   # Local transparent patch covers rotated sprite, plume and history (not full desktop).
   x,y=st['xy'];r=math.ceil(200*st['scale']+8);pts=[(x-r,y-r),(x+r,y+r),*(p for _,p,_ in st['trail'])];pad=math.ceil(12*st['scale']+6);l=max(0,math.floor(min(p[0] for p in pts))-pad);top=max(0,math.floor(min(p[1] for p in pts))-pad);right=min(im.width,math.ceil(max(p[0] for p in pts))+pad);bottom=min(im.height,math.ceil(max(p[1] for p in pts))+pad)
   if right<=l or bottom<=top:continue
   def tr(p):return (p[0]-l,p[1]-top)
   local=dict(st,xy=tr(st['xy']),nozzles=[tr(p) for p in st['nozzles']],trail=[(t,tr(p),a) for t,p,a in st['trail']]);layer=self.flights[st['id']].draw(Image.new('RGBA',(right-l,bottom-top)),local)
   if st['opacity']<1:layer.putalpha(layer.getchannel('A').point(lambda a:round(a*st['opacity'])))
   im.alpha_composite(layer,(l,top))
  return im

class FleetFlight(Primary):
 def __init__(self,root,enabled=True,count=0):
  super().__init__(root,enabled);self.fleet=EscortFleet(root,count)
 def reset(self):
  super().reset()
  if hasattr(self,'fleet'):self.fleet.reset()
 def set_count(self,count):self.fleet.set_count(count)
 def update(self,t,xy,scale=.58,fixed=False,bounds=None,escorts_visible=True):
  st=super().update(t,xy,scale,fixed);st['escorts']=self.fleet.update(t,xy,scale,bounds,escorts_visible);return st
 def draw(self,background,state):
  if not state['escorts']:return super().draw(background,state)
  return super().draw(self.fleet.draw(background,state['escorts']),state)
