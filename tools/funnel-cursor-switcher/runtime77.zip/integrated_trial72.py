"""Trial72: replace only the opening of Trial71 special with six sequential rack launches."""
from integrated_trial71 import Integrated as Previous, Barrier as PreviousBarrier, ROOT
from field_trial66 import clamp,smooth, color
from PIL import Image,ImageDraw,ImageFilter
import math,json
from pathlib import Path

class Barrier(PreviousBarrier):
    def __init__(self,root=ROOT,field_color='purple'):
        super().__init__(root,field_color)
        self.rack=json.loads((Path(root)/'trial72/launch_manifest.json').read_text(encoding="utf-8"))['poses']
    def trigger(self,*args,**kwargs):
        if not super().trigger(*args,**kwargs):return False
        e=self.event; old=e['ends']['launch']; duration=1.48; shift=duration-old
        e['ends']={k:v+shift for k,v in e['ends'].items()};e['end']=e['ends']['depart']
        l,t,r,b=e['bounds']; margin=min(4,(r-l)/20,(b-t)/20)
        # Rightmost high -> leftmost low; the first and fifth are long straight racks.
        offsets=(0,34,86,86,138,138); dims=[self.rack['straight' if i in (0,4) else 'folded']['size'] for i in range(6)]
        maxh=max(y+h for y,(_,h) in zip(offsets,dims)); raww=6*38
        scale=min(.46*e['requested_scale'],(r-l-2*margin)/raww,(b-t-2*margin)/maxh)
        x0=clamp(e['origin'][0]-raww*scale/2,l+margin,r-margin-raww*scale)
        y0=clamp(e['origin'][1]-maxh*scale/2,t+margin,b-margin-maxh*scale)
        e['rack_units']=[dict(id=i,shape='straight' if i in (0,4) else 'folded',top=(x0+(5-i)*38*scale,y0+offsets[i]*scale),size=(w*scale,h*scale),ignition=.10+.12*i) for i,(w,h) in enumerate(dims)]
        return True
    def sample(self,t):
        s=super().sample(t)
        if s is None or s['phase']!='launch':return s
        e=self.event; age=s['age']; units=[]
        for v in e['rack_units']:
            x,y=v['top'];w,h=v['size']; elapsed=age-v['ignition'];move=elapsed-.06
            q=clamp(move/.66); dist=(y+h-e['bounds'][1]+max(18,h*.23))*q*q
            bottom=y+h-dist
            power=smooth(elapsed/.065) if q<1 else 0.
            # Keep a faint trail only while the body is still crossing the top boundary.
            units.append(dict(v,top=(x,y-dist),anchor=(x+w/2,bottom),power=power,progress=q,trail_length=min(95,h*.70)*power*(.30+.70*q),opacity=1. if q<1 else 0.))
        s['units']=units;s['rack_launch']=True;return s
    def region(self,size,state):
        if state and state.get('rack_launch'):
            return (0,0,*size)
        return super().region(size,state)
    def draw(self,background,state):
        if not state or not state.get('rack_launch'):return super().draw(background,state)
        out=background.copy().convert('RGBA');opacity=state['opacity'];jet=Image.new('RGBA',out.size);d=ImageDraw.Draw(jet)
        for v in state['units']:
            p=v['power']*v['opacity']*opacity
            if p<=0:continue
            x,y=v['anchor'];w,h=v['size'];length=v['trail_length'];half=max(.8,w*.35);end=y+length
            for f,rgba in [(1.,(42,125,255,round(105*p))),(.55,(87,201,255,round(190*p))),(.24,(234,249,255,round(245*p)))]:
                d.polygon([(x-half*f,y-1),(x+half*f,y-1),(x,end if f==1 else y+length*(.55+.25*f))],fill=rgba)
            d.ellipse((x-half,y-half,x+half,y+half),fill=(182,235,255,round(205*p)))
        out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(3)));out.alpha_composite(jet)
        for v in state['units']:
            if not v['opacity']:continue
            im=self._image('trial72/'+v['shape']+'.png').resize(tuple(max(1,round(a)) for a in v['size']),Image.Resampling.LANCZOS)
            if opacity!=1:im=im.copy();im.putalpha(im.getchannel('A').point(lambda a:round(a*opacity)))
            out.alpha_composite(im,tuple(round(a) for a in v['top']))
        return out

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse)
        self.barrier=Barrier(root,field_color)
