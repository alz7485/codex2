"""Trial74: retain photo rack and small field units; smooth station motion and exhaust.
All changes visual only. No new 3D renders; interpolate the existing 13 true captures.
"""
from integrated_trial73 import Integrated as Previous, Barrier as PreviousBarrier, ROOT
from field_trial66 import clamp,smooth,mix,add,line,color,exit_point
from PIL import Image,ImageDraw,ImageFilter
import math
import numpy as np

class Barrier(PreviousBarrier):
    def trigger(self,*args,**kwargs):
        if not super().trigger(*args,**kwargs): return False
        e=self.event
        # Keep enough time for the final plume to clear the top edge.
        # Only launch/gap and the final departure duration change; field hold stays intact.
        e['ends']={k:v+.12 for k,v in e['ends'].items()}
        e['ends']['depart']+=.52
        e['end']=e['ends']['depart']
        return True

    def sample(self,t):
        s=super().sample(t)
        if s is None:return None
        e=self.event; phase=s['phase'];u=s['u']
        if s.get('rack_launch'):
            # Residual exhaust survives the body crossing the boundary.
            for v in s['units']:
                elapsed=s['age']-v['ignition'];q=v['progress'];h=v['size'][1]
                tail_age=max(0.,elapsed-.72)
                v['jet_fade']=smooth(elapsed/.065)*(1-smooth(tail_age/.16))
                v['jet_length']=min(95,h*.70)*(.30+.70*q)
                # At ignition the nozzle axis is tilted; after the upward acceleration,
                # the luminous wake follows the actual vertical travel direction.
                v['jet_angle']=v['angle']*(1-smooth((elapsed-.06)/.22))
            return s
        if phase=='open':
            for v in s['units']:
                delay=(v['id']%3)*.035
                v['pose_float']=12*smooth((u-delay)/(1-delay))
        elif phase=='depart':
            # Close in place, turn on the same closed projection, then accelerate.
            for v in s['units']:
                i=v['id'];p=e['stations'][i];h=e['headings'][i]
                v['pose_float']=12*(1-smooth(u/.30))
                turn=smooth((u-.30)/.25);v['station_heading']=h
                v['heading']=h+math.pi*turn
                q=clamp((u-.55)/.45);d=q*q
                dest=exit_point(p,(-math.cos(h),-math.sin(h)),e['bounds'],192*e['scale']+16)
                v['anchor']=mix(p,dest,d);v['trail_start']=mix(p,dest,max(0,d-.12))
                v['power']=smooth(q/.24);v['opacity']=1-smooth((q-.82)/.18)
        return s

    def _station(self,v):
        f=v.get('pose_float')
        if f is None:return super()._station(v)
        f=clamp(f,0,12);a=math.floor(f);b=min(12,a+1);u=f-a
        def frame(i):
            return super(Barrier,self)._station(dict(v,open_step=i,pose=3 if i==12 else v.get('pose',0),light=0))
        im=frame(a)
        if b==a or u<1e-8:return im
        # Premultiplied alpha avoids dark fringes. Interpolation is a 2D approximation,
        # not a new geometry pose, and only between adjacent true 3D captures.
        return Image.blend(im.convert('RGBa'),frame(b).convert('RGBa'),u).convert('RGBA')

    def _rear_offset(self,i,heading):
        # The rear visual point on the closed silhouette, estimated from alpha.
        key=('rear74',i)
        if key not in self.cache:
            im=self._image(f'trial73/poses/{i}-0-base.png');a=np.asarray(im.getchannel('A'));yy,xx=np.where(a>=128)
            dx,dy=xx+.5-im.width/2,yy+.5-im.height/2
            c,s=math.cos(heading),math.sin(heading);along=dx*c+dy*s;side=-dx*s+dy*c
            cut=np.percentile(along,5);m=along<=cut;lat=float(np.median(side[m]));back=float(np.median(along[m]));self.cache[key]=(back*c-lat*s,back*s+lat*c)
        return self.cache[key]

    def _transit_draw(self,background,state):
        out=background.copy().convert('RGBA');jet=Image.new('RGBA',out.size);d=ImageDraw.Draw(jet);opacity=state['opacity']
        items=[]
        for v in state['units']:
            h=v['heading'];sh=v['station_heading'];delta=(h-sh+math.pi)%(2*math.pi)-math.pi
            im=self._station(v);n=im.width;scale=n/self.cell
            if abs(delta)>1e-8:im=im.rotate(-math.degrees(delta),Image.Resampling.BICUBIC,expand=True)
            p=v['anchor'];alpha=v['opacity']*opacity;power=v['power'];dx,dy=self._rear_offset(v['id'],sh);c,s=math.cos(delta),math.sin(delta)
            noz=add(p,((dx*c-dy*s)*scale,(dx*s+dy*c)*scale));items.append((v,im,p,alpha))
            if power>0 and alpha>0:
                length=max(3,40*scale)*power;end=add(noz,(-math.cos(h)*length,-math.sin(h)*length));w=max(1,4*scale)
                if 'trail_start' in v:
                    tail=add(v['trail_start'],(noz[0]-p[0],noz[1]-p[1]));line(d,[tail,noz],color((67,163,255),65*alpha*power),w)
                line(d,[noz,end],color((115,212,255),200*alpha*power),w);line(d,[noz,mix(noz,end,.57)],color((243,252,255),245*alpha*power),max(1,w*.4))
        out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(2)));out.alpha_composite(jet)
        for v,im,p,alpha in sorted(items,key=lambda a:state['vertices'][a[0]['id']][2]):self._paste(out,im,p,alpha)
        return out

    def draw(self,background,state):
        if not state:return super().draw(background,state)
        if state.get('rack_launch'):
            out=background.copy().convert('RGBA');opacity=state['opacity'];jet=Image.new('RGBA',out.size);d=ImageDraw.Draw(jet)
            for v in state['units']:
                p=v['jet_fade']*opacity
                if p<=0:continue
                x,y=v['anchor'];length=v['jet_length'];half=max(.8,34*v['rack_scale']*.30);a=math.radians(v['jet_angle']);dx,dy=math.sin(a),math.cos(a);nx,ny=dy,-dx
                for f,rgba in [(1.,(42,125,255,round(105*p))),(.55,(87,201,255,round(190*p))),(.24,(234,249,255,round(245*p)))]:
                    le=length if f==1 else length*(.55+.25*f);d.polygon([(x-nx*half*f,y-ny*half*f),(x+nx*half*f,y+ny*half*f),(x+dx*le,y+dy*le)],fill=rgba)
                if v['opacity']:d.ellipse((x-half,y-half,x+half,y+half),fill=(182,235,255,round(205*p)))
            out.alpha_composite(jet.filter(ImageFilter.GaussianBlur(3)));out.alpha_composite(jet)
            for v in reversed(state['units']):
                if not v['opacity']:continue
                im,_,_=self._rack_sprite(v['shape'],v['angle'],v['rack_scale'])
                if opacity!=1:im=im.copy();im.putalpha(im.getchannel('A').point(lambda a:round(a*opacity)))
                out.alpha_composite(im,tuple(round(a) for a in v['top']))
            return out
        if state['phase'] in ('return','depart'):return self._transit_draw(background,state)
        return super().draw(background,state)

class Integrated(Previous):
    def __init__(self,root=ROOT,enabled=True,count=0,field_color='purple',delay=.9,period=2.4,reverse=False):
        super().__init__(root,enabled,count,field_color,delay,period,reverse);self.barrier=Barrier(root,field_color)
