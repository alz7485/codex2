"""Reference flight compositor. Visual only; all input coordinates are read-only.
Run preview_trial62.py for a deterministic preview. No OS cursor or hooks.
"""
import math,json
from collections import deque
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import numpy as np

def clamp(x,a,b):return max(a,min(b,x))
def wrap(a):return (a+math.pi)%(2*math.pi)-math.pi
def normalized(v):
 n=math.hypot(*v);return (v[0]/n,v[1]/n) if n>1e-8 else (-1.,0.)
class Flight:
 def __init__(self,root):
  self.root=Path(root);self.manifest=json.loads((self.root/'flight_manifest.json').read_text(encoding="utf-8"));self.poses={(p['pitch'],p['roll']):p for p in self.manifest['poses']};self.cache={};self.reset()
 def reset(self):
  self.last=None;self.heading=math.radians(-135);self.roll=self.pitch=self.power=self.speed=0.;self.history=deque(maxlen=128)
 def update(self,t,xy,scale=0.58,fixed=False):
  if not math.isfinite(t) or not all(math.isfinite(a) for a in xy) or not math.isfinite(scale) or not 0<scale<=4:raise ValueError('invalid input')
  if self.last and (t<self.last[0] or t-self.last[0]>.25 or math.dist(xy,self.last[1])>500 or scale!=self.last[2] or fixed!=self.last[3]):self.reset()
  if self.last and t==self.last[0] and tuple(xy)!=self.last[1]:self.reset()
  if self.last and t>self.last[0]:
   dt=t-self.last[0];dx,dy=xy[0]-self.last[1][0],xy[1]-self.last[1][1];speed=math.hypot(dx,dy)/dt;target=math.atan2(dy,dx) if speed>6 else self.heading;turn=wrap(target-self.heading);alpha=1-math.exp(-dt/0.095);self.heading=wrap(self.heading+alpha*turn);acc=clamp((speed-self.speed)/dt,-2500,2500);self.speed+=(1-math.exp(-dt/.09))*(speed-self.speed);self.roll+=(1-math.exp(-dt/.15))*(clamp(math.degrees(turn)*1.0,-32,32)-self.roll);self.pitch+=(1-math.exp(-dt/.15))*(clamp(acc/100.,-12,12)-self.pitch);want=clamp(.05+self.speed/470+max(0,acc)/4500,0,1);self.power+=(1-math.exp(-dt/.09))*(want-self.power)
  roll=min(self.manifest['rolls'],key=lambda a:abs(a-self.roll));pitch=min(self.manifest['pitches'],key=lambda a:abs(a-self.pitch));pose=self.poses[(pitch,roll)];heading=math.radians(-135) if fixed else self.heading;cs,sn=math.cos(heading),math.sin(heading);cx,cy=self.manifest['pivot']
  def transform(p):
   x,y=(p[0]-cx)*scale,(p[1]-cy)*scale;return (xy[0]+x*cs-y*sn,xy[1]+x*sn+y*cs)
  nozzles=[transform(p) for p in pose['nozzles']];rear=transform(pose['rear_direction']);front=transform(pose['front']);mid=tuple(sum(p[i] for p in nozzles)/len(nozzles) for i in range(2));direction=normalized((rear[0]-mid[0],rear[1]-mid[1]));self.last=(t,tuple(xy),scale,fixed)
  if self.history and self.history[-1][0]==t:self.history.pop()
  if self.power>.10:self.history.append((t,mid,self.power))
  while self.history and t-self.history[0][0]>.40:self.history.popleft()
  return {'t':t,'xy':tuple(xy),'scale':scale,'heading':heading,'roll':roll,'pitch':pitch,'pose':pose['stem'],'power':self.power,'nozzles':nozzles,'rear':direction,'front':front,'trail':list(self.history)}
 def body(self,state):
  name=state['pose'];ims=self.cache.get(name)
  if ims is None:
   ims=tuple(Image.open(self.root/'poses'/f'{name}_{s}.png').convert('RGBA') for s in ('base','lit'));self.cache[name]=ims
  im=Image.blend(*ims,clamp(state['power'],0,1));n=max(1,round(im.width*state['scale']));return im.resize((n,n),Image.Resampling.LANCZOS).rotate(-math.degrees(state['heading']),resample=Image.Resampling.BICUBIC,expand=True)
 def draw(self,background,state):
  im=background.copy().convert('RGBA');layer=Image.new('RGBA',im.size);d=ImageDraw.Draw(layer);p=state['power'];sc=state['scale'];t=state['t'];dx,dy=state['rear'];nx,ny=-dy,dx
  # Time-based rear history, not the position of the OS hotspot.
  trail=state['trail']
  for a,b in zip(trail,trail[1:]):
   f=clamp(1-(t-b[0])/.4,0,1)*b[2];d.line([a[1],b[1]],fill=(58,175,255,round(105*f)),width=max(1,round(7*sc*f)))
  for i,(x,y) in enumerate(state['nozzles']):
   pulse=.92+.08*math.sin(t*math.tau*17+i*1.4);length=(5+70*p)*sc*pulse;w=(2+8*p)*sc
   def q(a,b):return (x+dx*a+nx*b,y+dy*a+ny*b)
   if p>.025:
    d.polygon([q(0,-w),q(length*.42,-w*.52),q(length,0),q(length*.42,w*.52),q(0,w)],fill=(58,157,255,round(145*p)))
    d.polygon([q(0,-w*.5),q(length*.65,0),q(0,w*.5)],fill=(132,220,255,round(220*p)))
    d.line([q(0,0),q(length*.43,0)],fill=(236,252,255,round(250*p)),width=max(1,round(w*.45)))
    rr=max(1,3.4*sc*p);d.ellipse((x-rr,y-rr,x+rr,y+rr),fill=(211,246,255,round(245*p)))
  im.alpha_composite(layer.filter(ImageFilter.GaussianBlur(max(1,3*sc))));im.alpha_composite(layer)
  body=self.body(state);xy=state['xy'];im.alpha_composite(body,(round(xy[0]-body.width/2),round(xy[1]-body.height/2)));return im
