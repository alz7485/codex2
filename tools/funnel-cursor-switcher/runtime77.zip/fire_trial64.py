"""Trial64 visual-only effects; original input/state machine untouched."""
import math
from PIL import Image,ImageDraw,ImageFilter
from flight_trial62 import Flight,clamp,normalized
from fire_trial63 import FireFlight as Previous
from primary_fire_trial63 import FIRE,AFTER,smooth

class FireFlight(Previous):
 def visual_state(self,s):
  if not s['shots']:return s
  t=s['t'];p=s['charge'];front=s['front'];sc=s['scale']
  angle=.65*p*math.sin(t*math.tau*13)
  for shot in s['shots']:
   if shot['stage']=='charge':continue
   age=shot['age'];near=max(0,1-math.dist(shot['origin'],front)/max(1,24*sc))
   angle+=2.4*near*math.exp(-age/.056)*math.sin(age*math.tau*17)
  a=math.radians(clamp(angle,-2.5,2.5));c,d=math.cos(a),math.sin(a)
  def vec(v):return (c*v[0]-d*v[1],d*v[0]+c*v[1])
  def point(v):
   x,y=vec((v[0]-front[0],v[1]-front[1]));return (front[0]+x,front[1]+y)
  v=dict(s);v['xy']=point(s['xy']);v['heading']=s['heading']+a;v['rear']=vec(s['rear']);v['grid']=point(s['grid']);v['nozzles']=[point(x) for x in s['nozzles']];v['holes']=[point(x) for x in s['holes']];v['channel']=[point(x) for x in s['channel']];v['visual_angle']=a
  return v
 def draw(self,background,state):
  if not state['shots']:return super().draw(background,state)
  s=self.visual_state(state);bg=background.copy().convert('RGBA');layer=Image.new('RGBA',bg.size);d=ImageDraw.Draw(layer);t=s['t'];sc=s['scale'];p=s['charge'];grid=s['grid'];front=s['front'];ux,uy=normalized((front[0]-grid[0],front[1]-grid[1]));nx,ny=-uy,ux;length=math.dist(grid,front)
  def q(o,a,b):return (o[0]+ux*a+nx*b,o[1]+uy*a+ny*b)
  def dot(draw,pt,r,col):
   x,y=pt;draw.ellipse((x-r,y-r,x+r,y+r),fill=col)
  if p>0:
   puls=.88+.12*math.sin(t*math.tau*9);energy=p*puls
   d.line(s['channel'],fill=(108,75,255,round(65*energy)),width=max(1,round(24*sc*energy)))
   for j in range(3):
    phase=t*math.tau*(7+j*1.7)+j*2.1;start=.04+j*.17;span=.36+j*.08
    pts=[q(grid,length*(start+span*k/8),math.sin(phase+k*2.7)*sc*(4+5*p)*math.sin(math.pi*k/8)) for k in range(9)]
    d.line(pts,fill=(137,116,255,round(145*energy)),width=max(1,round(3*sc)))
    d.line(pts,fill=(223,230,255,round(210*energy)),width=max(1,round(sc)))
   for i in range(20):
    u=(t*2.1+i/20)%1;off=math.sin(t*13+i*2.399)*(10*(1-u)+2)*sc;point=q(grid,length*u,off);tail=q(grid,max(0,length*u-(7+7*p)*sc),off+1.1*sc);alpha=round(210*energy*min(1,u*8));d.line([tail,point],fill=(144,156,255,alpha),width=max(1,round(2*sc)));dot(d,point,max(.65,1.3*sc),(238,244,255,alpha))
   dot(d,grid,7*sc*energy,(156,142,255,round(200*energy)));dot(d,grid,3*sc*energy,(245,248,255,round(245*p)))
   dot(d,front,6*sc*energy,(180,147,255,round(180*p)));dot(d,front,2.5*sc*energy,(255,250,255,round(248*p)))
  bg.alpha_composite(layer.filter(ImageFilter.GaussianBlur(max(1,3.3*sc))));bg.alpha_composite(layer)
  im=Flight.draw(self,bg,s)
  for shot in s['shots']:
   if shot['stage']=='charge':continue
   age=shot['age'];power=shot['power'];o=shot['origin'];ss=shot['scale'];h=shot['heading'];vx,vy=math.cos(h),math.sin(h);px,py=-vy,vx
   def b(l,w=0):return (o[0]+vx*l+px*w,o[1]+vy*l+py*w)
   ray=Image.new('RGBA',im.size);r=ImageDraw.Draw(ray);length=220*ss;end=length*smooth(age/.040);start=length*smooth((age-FIRE)/AFTER) if age>FIRE else 0
   if end>start:
    for wid,color in [(25,(118,72,255,65)),(15,(141,92,255,145)),(8,(184,151,255,205)),(3,(255,247,255,245))]:
     r.line([b(start),b(end)],fill=(*color[:3],round(color[3]*power)),width=max(1,round(wid*ss*max(.25,power))))
    for j in range(5):
     pos=((age*1150+j*44)%220)*ss;lo=max(start,pos-13*ss);hi=min(end,pos+5*ss)
     if hi>lo:r.line([b(lo),b(hi)],fill=(241,224,255,round(220*power)),width=max(1,round(5*ss*power)))
    dot(r,b(end),max(1,4*ss*power),(249,239,255,round(240*power)))
   if age<.15:
    k=age/.15;rad=(5+23*k)*ss;alpha=round(175*(1-k));pts=[b(5*ss+math.cos(j*math.tau/48)*rad*.30,math.sin(j*math.tau/48)*rad) for j in range(49)];r.line(pts,fill=(190,168,255,alpha),width=max(1,round(2*ss)))
    dot(r,o,max(1,10*ss*(1-k)),(235,221,255,alpha));dot(r,o,max(1,4*ss*(1-k)),(255,255,255,alpha))
   if .025<age<FIRE+AFTER:
    u=(age-.025)/(FIRE+AFTER-.025);fade=(1-u)**1.6
    for j in range(10):
     phi=j*2.399963+shot['id']*.37;dist=(age-.025)*(45+9*(j%4))*ss;along=dist*(1.2+.55*math.cos(phi));across=dist*math.sin(phi)*.8;pos=b(along,across);tail=b(max(0,along-4*ss),across*.82);alpha=round(190*fade)
     r.line([tail,pos],fill=(158,136,255,alpha),width=max(1,round(ss)));dot(r,pos,max(.55,1.15*ss*fade),(225,221,255,alpha))
   im.alpha_composite(ray.filter(ImageFilter.GaussianBlur(max(1,2.8*ss))));im.alpha_composite(ray)
  return im
