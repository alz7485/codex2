"""PTSET/GMSET creation shell: editable fields, not an E3D expression engine."""
import copy
import tkinter as tk
import uuid
from tkinter import messagebox, ttk
from . import element_schema as schema, project, expressions, catalogue, presets, pairing

BLUE = '#2269de'
MUTED = '#738499'


class ConstructionEditor(ttk.Frame):
    def __init__(self, host, kind):
        super().__init__(host.content)
        self.host, self.kind = host, kind
        self.busy = True
        self.field = None
        self.element_id = None
        self.section = 'main'
        self.preview_scom_id = host.scom_id
        self.point_canvas=None
        self.pack(fill='both', expand=True)
        definitions = [d for d in host.data['definitions'] if d['kind'] == kind]
        preferred = project.get(host.data, 'definitions', host.definition_id)
        draft=host.data.get('creation_draft',{})
        staged=project.get(host.data,'definitions',draft.get('ptset_id' if kind=='PTSET' else 'gmset_id'))
        if staged and staged['kind']!=kind:staged=None
        demo = next((d for d in definitions if d['id'] == ('ui-ptset' if kind == 'PTSET' else 'ui-gmset')), None)
        self.definition_id = preferred['id'] if preferred and preferred['kind'] == kind else (staged or demo or (definitions[0] if definitions else {})).get('id')
        self.build()
        self.refresh()
        self.busy = False

    @property
    def data(self): return self.host.data
    def definition(self): return project.get(self.data, 'definitions', self.definition_id)

    def remember_preview(self,definition=None):
        if self.kind=='PTSET':
            from .point_preview import remember
        elif self.kind=='GMSET':
            from .geometry_preview import remember
        else:return
        remember(self.data,definition or self.definition())
    def element(self):
        if hasattr(self,'elements') and len(self.elements.selection())>1:return None
        return next((e for e in schema.walk((self.definition() or {}).get('elements', [])) if e['id'] == self.element_id), None)

    def build(self):
        if self.kind in ('PTSET','GMSET'):
            from .construction_layout import build_simple
            build_simple(self)
            return
        top = ttk.Frame(self); top.pack(fill='x', pady=(0, 6))
        block = ttk.Frame(top); block.pack(side='left', fill='x', expand=True)
        ttk.Label(block, text=({'PTSET':'1. PTSET','GMSET':'2. GMSET'}.get(self.kind,self.kind)) + ' を作成・編集', style='PaneTitle.TLabel').pack(side='left')
        from .project_actions import Hint
        note=ttk.Label(block,text='ⓘ 構成模式図',style='Muted.TLabel');note.pack(side='left',padx=8)
        note.hint=Hint(note,'要素・属性・式を編集します。プレビューは寸法や式を反映しない構成模式図です。')
        for text, command in [('保存', self.host.save_project), ('出力を確認', self.review), ('新しい '+self.kind+' を作る', self.add_definition)]:
            button=ttk.Button(top,text=text,command=command);button.pack(side='right',padx=3)
            if command==self.add_definition:self.new_set_button=button
        metadata = ttk.Frame(self); metadata.pack(fill='x', pady=(0, 10))
        ttk.Label(metadata, text=self.kind + ' 名').pack(side='left')
        self.def_name = tk.StringVar()
        self.name_entry = ttk.Entry(metadata, textvariable=self.def_name, width=32); self.name_entry.pack(side='left', padx=8)
        self.name_entry.bind('<FocusOut>', lambda _: self.commit_name()); self.name_entry.bind('<Return>', lambda _: self.commit_name())
        if schema.PARENT_FIELDS[self.kind]:ttk.Button(metadata, text='親属性・中立軸', command=self.edit_parent).pack(side='left', padx=4)
        self.usage_label = ttk.Label(metadata, text='', style='Muted.TLabel'); self.usage_label.pack(side='left', padx=10)
        ttk.Button(metadata, text='複製して作成', command=self.duplicate_definition).pack(side='right')
        preset_bar=ttk.Frame(self);preset_bar.pack(fill='x',pady=(0,8))
        ttk.Label(preset_bar,text='PARAM プリセット').pack(side='left')
        self.preset_choice=ttk.Combobox(preset_bar,state='readonly',width=36);self.preset_choice.pack(side='left',padx=8)
        self.preset_choice.bind('<<ComboboxSelected>>',self.assign_preset)
        ttk.Button(preset_bar,text='プリセットを管理',command=lambda:self.host.switch('rules')).pack(side='left')
        if self.kind in ('PTSET','GMSET'):
            flow=ttk.Frame(preset_bar if self.kind=='PTSET' else self)
            if self.kind=='PTSET':flow.pack(side='right')
            else:flow.pack(fill='x',pady=(0,8))
            self.workflow_label=ttk.Label(flow,text='PTSET → GMSET → カタログ作成 → スペック',style='Muted.TLabel',wraplength=600)
            if self.kind!='PTSET':self.workflow_label.pack(side='left')
            self.create_part_button=ttk.Button(flow,text='PTSET の編集を終えて GMSET へ' if self.kind=='PTSET' else '次へ：この GMSET で SCOM を登録',style='TButton' if self.kind=='PTSET' else 'Primary.TButton',command=self.create_part)
            self.create_part_button.pack(side='right')
        split = ttk.Panedwindow(self, orient='horizontal'); split.pack(fill='both', expand=True)
        left = ttk.Frame(split, padding=8); center = ttk.Frame(split, padding=10); right = ttk.Frame(split, padding=10)
        for frame, weight in ((left, 2), (right, 5), (center, 3)): split.add(frame, weight=weight)
        self.host.balance(split,(.24,.70) if self.kind=='PTSET' else (.23,.71))
        ttk.Label(left, text='定義を選択', style='Heading.TLabel').pack(anchor='w', pady=4)
        self.def_choice = ttk.Combobox(left, state='readonly'); self.def_choice.pack(fill='x', pady=5)
        self.def_choice.bind('<<ComboboxSelected>>', self.select_definition)
        ttk.Label(left, text='作成済みのポイント' if self.kind == 'PTSET' else '形状の構成', style='Heading.TLabel').pack(anchor='w', pady=(12, 5))
        self.elements = ttk.Treeview(left, columns=('number','type') if self.kind=='PTSET' else ('type',), show='tree headings', selectmode='browse', height=5)
        self.elements.heading('#0', text='要素名'); self.elements.heading('type', text='種類')
        self.elements.column('#0', width=130, minwidth=70); self.elements.column('type', width=75, minwidth=60)
        if self.kind=='PTSET':
            self.elements.heading('number',text='番号');self.elements.column('number',width=45,minwidth=40)
        self.elements.pack(fill='both', expand=True); self.elements.bind('<<TreeviewSelect>>', self.select_element)
        buttons = ttk.Frame(left); buttons.pack(fill='x', pady=8)
        for text, fn in [('複製', self.duplicate_element), ('削除', self.delete_element)]: ttk.Button(buttons, text=text, command=fn).pack(side='left', padx=2)
        outline = ttk.Frame(left); outline.pack(fill='x')
        for text,fn in (([('子を追加',self.add_child)] if self.kind!='PTSET' else [])+[('↑',lambda:self.move_element(-1)),('↓',lambda:self.move_element(1))]): ttk.Button(outline,text=text,command=fn,width=7).pack(side='left',padx=2)
        p0=None
        if self.kind == 'PTSET':
            p0=ttk.Label(left,text='P0：原点 / +Z（自動生成・編集不可）',style='Muted.TLabel',wraplength=250);p0.pack(anchor='w',pady=5)
        if self.kind=='PTSET':ttk.Label(right,text='2. 種類を選んで要素を作成',style='Heading.TLabel').pack(anchor='w',pady=(0,6))
        library = ttk.LabelFrame(right if self.kind=='PTSET' else left,text='ポイントの種類' if self.kind=='PTSET' else '要素ライブラリ',padding=8);library.pack(fill='x',pady=6)
        self.negative = tk.BooleanVar(value=False)
        if self.kind == 'GMSET':
            ttk.Checkbutton(library, text='ネガティブ（'+str(len(schema.NEGATIVE_BASE))+'種類）', variable=self.negative, command=self.populate_library).pack(anchor='w')
            ttk.Label(library, text='ポジティブ：18種類', style='Muted.TLabel').pack(anchor='w')
        elif self.kind=='PTSET':ttk.Label(library,text='選択すると、指定方法を下に表示します。',style='Muted.TLabel',wraplength=310).pack(anchor='w')
        else: ttk.Label(library,text=' / '.join(schema.TYPES_BY_SET[self.kind]),style='Muted.TLabel').pack(anchor='w')
        library_list=ttk.Frame(library);library_list.pack(fill='x',pady=5)
        self.library = tk.Listbox(library_list, height=4 if self.kind=='PTSET' else 3, exportselection=False, font=(self.host.ui_font, 10), relief='flat', selectbackground='#e4efff', selectforeground=BLUE)
        self.library.pack(side='left',fill='x',expand=True)
        scroll=ttk.Scrollbar(library_list,orient='vertical',command=self.library.yview);scroll.pack(side='right',fill='y');self.library.configure(yscrollcommand=scroll.set)
        if self.kind=='PTSET':
            self.library.bind('<<ListboxSelect>>',self.describe_selected_type)
            self.type_help=ttk.Label(library,text='',wraplength=310,justify='left');self.type_help.pack(anchor='w',fill='x',pady=(6,8))
        else:self.library.bind('<Double-1>',lambda _:self.add_element())
        self.create_element_button=ttk.Button(library,text='作成' if self.kind=='PTSET' else '＋ 選択した要素を追加',command=self.add_element,style='Primary.TButton' if self.kind=='PTSET' else 'TButton');self.create_element_button.pack(fill='x')
        self.populate_library()
        if self.kind!='PTSET':library.pack(side='bottom',fill='x',pady=6,before=self.elements)
        if p0:p0.pack(side='bottom',anchor='w',pady=5,before=self.elements)
        outline.pack(side='bottom',fill='x',before=self.elements)
        buttons.pack(side='bottom',fill='x',pady=8,before=self.elements)
        if self.kind=='PTSET':ttk.Label(center,text='3. ポイントを選んで属性を入力',style='Heading.TLabel').pack(anchor='w',pady=(0,6))
        title = ttk.Frame(center); title.pack(fill='x')
        self.element_name = tk.StringVar(); self.element_name_entry = ttk.Entry(title, textvariable=self.element_name)
        self.element_name_entry.pack(side='left', fill='x', expand=True, padx=(0, 8))
        self.element_name.trace_add('write', self.rename_element)
        self.type_choice = ttk.Combobox(title, state='readonly', width=10); self.type_choice.pack(side='right'); self.type_choice.bind('<<ComboboxSelected>>', self.change_type)
        self.element_note = ttk.Label(center, text='', style='Muted.TLabel', wraplength=530); self.element_note.pack(anchor='w', pady=6)
        self.tabs = ttk.Notebook(center); self.tabs.pack(fill='both', expand=True, pady=(3, 8))
        self.tables = {}
        sections = [('main', '基本・位置' if self.kind == 'PTSET' else '形状・位置')]
        sections += [('detail', '詳細属性')] if self.kind == 'PTSET' else [('common', '共通'), ('negative', '負形状')]
        sections += [('extra', '追加属性')]
        for key, label in sections:
            frame = ttk.Frame(self.tabs, padding=3); self.tabs.add(frame, text=label)
            table = self.host.table(frame, [('attr', '属性', 90), ('meaning', '説明', 180), ('value', '設定値・式', 260)], height=4)
            table.bind('<<TreeviewSelect>>',lambda event,s=key:self.select_field(s))
            table.bind('<Double-1>',lambda _:self.focus_value_input())
            self.tables[key] = table
        self.section_order = [s[0] for s in sections]
        self.tabs.bind('<<NotebookTabChanged>>', self.tab_changed)
        editor = ttk.LabelFrame(center, text='属性値・式の入力', padding=10); editor.pack(side='bottom',fill='x',before=self.tabs)
        self.field_label = ttk.Label(editor, text='', style='Heading.TLabel'); self.field_label.pack(anchor='w', pady=(0, 6))
        self.expression = tk.StringVar(); self.expression.trace_add('write', self.edit_expression)
        self.expression_entry = ttk.Entry(editor, textvariable=self.expression, font=(self.host.ui_font, 13)); self.expression_entry.pack(fill='x')
        self.choice_entry = ttk.Combobox(editor, textvariable=self.expression, state='normal')
        reference = self.reference_frame = ttk.Frame(editor); reference.pack(fill='x', pady=8)
        self.ref_kind = ttk.Combobox(reference, values=schema.REFERENCE_TYPES, state='readonly', width=14); self.ref_kind.set('PARAM'); self.ref_kind.pack(side='left')
        self.ref_kind.bind('<<ComboboxSelected>>', lambda _: self.update_role())
        self.ref_number = tk.StringVar(value='1')
        self.number_entry = ttk.Spinbox(reference, from_=1, to=999, width=5, textvariable=self.ref_number); self.number_entry.pack(side='left', padx=5)
        self.ref_number.trace_add('write', lambda *_: self.update_role())
        ttk.Button(reference, text='式へ挿入', command=self.insert_reference).pack(side='left', padx=3)
        ttk.Button(reference, text='÷ 2', command=self.half).pack(side='left')
        self.role_label = ttk.Label(editor, text='', style='Muted.TLabel'); self.role_label.pack(anchor='w')
        if self.kind=='PTSET':ttk.Button(reference,text='式を整理',command=self.normalize_expression).pack(side='left',padx=3)
        else:
            helpers=ttk.Frame(editor);helpers.pack(fill='x',pady=4)
            for text,fn in [('式を読みやすく整理',self.normalize_expression),('直径／半径',self.edit_sizes),('LINE の点列',self.edit_points)]:ttk.Button(helpers,text=text,command=fn).pack(side='left',padx=2)
        ttk.Label(editor,text='四則演算・三角関数・明示単位に対応。角度は度、距離のDB単位はmm。',style='Muted.TLabel',wraplength=520).pack(anchor='w',pady=5)
        self.validation_note = ttk.Label(editor, text='', foreground='#bb6440', wraplength=520); self.validation_note.pack(anchor='w')
        self.canvas=None
        if self.kind!='PTSET':
            ttk.Label(right,text='構成プレビュー',style='Heading.TLabel').pack(anchor='w')
            ttk.Label(right,text='模式図：寸法・式・方向は未反映',style='Muted.TLabel',wraplength=310).pack(anchor='w',pady=5)
            self.canvas=tk.Canvas(right,width=320,height=235,bg='#f2f6fc',highlightthickness=0);self.canvas.pack(fill='both',expand=True,pady=8)
            self.canvas.bind('<Configure>',lambda _:self.draw())
        ttk.Label(right,text='確認用 SCOM（任意）' if self.kind=='PTSET' else '確認用 SCOM',style='Heading.TLabel').pack(anchor='w',pady=(8,3))
        self.scom_choice = ttk.Combobox(right, state='readonly'); self.scom_choice.pack(fill='x', pady=5)
        self.scom_choice.bind('<<ComboboxSelected>>', self.select_scom)
        self.values_label = ttk.Label(right, text='', style='Muted.TLabel', wraplength=300); self.values_label.pack(anchor='w', pady=8)
        ttk.Button(right, text='SCOM の値・ANGL を編集', command=self.open_scom).pack(fill='x', pady=8)
        ttk.Label(right, text='確認値は PTSET に保存されません。' if self.kind=='PTSET' else '読み取り専用。点・形状の定義には保存されません。\n設計側のコンテキストを推測せず、未設定参照は計算不可と表示します。', style='Muted.TLabel', wraplength=310).pack(anchor='w')

    def assign_role(self,_=None):
        from . import workflow
        node=self.element()
        if not node or not self.commit_inline():return
        value=self.role_choice.get()
        if self.kind=='PTSET':
            if value not in workflow.POINT_ROLES:return
            node['point_role']=value
        elif node['type'] not in schema.NEGATIVE_BASE and schema.positive(node['type']) not in ('LINE','SLINE'):
            node['preview_group']=value
        self.host.mark();self.refresh()

    def assign_preset(self,_=None):
        if self.busy or not self.definition():return
        if not self.commit_inline():return
        try:presets.bind(self.data,self.definition(),self.preset_options[self.preset_choice.get()])
        except ValueError as exc:self.validation_note.configure(text=str(exc));self.refresh();return
        self.host.mark();self.refresh()

    def refresh_pairing(self):
        if not hasattr(self,'ptset_choice'):return
        d=self.definition();resolved=pairing.resolve(self.data,d);pt=resolved['pointset']
        self.ptset_options={'未設定':'','対応から自動選択':None}
        for record in self.data['definitions']:
            if record['kind']!='PTSET':continue
            label=record['name']
            if label in self.ptset_options:label+=' ['+record['id'][:8]+']'
            self.ptset_options[label]=record['id']
        raw=(d or {}).get(pairing.PAIR_KEY,'')
        if raw and raw not in self.ptset_options.values():self.ptset_options['参照先不明：'+raw]=raw
        self.ptset_choice['values']=list(self.ptset_options)
        self.ptset_choice.set(next((label for label,ident in self.ptset_options.items() if ident==pt['id']),'未設定') if pt else next((label for label,ident in self.ptset_options.items() if raw and ident==raw),'未設定'))
        self.ptset_choice.configure(state='readonly' if d else 'disabled')
        notes={'name':'名前の一致から初期選択','scom':'登録済み SCOM の対応','draft':'作成中の部品の対応','manual':'手動で選択した対応','unset':'PTSET は未設定','none':'対応する PTSET を選択してください。','ambiguous':'候補が複数あります。PTSET を選択してください。','missing':'適用する PTSET が見つかりません。'}
        note=notes[resolved['source']] if d else 'GMSET を作成してください。'
        if pt and presets.selected_id(self.data,pt)!=presets.selected_id(self.data,d):note+=' / PARAM プリセットが異なります。'
        self.pairing_note.configure(text=note)

    def assign_ptset(self,_=None):
        if self.busy or not self.definition():return
        if not self.commit_inline():self.refresh_pairing();return
        try:pairing.assign(self.data,self.definition(),self.ptset_options[self.ptset_choice.get()])
        except (KeyError,ValueError) as exc:self.host.status.configure(text=str(exc));self.refresh_pairing();return
        self.host.mark('GMSET に適用する PTSET を変更しました。');self.refresh_pairing();self.draw()

    def populate_library(self):
        items = schema.TYPES_BY_SET[self.kind]
        if self.kind == 'GMSET' and self.negative.get(): items = schema.NEGATIVE_BASE
        if hasattr(self,'shape_tabs'):
            index=1 if self.negative.get() else 0
            self.library=self.shape_libraries[index]
            if self.shape_tabs.index(self.shape_tabs.select())!=index:self.shape_tabs.select(index)
        self.library.delete(0, 'end')
        for kind in items:
            label=schema.LABELS.get(kind,'負 '+schema.LABELS.get(schema.positive(kind),'未確認'))
            self.library.insert('end',kind+'  '+label)
        if items:self.library.selection_set(0)
        self.describe_selected_type()

    def describe_selected_type(self,_=None):
        if hasattr(self,'guide_canvas'):
            from .element_guide import draw
            draw(self)
        if self.kind!='PTSET' and not getattr(self,'simple_layout',False):return
        selection=self.library.curselection()
        if not selection:
            self.type_help.configure(text='作成する種類を選んでください。')
            self.create_element_button.configure(text='種類を選択して作成',state='disabled');return
        kind=self.library.get(selection[0]).split()[0]
        if kind in schema.PT_GUIDES:
            guide=schema.PT_GUIDES[kind]
            text=guide['position']+'\n'+guide['direction']+'\n'+guide['usage']
        else:
            text=schema.LABELS.get(kind,'負 '+schema.LABELS.get(schema.positive(kind),'未確認'))
            text+='\n'+('ネガティブ形状。NAPP で適用先を指定します。' if kind in schema.NEGATIVE_BASE else '形状を作成してから、寸法・位置の式を入力します。')
        if schema.positive(kind) in ('BOXI','TUBE'):
            text+='\n長さは設計側の前後の接続位置から決まります。SCYLのような高さ入力はありません。'
        self.type_help.configure(text=text)
        self.create_element_button.configure(text=kind+' を作成',state='normal' if self.definition() else 'disabled')

    def toggle_create(self):
        if not self.commit_inline():return
        self.creating=not self.creating
        if self.creating:
            self.creation_frame.deiconify();self.creation_frame.lift();self.creation_frame.grab_set();self.library.focus_set()
        else:self.creation_frame.grab_release();self.creation_frame.withdraw()

    def toggle_settings(self):
        self.settings_open=not self.settings_open
        if self.settings_open:self.settings_frame.pack(fill='x',pady=(0,14),before=self.main_split)
        else:self.commit_name();self.settings_frame.pack_forget()
        self.operations_menu.entryconfigure(self.settings_menu_index,label='設定・確認を閉じる' if self.settings_open else 'セットの設定・確認')

    def toggle_references(self):
        self.references_open=not self.references_open
        if self.references_open:self.reference_controls.pack(fill='x',pady=4)
        else:self.reference_controls.pack_forget()
        self.reference_button.configure(text='PARAM 選択を閉じる' if self.references_open else 'PARAM を選ぶ…')

    def open_preview(self):
        if getattr(self,'simple_layout',False) and self.canvas is not None:
            self.canvas.focus_set();self.draw();return
        existing=getattr(self,'preview_window',None)
        if existing and existing.winfo_exists():existing.lift();return
        win=tk.Toplevel(self.host);self.preview_window=win;win.title('構成プレビュー');win.geometry('520x480');win.transient(self.host)
        ttk.Label(win,text='構成の模式図。寸法・位置・方向は未反映です。',padding=12).pack(anchor='w')
        self.canvas=tk.Canvas(win,bg='#f2f6fc',highlightthickness=0);self.canvas.pack(fill='both',expand=True,padx=12,pady=8)
        self.canvas.bind('<Configure>',lambda _:self.draw())
        def close():self.canvas=None;win.destroy()
        win.protocol('WM_DELETE_WINDOW',close);ttk.Button(win,text='閉じる',command=close).pack(pady=10)
        self.bind('<Destroy>',lambda event:close() if event.widget is self and win.winfo_exists() else None,add='+')
        self.draw()

    def focus_value_input(self):
        if not self.element() or not self.field:return
        if getattr(self,'simple_layout',False):
            self.tables[self.section].begin_edit(self.field);return
        entry=self.choice_entry if self.choice_entry.winfo_ismapped() else self.expression_entry
        entry.focus_set();entry.selection_range(0,'end')

    def commit_inline(self):
        if not all(table.finish_edit() for table in self.tables.values() if hasattr(table,'finish_edit')):return False
        if hasattr(self, 'normalize_destination'): self.normalize_destination()
        return self.elements.finish_edit() if hasattr(self.elements,'finish_edit') else True

    def attribute_section(self,key=None):
        return self.attribute_sections.get(key or self.field,'main') if getattr(self,'unified_attributes',False) else self.section

    def select_first_section(self):
        self.section='main'
        if not getattr(self,'unified_attributes',False):self.tabs.select(0)

    def element_name_context(self,ident):
        if not self.commit_inline():return None
        definition=self.definition();data=self.data
        element=next((node for node in schema.walk(definition['elements']) if node['id']==ident),None) if definition else None
        if not element:return None
        original=element['name'];siblings=self.siblings(element)
        def commit(value):
            value=value.strip()
            if self.data is not data or definition not in data['definitions'] or not any(node is element for node in schema.walk(definition['elements'])):
                raise ValueError('編集対象が変更されています。要素名を選び直してください。')
            if element['name']!=original and value!=element['name']:raise ValueError('要素名が変更されています。選び直してください。')
            if not value or any(node is not element and node['name']==value for node in siblings):raise ValueError('要素名が空か、同じ一覧の名前と重複しています。')
            if len(value)>1000:raise ValueError('要素名は1000文字以内にしてください。')
            if value==element['name']:return
            element['name']=value;values=list(self.elements.item(ident,'values'));values[1]=value
            self.elements.item(ident,text=value,values=values)
            if self.element() is element:self.element_name.set(value)
            self.host.mark();self.draw();self.redraw_points()
        return {'value':original,'commit':commit,'report':lambda text:self.host.status.configure(text=text)}

    def preview_attribute_changed(self,element,key):
        view=getattr(self,'geometry_view',None)
        if view is None:return
        if key in ('TUFLA','CLFLA'):
            view.representation_mode.set('属性確認')
            view.rep_options['tube' if key=='TUFLA' else 'cl']=True
            self.host.gmset_representation=view.representation_settings()
        if key=='NAPP' and element['type'] in schema.NEGATIVE_BASE:
            view.show_negative.set(True);view.render_mode.set('面＋線')
            view.sync_display_controls()

    def inline_context(self,key,section):
        element=self.element();definition=self.definition();data=self.data
        if not element or not schema.known(element['type']) or section=='extra':return None
        if schema.positive(element['type'])=='LPYR' and key=='PAAX':return None
        original=schema.value(element,key);choices=()
        if key=='OBST':choices=tuple(schema.OBST_CHOICES)
        elif key in ('CLFLA','TUFLA','TVISI','BVISI'):choices=('','TRUE','FALSE')
        elif key=='NAPP':choices=tuple(str(i) for i in range(8))
        elif key=='PSKEY':choices=schema.PSKEY_CHOICES
        def commit(value):
            if self.data is not data or definition not in data['definitions'] or not any(node is element for node in schema.walk(definition['elements'])):
                raise ValueError('編集対象が変更されています。セルを選び直してください。')
            if schema.value(element,key)!=original and value!=schema.value(element,key):raise ValueError('属性が変更されています。セルを選び直してください。')
            if key=='OBST':value=schema.OBST_CHOICES.get(value,value)
            self.preview_attribute_changed(element,key)
            if value==schema.value(element,key):
                self.draw();return
            self.remember_preview(definition)
            if key in ('PTCPOS','PTSPOS','PTEPOS'):
                import re
                value=re.sub(r'\bP(?:P\s*)?(\d+)\b',r'PP \1',value,flags=re.I)
            schema.set_value(element,key,value)
            if self.kind=='PTSET':
                from .point_preview import seed_parameter_position
                seed_parameter_position(data,definition,element,key)
            from .editor_rules import derived_axes
            derived_axes(element)
            if schema.positive(element['type'])=='LPYR' and self.tables['main'].exists('PAAX'):
                self.tables['main'].item('PAAX',values=('PAAX',schema.meaning(element['type'],'PAAX'),'自動：'+element['attrs'].get('PAAX','')))
            self.remember_preview(definition)
            self.host.mark()
            if self.element() is element:
                self.tables['main' if getattr(self,'unified_attributes',False) else section].item(key,values=(key,schema.meaning(element['type'],key),self.display_field_value(element,key)))
                if self.field==key:
                    busy=self.busy;self.busy=True;self.expression.set(value);self.busy=busy;self.update_validation()
                if self.kind=='PTSET' and key=='NUMB':self.elements.item(element['id'],values=(value,element['name'],self.elements.item(element['id'],'values')[2]))
            self.redraw_points();self.draw()
        return {'value':original,'toggle':('FALSE','TRUE') if key in ('CLFLA','TUFLA','TVISI','BVISI') else ('0','1','2') if key=='OBST' else ('0','1','2','4','7') if key=='NAPP' else (), 'choices':choices,'commit':commit,'report':lambda text:self.validation_note.configure(text=text)}

    def open_point_canvas(self):
        if self.kind!='PTSET' or not self.definition():return
        if self.point_canvas and self.point_canvas.winfo_exists():self.point_canvas.canvas.focus_set()

    def redraw_points(self,options=False):
        if self.point_canvas and self.point_canvas.winfo_exists():
            if options:self.point_canvas.refresh_options()
            else:self.point_canvas.redraw()

    def refresh(self):
        self.busy = True
        self.definition_names = {d['name']: d['id'] for d in self.data['definitions'] if d['kind'] == self.kind}
        if not getattr(self,'simple_layout',False):self.def_choice['values'] = list(self.definition_names)
        d=self.definition()
        self.describe_selected_type()
        if getattr(self,'simple_layout',False):
            self.add_button.configure(state='normal' if d else 'disabled')
            self.preset_choice.configure(state='readonly' if d else 'disabled')
        if hasattr(self,'create_part_button'):
            self.create_part_button.configure(state='normal' if d else 'disabled')
            pointset=project.get(self.data,'definitions',self.data.get('creation_draft',{}).get('ptset_id'))
            self.workflow_label.configure(text=('使用する PTSET：'+pointset['name']) if self.kind=='GMSET' and pointset else ('' if getattr(self,'simple_layout',False) else 'PTSET → GMSET → カタログ作成 → スペック'))
        self.def_choice.set(d['name'] if d else '')
        self.def_name.set(d['name'] if d else '')
        self.elements.delete(*self.elements.get_children())
        self.preset_options=presets.choices(self.data)
        current=presets.selected_id(self.data,self.definition()) if self.definition() else ''
        if current and current not in self.preset_options.values():self.preset_options['参照先不明：'+current]=current
        self.preset_choice['values']=list(self.preset_options);self.preset_choice.set(presets.label(self.data,self.definition()) if self.definition() else '')
        if hasattr(self,'element_preset_choice'):
            from .element_presets_ui import refresh_ptset_presets
            refresh_ptset_presets(self)
        self.refresh_pairing()
        if d:
            self.host.definition_id = d['id']
            counters={}
            def insert(items,parent='',depth=0):
                for index,e in enumerate(items):
                    counters[e['type']]=counters.get(e['type'],0)+1
                    label=e['type']+' '+str(counters[e['type']])
                    if self.kind=='PTSET' and e.get('point_role'):label+=' / '+e['point_role']
                    values=(e['attrs'].get('NUMB','') if self.kind=='PTSET' else str(index+1),'  '*depth+e['name'],label) if getattr(self,'simple_layout',False) else ((e['attrs'].get('NUMB',''),e['type']) if self.kind=='PTSET' else (e['type'],))
                    self.elements.insert(parent,'end',iid=e['id'],text=e['name'],values=values,open=True)
                    insert(e.get('children',[]),e['id'],depth+1)
            insert(d['elements'])
            if not any(e['id'] == self.element_id for e in schema.walk(d['elements'])): self.element_id = next((e['id'] for e in d['elements']), None)
            if self.element_id: self.elements.selection_set(self.element_id)
            usage = sum(d['id'] in (s.get('gmset_id'), s.get('ptset_id'), s.get('ngmset_id'), s.get('gmsset_id'), s.get('ptsset_id')) for s in self.data['scoms'])
            self.usage_label.configure(text=f'使用先 SCOM：{usage} 件')
        else: self.element_id = None; self.usage_label.configure(text='定義を追加してください。')
        self.scom_names = {s['name']: s['id'] for s in self.data['scoms']}
        self.scom_choice['values'] = list(self.scom_names)
        current = project.get(self.data, 'scoms', self.preview_scom_id)
        self.scom_choice.set(current['name'] if current else '')
        self.refresh_element()
        self.busy = False
        self.refresh_values(); self.draw();self.redraw_points(options=True)
        if hasattr(self,'element_preset_menu'):
            saved=[p for p in self.data.get('element_presets',[]) if p['kind']==self.kind]
            self.element_preset_menu.entryconfigure(0,state='normal' if d and d['elements'] else 'disabled')
            self.element_preset_menu.entryconfigure(1,state='normal' if d and saved else 'disabled')
            self.element_preset_menu.entryconfigure(2,state='normal' if saved else 'disabled')
            if hasattr(self,'recall_preset_button'):
                self.recall_preset_button.configure(state='normal' if d and saved else 'disabled')
                self.register_preset_button.configure(state='normal' if d and d['elements'] else 'disabled')
            if getattr(self.host,'is_preset_editor',False):
                for index in range(3):self.element_preset_menu.entryconfigure(index,state='disabled')
                self.context_menu.entryconfigure(self.settings_menu_index,state='disabled')

    def refresh_element(self):
        e = self.element()
        self.attribute_sections={}
        if hasattr(self,'role_choice'):
            from .workflow import shape_group
            self.role_choice.set(e.get('point_role','') if e and self.kind=='PTSET' else shape_group(e) if e else '')
            editable=e and (self.kind=='PTSET' or shape_group(e) in ('本体','保温'))
            self.role_choice.configure(state='readonly' if editable else 'disabled')
        unified=getattr(self,'unified_attributes',False)
        if unified:self.section='main'
        if getattr(self,'simple_layout',False):
            for button,match in self.helper_buttons:
                button.pack_forget()
                if e and (match=='negative' and e['type'] in schema.NEGATIVE_BASE or schema.positive(e['type'])==match):button.pack(side='left',pady=6,padx=(0,6))
            self.child_button.pack_forget()
            if e and schema.allowed_children(e['type']):self.child_button.pack(side='right')
        self.element_name.set(e['name'] if e else '')
        available = list(schema.TYPES_BY_SET[self.kind])
        if self.kind == 'GMSET': available += list(schema.NEGATIVE_BASE)
        if e and e['type'] in schema.CHILD_TYPES: available = [e['type']]
        if e and e['type'] not in available: available += [e['type']]
        self.type_choice.set(e['type'] if e else '')
        if not getattr(self,'simple_layout',False):
            self.type_choice['values']=available
            self.type_choice.configure(state='readonly' if e else 'disabled')
            self.element_name_entry.configure(state='normal' if e else 'disabled')
        for table in self.tables.values(): table.delete(*table.get_children())
        if not e:
            if getattr(self,'simple_layout',False):self.element_details.configure(text='')
            self.field = None; self.load_field(); self.element_note.configure(text='ポイント・形状欄の「＋ 追加」から要素を作成してください。' if self.definition() else '左端の '+self.kind+' 一覧の「＋ 追加」で名前を登録してください。'); return
        if schema.known(e['type']):
            listed = set()
            if e['type'] in schema.GM_TYPES:e['attrs']['NAPP']='0'
            elif e['type'] in schema.NEGATIVE_BASE:e['attrs'].setdefault('NAPP','2')
            expanded=getattr(self,'show_optional_attrs',False)
            for section in (('main','detail','common','negative') if unified else self.tables):
                if section == 'extra': continue
                table=self.tables['main' if unified else section]
                for key in schema.fields(e['type'], section):
                    self.attribute_sections[key]=section
                    listed.add(key)
                    if key=='NAPP' and e['type'] not in schema.NEGATIVE_BASE:continue
                    if key in (('DESC','PURP') if self.kind=='PTSET' else ('DESC','GTYP','PURP')) and not expanded:continue
                    table.insert('', 'end', iid=key, values=(key, schema.meaning(e['type'],key), ('自動・編集不可：'+self.display_field_value(e,key) if schema.positive(e['type'])=='LPYR' and key=='PAAX' else self.display_field_value(e,key))))
            for key, value in e['attrs'].items():
                if key not in listed and not (key == 'PTCD' and 'PTCDIR' in listed):
                    self.attribute_sections[key]='extra'
                    self.tables['main' if unified else 'extra'].insert('', 'end', iid=key, values=(key, '元データを保持', str(value)))
            note = 'PSKEY・DESC・PURP の新規値は unset。' if self.kind == 'PTSET' else 'OBST：0 対象外 / 1 ソフト / 2 ハード。'
            if e['type'] in schema.NEGATIVE_BASE:
                note = ''
                if e['type'] == 'NSRU': note += 'NSRU の固有属性は未確認です。'
        else:
            for key, value in e['attrs'].items():
                self.attribute_sections[key]='extra'
                self.tables['main' if unified else 'extra'].insert('', 'end', iid=key, values=(key, '旧仮要素・未対応の原文', str(value)))
            note = '旧仮要素・未対応要素です。追加属性で原文を確認できます。正式要素への変更時も原文を保持します。'
        note = schema.LABELS.get(e['type'],'負 '+schema.LABELS.get(schema.positive(e['type']),''))+' / '+note
        note += '\n' + schema.NOTES.get(schema.positive(e['type']),'')
        if getattr(self,'simple_layout',False):
            self.element_details.configure(text=note)
            note=schema.LABELS.get(e['type'],'負 '+schema.LABELS.get(schema.positive(e['type']),'未対応'))
        self.element_note.configure(text=note)
        if getattr(self,'simple_layout',False) and not unified:
            if 'negative' in self.tab_frames:
                if e['type'] in schema.NEGATIVE_BASE:self.tabs.add(self.tab_frames['negative'])
                else:
                    if self.section=='negative':self.section='main';self.tabs.select(0)
                    self.tabs.hide(self.tab_frames['negative'])
            extra=self.tab_frames['extra']
            if self.tables['extra'].get_children():self.tabs.add(extra)
            else:
                if self.section=='extra':self.section='main';self.tabs.select(0)
                self.tabs.hide(extra)
        table = self.tables[self.section]
        keys = table.get_children()
        if self.field not in keys: self.field = keys[0] if keys else None
        if self.field: table.selection_set(self.field)
        self.load_field()

    def select_definition(self, _=None):
        if self.busy: return
        self.commit_name(); self.definition_id = self.definition_names.get(self.def_choice.get()); self.element_id = None
        self.refresh()

    def select_element(self, _=None):
        if self.busy: return
        selected = self.elements.selection()
        if hasattr(self,'multi_notice'):self.multi_notice.pack_forget()
        if len(selected)>1:
            if hasattr(self,'multi_notice'):self.multi_notice.pack(fill='x',pady=8,before=self.tabs)
            if not self.commit_inline():return
            self.element_id=None;self.refresh_element();self.element_note.configure(text='複数選択中：属性は表示・編集できません。');self.draw();self.redraw_points();return
        if selected and selected[0] != self.element_id:
            if not self.commit_inline():
                if self.element_id:self.elements.selection_set(self.element_id)
                return
            self.element_id = selected[0]; self.field = None
            self.busy = True; self.refresh_element(); self.busy = False; self.draw();self.redraw_points()

    def select_field(self, section):
        if self.busy or section != self.section: return
        selected = self.tables[section].selection()
        if selected and selected[0] != self.field:
            self.field = selected[0]; self.busy = True; self.load_field(); self.busy = False

    def tab_changed(self, _=None):
        if self.busy: return
        index = self.tabs.index('current'); self.section = self.section_order[index]; self.field = None
        self.busy = True; self.refresh_element(); self.busy = False

    def load_field(self):
        e = self.element()
        self.choice_entry.pack_forget(); self.expression_entry.pack_forget()
        if getattr(self,'simple_layout',False):
            self.field_label.configure(text=self.field if e and self.field else '属性を選択してください')
            self.field_meaning.configure(text=schema.meaning(e['type'],self.field) if e and self.field else '')
        else:self.field_label.configure(text=(self.field + ' / ' + schema.meaning(e['type'],self.field) if e else '') if self.field else '属性を選択してください')
        self.expression.set(schema.value(e, self.field) if e and self.field else '')
        choices = ()
        if self.field == 'OBST': choices = tuple(schema.OBST_CHOICES)
        elif self.field in ('PAXI', 'PAAX', 'PBAX', 'PCAX', 'PLAXI', 'PTCDIR'): choices = schema.DIRECTIONS
        elif self.field in ('CLFLA','TUFLA','TVISI','BVISI'): choices = ('','TRUE','FALSE')
        elif self.field == 'NAPP': choices = tuple(str(i) for i in range(8))
        if choices:
            self.choice_entry['values'] = choices
            if self.field == 'OBST': self.expression.set(next((key for key, val in schema.OBST_CHOICES.items() if val == schema.value(e, self.field)), schema.value(e, self.field)))
            if not getattr(self,'simple_layout',False):self.choice_entry.pack(fill='x', before=self.reference_frame)
        elif not getattr(self,'simple_layout',False):self.expression_entry.pack(fill='x', before=self.reference_frame)
        self.expression_entry.configure(state='normal' if e and self.field and schema.known(e['type']) and self.attribute_section() != 'extra' else 'readonly')
        self.choice_entry.configure(state='normal' if e and self.field else 'disabled')
        if getattr(self,'simple_layout',False):
            available=bool(e and self.field and self.field not in ('NUMB','DESC','PURP','PSKEY','GTYP','LEVEL','OBST','CLFLA','TUFLA','TVISI','BVISI','NAPP') and self.attribute_section()!='extra')
            self.reference_button.configure(state='normal' if available else 'disabled')
            if not available and self.references_open:self.toggle_references()
        self.update_role(); self.update_validation()

    def update_validation(self):
        self.update_expression_caption()
        if not self.field or not self.element(): self.validation_note.configure(text=''); return
        e = self.element(); key = self.field; expr = schema.value(e,key)
        if key == 'NUMB':
            text = 'P0 は自動生成。正の整数で、同じ PTSET 内の番号を重複させません。'
        elif key == 'LEVEL': text = '下限 上限 の 2 整数。描画フラグと REPRESENTATION の設定にも依存します。'
        elif key == 'NAPP':text=''
        elif key in ('TVISI','BVISI','CLFLA','TUFLA'): text='TRUE / FALSE の描画フラグです。'
        elif key in ('PAXI','PAAX','PBAX','PCAX','PLAXI','PTCDIR','PTCPOS','PTSPOS','PTEPOS','PTS','DESC','PURP','PSKEY','GTYP','PKEY'):
            text='原文を保持。基本軸・対応する角度式を計算します。未対応の式は原文保持。' if key in ('PAXI','PAAX','PBAX','PCAX','PLAXI','PTCDIR','PTCPOS','PTSPOS','PTEPOS') else schema.meaning(e['type'],key)
        elif not expr.strip(): text='未設定'+('：実寸評価時は '+schema.evaluation_default(e['type'],key) if schema.evaluation_default(e['type'],key) is not None else '')
        elif key=='PCON' and expr.isidentifier() and expr not in {p['role'] for p in presets.rules(self.data,self.definition())} and expr.upper() not in ('PARAM','PARA','ANGL'):text='固定の接続コード：'+expr
        else:
            try:
                scom=project.get(self.data,'scoms',self.preview_scom_id)
                if scom:presets.require_compatible(self.data,scom,self.definition())
                attributes=dict(self.definition().get('model_settings',{}));attributes.update((scom or {}).get('component_attrs',{}))
                value=expressions.evaluate(expr,expressions.contexts_for(scom or {}),attributes,presets.rules(self.data,self.definition()))
                text='確認結果：' + str(value) + ('（選択 SCOM）' if scom else '（定数）')
            except ValueError as exc: text=str(exc)
        self.validation_note.configure(text=text)

    def display_field_value(self,element,key):
        raw=schema.value(element,key)
        if key in ('PTCPOS','PTSPOS','PTEPOS'):
            import re
            raw=re.sub(r'\bP(?:P\s*)?(\d+)\b',r'PP \1',raw,flags=re.I)
        literal={'NUMB','DESC','PURP','PSKEY','GTYP','SKEY','PKEY','LEVEL','OBST','NAPP','CLFLA','TUFLA','TVISI','BVISI'}
        return raw if getattr(self,'simple_layout',False) or key in literal else presets.display_expression(self.data,self.definition(),raw)

    def parameter_caption(self,key,value):
        from .value_choices import is_point_reference
        element=self.element()
        literal={'NUMB','DESC','PURP','PSKEY','GTYP','SKEY','PKEY','LEVEL','OBST','NAPP','CLFLA','TUFLA','TVISI','BVISI'}
        if not element or not schema.known(element['type']):return ''
        if str(value).strip().lower() in ('','unset'):
            default=schema.evaluation_default(element['type'],key)
            if default is not None:return '未設定：実寸評価時は '+default
        if key=='PSKEY':return 'ISODRAFT の端部記号を追加（標準記号に重ね描き）'
        if key in literal:return ''
        if is_point_reference(key,value):return 'ポイント参照：'+str(value).strip()
        return presets.expression_names(self.data,self.definition(),value)

    def update_expression_caption(self):
        if not getattr(self,'simple_layout',False):return
        element=self.element()
        raw=schema.value(element,self.field) if element and self.field else ''
        text=self.parameter_caption(self.field,raw) if element and self.field and self.attribute_section()!='extra' else ''
        if not text:
            self.expression_caption.configure(text='');self.expression_caption.pack_forget()
        else:
            self.expression_caption.configure(text=text)
            options={'before':self.reference_controls} if self.reference_controls.winfo_manager() else {}
            self.expression_caption.pack_forget()

    def edit_expression(self, *_):
        if self.busy or not self.element() or not self.field or self.attribute_section() == 'extra' or not schema.known(self.element()['type']): return
        value = self.expression.get()
        if self.field == 'OBST': value = schema.OBST_CHOICES.get(value, value)
        self.remember_preview()
        schema.set_value(self.element(), self.field, value)
        self.preview_attribute_changed(self.element(),self.field)
        if self.kind=='PTSET':
            from .point_preview import seed_parameter_position
            seed_parameter_position(self.data,self.definition(),self.element(),self.field)
        self.remember_preview()
        self.tables[self.section].item(self.field, values=(self.field, schema.meaning(self.element()['type'],self.field), self.display_field_value(self.element(),self.field)))
        if self.kind=='PTSET' and self.field=='NUMB':self.elements.item(self.element_id,values=(value,self.element()['name'],self.elements.item(self.element_id,'values')[2]) if getattr(self,'simple_layout',False) else (value,self.element()['type']))
        self.host.mark(); self.update_validation();self.redraw_points();self.draw()

    def rename_element(self, *_):
        if not self.busy and self.element():
            self.element()['name'] = self.element_name.get(); self.elements.item(self.element_id, text=self.element_name.get()); self.host.mark(); self.draw()

    def change_type(self, _=None):
        e = self.element(); kind = self.type_choice.get()
        if not e or kind == e['type']: return
        if not messagebox.askyesno('要素型を変更', '要素型を変更しますか？ 元の属性と型の履歴は保持します。', parent=self.host): self.type_choice.set(e['type']); return
        schema.change_type(e, kind); self.field = None; self.section = 'main'
        self.select_first_section(); self.host.mark(); self.refresh()

    def insert_reference(self):
        e = self.element()
        if not e or not self.field or self.field == 'NUMB' or self.attribute_section() == 'extra' or not schema.known(e['type']): return
        try: number = int(self.ref_number.get())
        except ValueError: self.validation_note.configure(text='参照番号は正の整数を指定してください。'); return
        if number < 1: self.validation_note.configure(text='参照番号は正の整数を指定してください。'); return
        ref = self.ref_kind.get() + '[' + str(number) + ']'
        if getattr(self,'simple_layout',False):
            table=self.tables[self.section]
            if not table.editing and not table.begin_edit(self.field):return
            entry=table.editing['entry'];variable=table.editing['variable']
            try:a,b=entry.index('sel.first'),entry.index('sel.last')
            except tk.TclError:a=b=entry.index('insert')
            text=variable.get();variable.set(text[:a]+ref+text[b:]);table.finish_edit();return
        entry = self.expression_entry if self.expression_entry.winfo_ismapped() else self.choice_entry
        try: a, b = entry.index('sel.first'), entry.index('sel.last')
        except tk.TclError: a = b = entry.index('insert')
        text = self.expression.get(); self.expression.set(text[:a] + ref + text[b:]); entry.focus_set(); entry.icursor(a + len(ref))

    def half(self):
        if not self.commit_inline():return
        if self.element() and schema.known(self.element()['type']) and self.field and self.attribute_section() != 'extra': self.expression.set('(' + self.expression.get() + ') / 2')

    def update_role(self):
        kind = self.ref_kind.get()
        pid = 'P' + self.ref_number.get()
        param = next((p for p in presets.rules(self.data,self.definition()) if p['id']==pid),None) if kind == 'PARAM' else None
        self.role_label.configure(text=kind+' '+self.ref_number.get()+' / '+(presets.caption(param) if param else presets.reference_roles(self.data,self.definition()).get(kind,{}).get(pid,'設定名未登録（参照種類ごとに区別）')))

    def commit_name(self):
        d = self.definition()
        if not d: return
        name = self.def_name.get().strip()
        if name == d['name']: return
        if not name or any(x['id'] != d['id'] and x['name'] == name for x in self.data['definitions']):
            self.host.status.configure(text='定義名が空か重複しています。'); self.def_name.set(d['name']); return
        d['name'] = name; self.host.mark()
        self.definition_names = {x['name']: x['id'] for x in self.data['definitions'] if x['kind'] == self.kind}
        if not getattr(self,'simple_layout',False):self.def_choice['values'] = list(self.definition_names)
        self.def_choice.set(name)
        self.refresh_pairing()

    def create_part(self):
        d=self.definition()
        if not d:return
        self.commit_name()
        if self.kind=='PTSET':self.host.component_from_ptset(d['id'])
        elif self.kind=='GMSET':self.host.component_from_gmset(d['id'])

    def add_definition(self):
        if self.kind in ('PTSET','GMSET'):
            self.host.definition_form(self.kind);return
        def apply(values):
            name=self.host.required(values['name'],'定義名')
            if any(d['name']==name for d in self.data['definitions']):raise ValueError('定義名が重複しています。')
            if len(self.data['definitions'])>=1000:raise ValueError('定義数の上限です。')
            d={'id':uuid.uuid4().hex,'name':name,'kind':self.kind,'revision':'01','elements':[]}
            presets.stamp(self.data,d);self.data['definitions'].append(d);self.host.definition_id=d['id']
        self.host.form(self.kind+' を追加',[('name','定義名','/NEW-'+self.kind,None)],apply)

    def duplicate_definition(self):
        d = self.definition()
        if not d: return
        copied = copy.deepcopy(d); copied['id'] = uuid.uuid4().hex
        names = {x['name'] for x in self.data['definitions']}; name = d['name'] + '-COPY'; n = 1
        while name in names: n += 1; name = d['name'] + '-COPY' + str(n)
        copied['name'] = name
        remap={}
        for e in schema.walk(copied['elements']):
            old=e['id'];e['id']=uuid.uuid4().hex;remap[old]=e['id']
        if copied.get('attrs',{}).get('NAREF') in remap: copied['attrs']['NAREF']=remap[copied['attrs']['NAREF']]
        self.data['definitions'].append(copied); self.definition_id = copied['id']; self.element_id = None
        self.host.mark(); self.refresh()

    def add_element(self):
        if not self.commit_inline():return
        d = self.definition(); selected = self.library.curselection()
        if not d: self.validation_note.configure(text='先に定義を追加してください。'); return
        if not selected: return
        try: e = schema.add_element(d, self.library.get(selected[0]).split()[0])
        except ValueError as exc: messagebox.showerror('追加できません', str(exc), parent=self.host); return
        self.element_id = e['id']; self.select_first_section(); self.field = None
        self.host.mark();self.refresh();self.elements.see(e['id'])
        if getattr(self,'simple_layout',False) and self.creating:self.toggle_create()
        self.host.status.configure(text=e['type']+' を作成しました。右側の属性行を選んで、値・式を入力してください。')

    def duplicate_element(self):
        if not self.commit_inline():return
        e, d = self.element(), self.definition()
        if not e:return
        siblings=self.siblings(e)
        if len(siblings)>=200 or e['type']=='SLOO': self.validation_note.configure(text='輪郭は 1 つ。頂点を追加・複製してください。');return
        self.remember_preview(d)
        copied = copy.deepcopy(e)
        for node in schema.walk([copied]): node['id']=uuid.uuid4().hex
        name = e['name'] + ' コピー'; n = 1
        names = {x['name'] for x in siblings}
        while name in names: n += 1; name = e['name'] + ' コピー ' + str(n)
        copied['name'] = name
        if 'NUMB' in copied['attrs']:
            numbers = [int(x['attrs']['NUMB']) for x in d['elements'] if str(x['attrs'].get('NUMB', '')).isdigit()]
            copied['attrs']['NUMB'] = str(max(numbers + [0]) + 1)
        self.siblings(e).append(copied); self.element_id = copied['id']; self.host.mark(); self.refresh()

    def delete_element(self):
        if not self.commit_inline():return
        ids=set(self.elements.selection())
        if ids and messagebox.askyesno('要素を削除',str(len(ids))+'件の選択要素を削除しますか？ 使用先にも影響します。',parent=self.host):
            self.remember_preview()
            def remove(items):
                items[:]=[n for n in items if n['id'] not in ids]
                for node in items:remove(node.get('children',[]))
            remove(self.definition()['elements']);self.element_id=None;self.host.mark();self.refresh()

    def select_scom(self, _=None):
        self.preview_scom_id = self.scom_names.get(self.scom_choice.get()); self.refresh_values(); self.update_validation()
        self.redraw_points(options=True)
        if hasattr(self,'geometry_view'):
            self.geometry_view.cancel(redraw=False)
            self.geometry_view.mode.set('SCOM 実寸' if self.preview_scom_id else '仮サイズ');self.draw()

    def refresh_values(self):
        s = project.get(self.data, 'scoms', self.preview_scom_id)
        if self.kind=='PTSET' or getattr(self,'simple_layout',False):
            self.values_label.configure(text=presets.label(self.data,s)+' / '+str(len(s['values']))+' 項目を確認に使用' if s else '確認用 SCOM を選択してください。')
            return
        self.values_label.configure(text=('読み取り専用 / ' + s['name'] + '\n'+presets.label(self.data,s)+'\n\n' + '\n'.join(p['id'] + ' ' + presets.caption(p) + '：' + str(s['values'].get(p['id'], '未入力')) + ' ' + p.get('unit', '') for p in presets.rules(self.data,s)[:6])) if s else '確認用 SCOM を選択してください。')

    def open_scom(self):
        s = project.get(self.data, 'scoms', self.preview_scom_id)
        if s: self.host.scom_id = s['id']; self.host.cate_id = s['cate_id']; self.host.switch('catalog')

    def edit_parent(self):
        d=self.definition()
        if not d: return
        keys=schema.PARENT_FIELDS[self.kind]
        if not keys: messagebox.showinfo('親属性','このセットには形状用の固有親属性はありません。',parent=self.host);return
        options={'未設定':''}
        if self.kind == 'PTSSET':
            options.update({e['name']:e['id'] for e in d['elements'] if e['type']=='PLINE'})
            options.update({str(i)+'：'+e['name']:str(i) for i,e in enumerate(d['elements'],1) if e['type']=='PLINE'})
        fields=[]
        for key in keys:
            raw=d.get('attrs',{}).get(key,'')
            if key == 'NAREF':
                if raw and raw not in options.values(): options['指定値：'+str(raw)]=raw
                initial=next((name for name,ident in options.items() if ident==raw),'未設定')
                target,source=schema.neutral_axis(d)
                hint='未指定時：'+(target['name'] if target else '原点・＋Y')+'（明示設定を推奨）' if source in ('origin','fallback') else '名前またはメンバー順番号'
                fields.append((key,schema.DESCRIPTIONS[key]+' / '+hint,initial,list(options)))
            else: fields.append((key,schema.DESCRIPTIONS.get(key,key),raw,None))
        def apply(v):
            d.setdefault('attrs',{}).update({key:options[v[key]] if key=='NAREF' else v[key] for key in keys})
        self.host.form(self.kind+' の親属性',fields,apply)

    def siblings(self,element):
        d=self.definition()
        if element in d['elements']: return d['elements']
        return next(node['children'] for node in schema.walk(d['elements']) if element in node.get('children',[]))

    def add_negative_child(self,kind):
        if not self.commit_inline():return
        e=self.element()
        if not e:return
        try:child=schema.add_child(e,kind)
        except ValueError as exc:self.validation_note.configure(text=str(exc));return
        self.preview_attribute_changed(child,'NAPP')
        self.element_id=child['id'];self.field=None;self.select_first_section();self.host.mark();self.refresh()

    def add_child(self):
        e=self.element()
        if not e: return
        if not schema.child_kind(e['type']):
            menu=tk.Menu(self,tearoff=False)
            for kind in schema.allowed_children(e['type']):menu.add_command(label=kind,command=lambda k=kind:self.add_negative_child(k))
            self.negative_child_menu=menu;menu.tk_popup(self.child_button.winfo_rootx(),self.child_button.winfo_rooty()+self.child_button.winfo_height());return
        try: child=schema.add_child(e)
        except ValueError as exc: self.validation_note.configure(text=str(exc));return
        self.element_id=child['id'];self.field=None;self.select_first_section()
        self.host.mark();self.refresh()

    def move_element(self,delta):
        e=self.element()
        if not e: return
        siblings=self.siblings(e);index=siblings.index(e);target=index+delta
        if 0 <= target < len(siblings):
            from . import element_library
            try:element_library.reorder(self.data,self.definition(),e['id'],target)
            except ValueError as exc:self.host.status.configure(text=str(exc));return
            self.host.mark();self.refresh()

    def normalize_expression(self):
        if not self.commit_inline():return
        e=self.element()
        if not e or not self.field or self.attribute_section() == 'extra': return
        try: value=expressions.normalized(self.expression.get(),presets.rules(self.data,self.definition()))
        except ValueError as exc: self.validation_note.configure(text=str(exc));return
        e.setdefault('expression_sources',{}).setdefault(self.field,self.expression.get())
        self.expression.set(value)

    def edit_sizes(self):
        e=self.element()
        if not e or schema.positive(e['type']) != 'LSNO': self.validation_note.configure(text='LSNO / NLSN を選択してください。');return
        fields=[]
        for face,d,r in (('top','PTDM','PTRA'),('bottom','PBDM','PBRA')):
            fields.extend([(face+'mode',face+' 入力モード','半径' if e['attrs'].get(r) and not e['attrs'].get(d) else '直径',['直径','半径']),
                           (face+'value',face+' 値・式',e['attrs'].get(d) or e['attrs'].get(r,''),None)])
        def apply(v):
            e.setdefault('size_history',[]).append(copy.deepcopy(e['attrs']))
            for face,d,r in (('top','PTDM','PTRA'),('bottom','PBDM','PBRA')):
                radius=v[face+'mode']=='半径';e['attrs'][r if radius else d]=v[face+'value'];e['attrs'][d if radius else r]=''
        self.host.form('LSNO：面ごとの寸法を選択',fields,apply)

    def edit_points(self):
        e=self.element()
        if not e or e['type'] != 'LINE': self.validation_note.configure(text='LINE を選択してください。');return
        values=str(e['attrs'].get('PTS','')).split()
        fields=[(str(i),'点 '+str(i+1)+'（P1 / T2、空欄は省略）',values[i] if i<len(values) else '',None) for i in range(6)]
        def apply(v):
            points=[v[str(i)].upper().strip() for i in range(6) if v[str(i)].strip()]
            import re
            if any(not re.fullmatch(r'[PT]\d+',p) for p in points): raise ValueError('P1 / T2 形式で指定してください。')
            e['attrs']['PTS']=' '.join(points)
        self.host.form('LINE：点の順序',fields,apply)

    def draw(self):
        if hasattr(self,'geometry_view'):
            self.geometry_view.redraw();return
        if self.canvas is None:return
        c = self.canvas; c.delete('all'); w, h = max(c.winfo_width(), 100), max(c.winfo_height(), 120)
        d = self.definition()
        if not d or not d['elements']:
            c.create_text(w/2, h/2, text='要素を追加すると構成を表示します', width=w-25, fill=MUTED); return
        for x in range(0, w, 25): c.create_line(x, 0, x, h, fill='#e6edf6')
        for y in range(0, h, 25): c.create_line(0, y, w, y, fill='#e6edf6')
        items = d['elements'][:6]
        spacing = max(35, min(60, (h-45)/len(items)))
        for i, e in enumerate(items):
            y = 22+i*spacing; chosen = e['id'] == self.element_id
            color = BLUE if chosen else ('#b87c30' if e['type'] in schema.NEGATIVE_BASE else '#8395ad')
            if self.kind == 'PTSET':
                c.create_oval(22, y, 38, y+16, outline=color, fill='#dceafe' if chosen else 'white', width=2)
                c.create_line(38, y+8, 64, y+8, arrow='last', fill=color)
            else: c.create_rectangle(20, y, 55, y+22, outline=color, fill='#dceafe' if chosen else '#e6ecf4', width=2, dash=(3,2) if e['type'] in schema.NEGATIVE_BASE else ())
            c.create_text(70, y+10, text=e['name']+'\n'+e['type'], anchor='w', fill=color, width=max(60,w-90), font=(self.host.ui_font,9))
        c.create_text(w/2, h-12, text='構成のみ表示 / 位置・寸法は未計算', fill=MUTED, font=(self.host.ui_font,9))

    def review(self):
        d = self.definition()
        if not d: return
        win = tk.Toplevel(self.host); win.title('定義の出力確認'); win.transient(self.host)
        ttk.Label(win, text='構成確認用のコメント表示です。E3D 実行用ではありません。', padding=12).pack()
        text = tk.Text(win, width=82, height=25, font=('Consolas',10)); text.pack(fill='both', expand=True, padx=12, pady=8)
        report=copy.deepcopy(self.data);report['definitions']=[d];report['cates']=[];report['scoms']=[];report['specs']=[];report['tables']=[];report['texts']=[]
        lines=project.macro_text(report).splitlines()
        text.insert('1.0','\n'.join(lines)); text.configure(state='disabled')
        ttk.Button(win, text='閉じる', command=win.destroy).pack(pady=8)
