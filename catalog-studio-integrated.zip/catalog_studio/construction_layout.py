"""Elements, permanent preview, and attributes beside the registered browser."""
import tkinter as tk
from tkinter import ttk
from . import element_schema as schema
from .attribute_table import AttributeTable
from .element_list import ElementList
from . import theme


def build_simple(editor):
    e = editor
    e.simple_layout = True
    e.unified_attributes = True
    e.attribute_sections = {}
    e.configure(style='Workspace.TFrame')
    point = e.kind == 'PTSET'
    e.canvas = None
    e.creating = e.settings_open = e.references_open = False

    e.settings_frame = ttk.LabelFrame(e, text='セットの設定・確認', padding=12)
    row = ttk.Frame(e.settings_frame)
    row.pack(fill='x')
    ttk.Label(row, text=e.kind + ' 名').pack(side='left')
    e.def_name = tk.StringVar()
    e.name_entry = ttk.Entry(row, textvariable=e.def_name, width=28)
    e.name_entry.pack(side='left', padx=8)
    e.name_entry.bind('<FocusOut>', lambda _: e.commit_name())
    e.name_entry.bind('<Return>', lambda _: e.commit_name())
    ttk.Button(row, text='PARAM プリセットを管理', command=lambda: e.host.switch('rules')).pack(side='left', padx=8)
    row = ttk.Frame(e.settings_frame)
    row.pack(fill='x', pady=(10, 0))
    if schema.PARENT_FIELDS[e.kind]:
        ttk.Button(row, text='親属性', command=e.edit_parent).pack(side='left')
    ttk.Button(row, text='セットを複製', command=e.duplicate_definition).pack(side='left', padx=6)
    ttk.Button(row, text='出力を確認', command=e.review).pack(side='left')
    e.usage_label = ttk.Label(row, text='', style='Muted.TLabel')
    e.usage_label.pack(side='right')
    row = ttk.Frame(e.settings_frame)
    row.pack(fill='x', pady=(10, 0))
    ttk.Label(row, text='確認用 SCOM').pack(side='left')
    e.scom_choice = ttk.Combobox(row, state='readonly', width=28)
    e.scom_choice.pack(side='left', padx=8)
    e.scom_choice.bind('<<ComboboxSelected>>', e.select_scom)
    ttk.Button(row, text='値・ANGL を開く', command=e.open_scom).pack(side='left')
    e.values_label = ttk.Label(row, text='', style='Muted.TLabel', wraplength=370)
    e.values_label.pack(side='left', padx=12)
    e.element_details = ttk.Label(e.settings_frame, text='', style='Muted.TLabel', wraplength=1000)
    e.element_details.pack(anchor='w', fill='x', pady=(8, 0))
    e.element_details.bind('<Configure>', lambda event: e.element_details.configure(wraplength=max(160, event.width - 8)))

    e.main_split = ttk.Panedwindow(e, orient='horizontal')
    e.main_split.pack(fill='both', expand=True)
    left = ttk.Frame(e.main_split, padding=(10,10),style='Card.TFrame')
    center = ttk.Frame(e.main_split, padding=(12,10),style='Card.TFrame')
    right = ttk.Frame(e.main_split, padding=(10,10),width=390,style='Card.TFrame')
    right.pack_propagate(False)
    e.element_pane,e.preview_pane,e.attribute_pane=left,center,right
    e.reference_bar=ttk.Frame(center)
    e.main_split.add(left, weight=1)
    e.main_split.add(center, weight=4)
    e.main_split.add(right, weight=0)
    e.panes_initialized=False
    def initialize_panes(event):
        if e.panes_initialized or event.width<600:return
        e.panes_initialized=True
        e.main_split.sashpos(0,max(160,min(310,int(event.width*.24))))
        e.main_split.sashpos(1,event.width-396)
    e.main_split.bind('<Configure>',initialize_panes)
    e.def_choice = tk.StringVar()
    e.set_name_label=ttk.Label(left,textvariable=e.def_name,style='Heading.TLabel',wraplength=210)
    e.set_name_label.pack(anchor='w',fill='x',pady=(0,6))
    e.set_name_label.bind('<Configure>',lambda event:e.set_name_label.configure(wraplength=max(120,event.width-4)))
    row=ttk.Frame(left);row.pack(fill='x',pady=(0,6))
    from .project_actions import icon,Hint
    if not getattr(e.host,'is_preset_editor',False):
        from .element_presets_ui import select_ptset_preset
        # Compatibility controller only; selection is exposed through the recall button.
        e.element_preset_choice=ttk.Combobox(row,state='readonly',width=12)
        e.element_preset_choice.bind('<<ComboboxSelected>>',lambda event:select_ptset_preset(e))
    e.element_action_icons={k:icon(e,k,color=theme.ACCENT) for k in ('new','recall','save')}
    e.add_button=ttk.Button(row,text='要素を追加',image=e.element_action_icons['new'],command=e.toggle_create,style='AttributeTool.TButton')
    e.add_button.pack(side='left',padx=(0,4));e.add_button.hint=Hint(e.add_button,'要素を追加')
    if not getattr(e.host,'is_preset_editor',False):
        from . import element_presets_ui
        e.recall_preset_button=ttk.Button(row,text='プリセット呼出',image=e.element_action_icons['recall'],style='AttributeTool.TButton',command=lambda:element_presets_ui.choose(e,'recall'))
        e.recall_preset_button.pack(side='left',padx=(0,4));e.recall_preset_button.hint=Hint(e.recall_preset_button,'プリセット呼出')
        e.register_preset_button=ttk.Button(row,text='現在を登録',image=e.element_action_icons['save'],style='AttributeTool.TButton',command=lambda:element_presets_ui.register_current(e))
        e.register_preset_button.pack(side='left');e.register_preset_button.hint=Hint(e.register_preset_button,'現在をプリセットに登録')

    e.creation_frame=tk.Toplevel(e)
    e.creation_frame.withdraw();e.creation_frame.title('ポイントを追加' if point else '形状を追加')
    e.creation_frame.geometry('960x720' if e.kind=='GMSET' else '980x600');e.creation_frame.minsize(920,680) if e.kind=='GMSET' else e.creation_frame.minsize(940,580)
    e.creation_frame.transient(e.winfo_toplevel())
    e.creation_frame.protocol('WM_DELETE_WINDOW',lambda:e.toggle_create() if e.creating else e.creation_frame.withdraw())
    creation=ttk.Frame(e.creation_frame,padding=16);creation.pack(fill='both',expand=True)
    ttk.Label(creation,text='種類を選んで作成',style='Heading.TLabel').pack(anchor='w',pady=(0,12))
    e.negative = tk.BooleanVar(value=False)
    if not point and e.kind!='GMSET':
        ttk.Checkbutton(creation, text='ネガティブ形状', variable=e.negative, command=e.populate_library).pack(anchor='w', pady=(0, 6))
    holder = ttk.Frame(creation)
    holder.pack(fill='both',expand=True)
    list_side=ttk.Frame(holder,width=340);list_side.pack(side='left',fill='both',padx=(0,16));list_side.pack_propagate(False)
    diagram_side=ttk.Frame(holder);diagram_side.pack(side='left',fill='both',expand=True)
    e.guide_canvas=tk.Canvas(diagram_side,height=270,background='#f5f8fc',highlightthickness=1,highlightbackground='#d7e1ed')
    e.guide_canvas.pack(fill='both',expand=True)
    from . import element_guide
    e.guide_canvas.bind('<Configure>',lambda _:element_guide.draw(e))
    e.guide_angles=(-40.,30.);e.guide_wire=True;e.guide_drag=None
    def guide_press(event):e.guide_drag=(event.x,event.y,*e.guide_angles);e.guide_canvas.focus_set()
    def guide_move(event):
        if e.guide_drag:
            x,y,a,b=e.guide_drag;e.guide_angles=(a+(event.x-x)*.5,max(-85,min(85,b+(event.y-y)*.5)));element_guide.draw(e)
    def guide_toggle(event=None):e.guide_wire=not e.guide_wire;element_guide.draw(e);return 'break'
    e.guide_canvas.bind('<Button-2>',guide_press);e.guide_canvas.bind('<B2-Motion>',guide_move)
    e.guide_canvas.bind('<ButtonRelease-2>',lambda event:setattr(e,'guide_drag',None))
    e.guide_canvas.bind('<F11>',guide_toggle)
    ttk.Button(diagram_side,text='ワイヤー／ソリッド (F11)',command=guide_toggle,style='AttributeTool.TButton').pack(fill='x',pady=4)

    def make_library(parent):
        from .shape_library import ShapeLibrary
        result=ShapeLibrary(parent,e.host.ui_font)
        result.pack(side='left',fill='both',expand=True)
        result.bind('<<ListboxSelect>>',e.describe_selected_type)
        return result
    if e.kind=='GMSET':
        # Native notebook tabs can expand on selection. Use a fixed-size tab
        # strip and keep the notebook only as the page container.
        style=ttk.Style(e);style.layout('ShapePages.TNotebook.Tab',[])
        strip=ttk.Frame(list_side);strip.pack(fill='x',pady=(0,4))
        strip.columnconfigure((0,1),weight=1,uniform='shape-tabs')
        e.shape_tab_value=tk.IntVar(value=0);e.shape_tab_buttons=[]
        e.shape_tabs=ttk.Notebook(list_side,style='ShapePages.TNotebook',takefocus=False);e.shape_tabs.pack(fill='both',expand=True)
        for index,label in enumerate(('通常形状','ネガティヴ形状')):
            button=ttk.Radiobutton(strip,text=label,variable=e.shape_tab_value,value=index,style='Preview.Toolbutton',command=lambda i=index:e.shape_tabs.select(i))
            button.grid(row=0,column=index,sticky='nsew',padx=(0,3) if index==0 else (3,0))
            e.shape_tab_buttons.append(button)
        e.shape_libraries=[]
        for label in ('通常形状','ネガティヴ形状'):
            tab=ttk.Frame(e.shape_tabs,padding=(0,6,0,0));e.shape_tabs.add(tab,text=label)
            e.shape_libraries.append(make_library(tab))
        e.library=e.shape_libraries[0]
        def change_shape_tab(_=None):
            index=e.shape_tabs.index(e.shape_tabs.select())
            e.shape_tab_value.set(index)
            e.negative.set(index==1);e.library=e.shape_libraries[index];e.populate_library()
        e.shape_tabs.bind('<<NotebookTabChanged>>',change_shape_tab)
    else:
        e.library=make_library(list_side)
        scroll=ttk.Scrollbar(list_side,command=e.library.yview);scroll.pack(side='right',fill='y')
        e.library.configure(yscrollcommand=scroll.set)
    e.type_help = ttk.Label(diagram_side, text='', wraplength=440, justify='left', style='Muted.TLabel')
    e.type_help.pack(fill='x', pady=10)
    e.creation_frame.bind('<Configure>', lambda event: e.type_help.configure(wraplength=max(140,event.width-320)) if event.widget is e.creation_frame else None)
    e.library.bind('<<ListboxSelect>>', e.describe_selected_type)
    actions=ttk.Frame(creation);actions.pack(fill='x',pady=(6,0))
    e.create_element_button = ttk.Button(actions, text='作成', command=e.add_element, style='Primary.TButton',width=12)
    e.create_element_button.pack(side='right')
    e.cancel_creation_button=ttk.Button(actions,text='キャンセル',width=9,command=lambda:e.toggle_create() if e.creating else None)
    e.cancel_creation_button.pack(side='right',padx=(0,6))
    e.populate_library()

    e.tree_holder = ttk.Frame(left)
    e.tree_holder.pack(fill='both', expand=True)
    e.elements = ElementList(e.tree_holder,e.host.ui_font,e.element_name_context)
    e.elements.grid(row=0, column=0, sticky='nsew')
    scroll = ttk.Scrollbar(e.tree_holder, command=e.elements.yview)
    scroll.grid(row=0, column=1, sticky='ns')
    e.elements.configure(yscrollcommand=scroll.set)
    e.tree_holder.rowconfigure(0, weight=1)
    e.tree_holder.columnconfigure(0, weight=1)
    e.elements.bind('<<TreeviewSelect>>', e.select_element)
    row = ttk.Frame(left)
    row.pack(side='bottom', fill='x', pady=(8, 0), before=e.tree_holder)
    from .construction_actions import context_menu,enable_drag
    context_menu(e);enable_drag(e)
    e.elements.bind('<Delete>',lambda event:e.delete_element())
    e.child_button = ttk.Button(row, text='子要素を追加', command=e.add_child,style='AttributeTool.TButton')
    if point:
        ttk.Label(row, text='P0：自動生成', style='Muted.TLabel').pack(side='right')

    preset_row=ttk.Frame(right);preset_row.pack(fill='x',pady=(0,6))
    e.preset_choice = ttk.Combobox(preset_row, state='readonly')
    e.preset_choice.pack(side='left',fill='x',expand=True)
    e.preset_choice.bind('<<ComboboxSelected>>', e.assign_preset)
    def optional():
        if not e.commit_inline():return
        e.show_optional_attrs=not getattr(e,'show_optional_attrs',False)
        e.optional_attrs_button.configure(text=('▲' if e.show_optional_attrs else '▼'))
        e.refresh_element()
    e.optional_attrs_button=ttk.Button(preset_row,text='▼',width=2,command=optional,style='AttributeTool.TButton')
    e.optional_attrs_button.pack(side='right',padx=(4,0))
    e.optional_attrs_button.hint=Hint(e.optional_attrs_button,('DESC・PURP' if point else 'DESC・GTYP・PURP')+'を表示／非表示')

    e.element_name = tk.StringVar()
    e.type_choice = tk.StringVar()
    e.element_note = ttk.Label(right, text='', style='Muted.TLabel', wraplength=740)
    e.element_note.bind('<Configure>',lambda event:e.element_note.configure(wraplength=max(160,event.width-4)))

    e.multi_notice=ttk.Label(right,text='複数選択中のため、属性の表示・編集はできません。',style='Muted.TLabel',wraplength=330)
    e.tabs = ttk.Frame(right)
    e.tabs.pack(fill='both', expand=True)
    e.tables = {}
    e.tab_frames = {}
    e.section_order = ['main']
    table = AttributeTable(e.tabs,e.host.ui_font,lambda attr,value:e.parameter_caption(attr,value) if e.attribute_section(attr)!='extra' else '',lambda attr:e.inline_context(attr,e.attribute_section(attr)),lambda attr:attr in schema.missing_fields(e.element()))
    from .value_editor import open_editor
    table.editor_factory=lambda table,key,context:open_editor(e,table,key,context)
    table.pack(fill='both',expand=True)
    table.bind('<<TreeviewSelect>>',lambda event:e.select_field('main'))
    table.bind('<Double-1>',lambda _:e.focus_value_input())
    table.bind('<Return>',lambda _:e.focus_value_input())
    e.tables['main'] = table

    box = ttk.Frame(right, padding=(0, 14, 0, 0))
    # Legacy controller variables remain available, while input lives in a dialog.
    row = ttk.Frame(box)
    row.pack(fill='x', pady=(0, 8))
    caption=ttk.Frame(row)
    e.field_label = ttk.Label(caption, text='', style='Heading.TLabel')
    e.field_label.pack(anchor='w')
    e.field_meaning=ttk.Label(caption,text='',style='AttributeMeaning.TLabel')
    e.field_meaning.pack(anchor='w',fill='x')
    e.reference_button = ttk.Button(row, text='PARAM を選ぶ…', command=e.toggle_references)
    e.reference_button.pack(side='right')
    def wrap_caption(event):
        width=max(100,event.width-e.reference_button.winfo_reqwidth()-12)
        e.field_label.configure(wraplength=width);e.field_meaning.configure(wraplength=width)
    row.bind('<Configure>',wrap_caption)
    e.expression = tk.StringVar()
    e.expression.trace_add('write', e.edit_expression)
    e.expression_entry = ttk.Entry(box, textvariable=e.expression, font=(e.host.ui_font, 13))
    e.choice_entry = ttk.Combobox(box, textvariable=e.expression, state='normal')
    e.reference_frame = ttk.Frame(box)
    e.reference_frame.pack(fill='x', pady=(6, 0))
    e.expression_caption = ttk.Label(e.reference_frame, text='', style='AttributeMeaning.TLabel', wraplength=710)
    e.expression_caption.bind('<Configure>', lambda event: e.expression_caption.configure(wraplength=max(160, event.width - 8)))
    e.reference_controls = ttk.Frame(e.reference_frame)
    row = ttk.Frame(e.reference_controls)
    row.pack(fill='x')
    e.ref_kind = ttk.Combobox(row, values=schema.REFERENCE_TYPES, state='readonly', width=14)
    e.ref_kind.set('PARAM')
    e.ref_kind.pack(side='left')
    e.ref_kind.bind('<<ComboboxSelected>>', lambda _: e.update_role())
    e.ref_number = tk.StringVar(value='1')
    e.number_entry = ttk.Spinbox(row, from_=1, to=999, width=5, textvariable=e.ref_number)
    e.number_entry.pack(side='left', padx=6)
    e.ref_number.trace_add('write', lambda *_: e.update_role())
    ttk.Button(row,text='挿入',command=e.insert_reference,style='Compact.TButton').pack(side='left',padx=3)
    row=ttk.Frame(e.reference_controls);row.pack(fill='x',pady=(4,0))
    for label, command in [('÷ 2', e.half), ('式を整理', e.normalize_expression)]:
        ttk.Button(row, text=label, command=command,style='Compact.TButton').pack(side='left', padx=3)
    e.role_label = ttk.Label(e.reference_controls, text='', style='Muted.TLabel', wraplength=710)
    e.role_label.pack(anchor='w', fill='x', pady=(6, 0))
    e.role_label.bind('<Configure>', lambda event: e.role_label.configure(wraplength=max(160, event.width - 8)))
    footer=ttk.Frame(right);footer.pack(side='bottom',fill='x',before=e.tabs,pady=(6,0))
    e.context_helpers = ttk.Frame(footer)
    e.context_helpers.pack(fill='x')
    e.helper_buttons = [(ttk.Button(e.context_helpers, text=label, command=command), match) for label, command, match in [('NAPP 適用先', e.edit_napp, 'negative'), ('直径／半径', e.edit_sizes, 'LSNO'), ('LINE の点列', e.edit_points, 'LINE')]]
    e.validation_note = ttk.Label(footer, text='', foreground='#bb6440', wraplength=710)
    e.validation_note.pack(anchor='w', pady=(4, 0))
    e.validation_note.bind('<Configure>',lambda event:e.validation_note.configure(wraplength=max(160,event.width-4)))

    if point:
        from .point_canvas import PointCanvas
        e.point_canvas=PointCanvas(e,center)
        e.point_canvas.pack(fill='both',expand=True)
    else:
        if not getattr(e.host,'is_preset_editor',False):
            e.reference_bar.pack(side='bottom',fill='x',pady=(8,0))
            e.reference_bar.columnconfigure((0,1),weight=1,uniform='references')
            pair_row=ttk.Frame(e.reference_bar);pair_row.grid(row=0,column=0,sticky='ew',padx=(0,10))
            ttk.Label(pair_row,text='適用PTSET',style='Muted.TLabel').pack(side='left',padx=(0,8))
            e.ptset_choice=ttk.Combobox(pair_row,state='readonly',width=8);e.ptset_choice.pack(side='left',fill='x',expand=True)
            e.ptset_choice.bind('<<ComboboxSelected>>',e.assign_ptset)
            e.pairing_note=ttk.Label(center,text='',style='AttributeMeaning.TLabel')
        from .geometry_canvas import GeometryCanvas
        e.geometry_view=GeometryCanvas(e,center)
        e.geometry_view.pack(fill='both',expand=True)
        e.canvas=e.geometry_view.canvas
