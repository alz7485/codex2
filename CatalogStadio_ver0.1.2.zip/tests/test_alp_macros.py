import copy
import tempfile
import unittest
from pathlib import Path
from catalog_studio import macro_import as mi, macro_export as me, expressions, project

SAMPLE = Path(__file__).resolve().parents[1]/'examples'/'alp-creation-sample.mac'


class AlpMacroTests(unittest.TestCase):
    def test_ptaxis_point_numbers_connections_distance_formula_and_locks(self):
        source = '''INPUT BEGIN
NEW PTSET /DEMO-ALP-POINTS
NEW PTAXIS
NUMB 4
PCON PARAM 8
PBOR PARAM 3
PDIS 0
PAXI Y
END
NEW PTAXIS
NUMB 7
PCON PARAM 9
PBOR PARAM 3
PDIS ( ATTRIB PARA[4 ] + 2 + 3 + ATTRIB DESP[1 ] )
PAXI -Y
END
END
OLD PTSET /DEMO-ALP-POINTS
LOCK
OLD PTAXIS 1 of PTSET /DEMO-ALP-POINTS
LOCK
OLD PTAXIS 2 of PTSET /DEMO-ALP-POINTS
LOCK
INPUT END PTSET /DEMO-ALP-POINTS
INPUT FINISH'''
        original = mi.parse(source).definitions[0]
        self.assertEqual([e['type'] for e in original['elements']], ['PTAXI', 'PTAXI'])
        self.assertEqual([e['attrs']['NUMB'] for e in original['elements']], ['4', '7'])
        output = me.creation_text([original], lock_created=True)
        self.assertEqual(output.count('NEW PTAXIS'), 2)
        self.assertNotIn('OLD ', output)
        self.assertEqual(output.splitlines().count('LOCK'), 3)
        self.assertNotIn('OLD PTAXIS 7 OF', output)
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'points.mac'; me.save(path, output)
            text, _ = mi.read_text(path)
            result = mi.parse(text).definitions[0]
        for old, new in zip(original['elements'], result['elements']):
            from tests.macro_assertions import assert_attrs_equivalent
            assert_attrs_equivalent(self,old['attrs'],new['attrs'],old['type'])
            self.assertTrue(new['macro_locked'])
        attrs = result['elements'][1]['attrs']
        contexts = {'PARAM': {'P3': 65, 'P4': 80, 'P9': 'BWD'}, 'DES PARAM': {'P1': 10}}
        self.assertEqual(expressions.evaluate(attrs['PCON'], contexts), 'BWD')
        self.assertEqual(expressions.evaluate(attrs['PBOR'], contexts), 65)
        self.assertEqual(expressions.evaluate(attrs['PDIS'], contexts), 95)

    def test_observed_aliases_and_raw_expression_values(self):
        gm = mi.parse(SAMPLE.read_text()).definitions[0]
        self.assertEqual([e['type'] for e in gm['elements']], ['SCYL', 'SSPH', 'LINE', 'LSNO'])
        self.assertEqual(gm['elements'][2]['attrs']['PTS'], 'P1 P3')
        self.assertEqual(gm['elements'][0]['attrs']['PDIA'], 'SUM PARAM 2 IPARAM 1')
        self.assertEqual(gm['elements'][3]['attrs']['PTDI'], '( ATTRIB PARA[4 ] + 2 + ATTRIB DESP[1 ] )')
        self.assertEqual(gm['elements'][0]['attrs']['NAPP'], '0')
        self.assertTrue(all(r['macro_locked'] for r in [gm]+gm['elements']))
        contexts={'PARAM':{'P2':40,'P4':30},'IPARAM':{'P1':10},'DES PARAM':{'P1':5}}
        self.assertEqual(expressions.evaluate(gm['elements'][0]['attrs']['PDIA'], contexts), 50)
        self.assertEqual(expressions.evaluate(gm['elements'][1]['attrs']['PDIA'], contexts), 10)
        self.assertEqual(expressions.evaluate(gm['elements'][3]['attrs']['PTDI'], contexts), 37)

    def test_export_compact_macro_and_sjis_round_trip(self):
        records = mi.parse(SAMPLE.read_text()).definitions
        before=copy.deepcopy(records)
        source=me.creation_text(records, lock_created=True)
        self.assertTrue(source.startswith('NEW GMSET /DEMO-ALP-SHAPES\n'))
        self.assertNotIn('INPUT ', source)
        self.assertIn('NEW SCYLINDER',source);self.assertIn('NEW LSNOUT',source)
        self.assertIn('SETP P1 P3',source);self.assertIn('CLFL true',source)
        self.assertNotIn('OLD ', source)
        self.assertEqual(source.splitlines().count('LOCK'), 5)
        self.assertTrue(source.endswith('LOCK\nEND\n'))
        self.assertEqual(records,before)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'alp.mac';me.save(path,source)
            decoded,_=mi.read_text(path)
            imported=mi.parse(decoded).definitions[0]
        for old,new in zip(records[0]['elements'],imported['elements']):
            from tests.macro_assertions import assert_attrs_equivalent
            assert_attrs_equivalent(self,old['attrs'],new['attrs'],old['type']);self.assertTrue(new['macro_locked'])

    def test_nested_type_ordinals_and_unlocked_elements(self):
        source='''INPUT BEGIN
NEW GMSET /NESTED
NEW SCYLINDER
PHEI 12
END
NEW SSPHERE
PDIA 8
END
NEW SCYLINDER
NEW NSCY
PHEI 2
END
END
END
OLD SCYLINDER 2 OF GMSET /NESTED
LOCK
OLD NSCY 1 OF SCYLINDER 2 OF GMSET /NESTED
LOCK
INPUT END GMSET /NESTED
INPUT FINISH'''
        gm=mi.parse(source).definitions[0]
        self.assertFalse(gm['macro_locked']);self.assertFalse(gm['elements'][0]['macro_locked'])
        self.assertTrue(gm['elements'][2]['macro_locked'])
        exported=me.creation_text([gm])
        self.assertNotIn('OLD SCYLINDER 1 OF GMSET',exported)
        self.assertNotIn('LOCK', exported)
        self.assertTrue(gm['elements'][2]['macro_locked'])
        self.assertFalse(mi.parse(exported).definitions[0].get('macro_locked', False))

    def test_rename_import_and_project_reload_keep_locks(self):
        data=project.sample();parsed=mi.parse(SAMPLE.read_text())
        data['definitions'].append(copy.deepcopy(parsed.definitions[0]))
        candidate,added,renamed=mi.prepare_import(data,parsed,[parsed.definitions[0]['id']])
        self.assertTrue(renamed)
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'project.json';project.save(candidate,path);loaded=project.load(path)
        record=next(d for d in loaded['definitions'] if d['id']==added[0]['id'])
        exported=me.creation_text([record]);mi.parse(exported)
        self.assertIn('NEW GMSET '+record['name']+'\n',exported)
        self.assertTrue(record['macro_locked'])
        self.assertNotIn('OLD GMSET /DEMO-ALP-SHAPES\n',exported)

    def test_reject_invalid_envelopes_external_targets_and_commands(self):
        base=SAMPLE.read_text()
        cases=[base.replace('INPUT BEGIN','INPUT BEGIN\nINPUT BEGIN',1),
               base.replace('INPUT END GMSET /DEMO-ALP-SHAPES','INPUT END GMSET /OTHER'),
               base.replace('OLD LINE 1 OF GMSET','OLD LINE 2 OF GMSET'),
               base.replace('OLD GMSET /DEMO-ALP-SHAPES','OLD GMSET /EXTERNAL'),
               base.replace('OLD GMSET /DEMO-ALP-SHAPES\n',''),
               base.replace('INPUT FINISH',''),base.replace('INPUT END GMSET /DEMO-ALP-SHAPES',''),
               base+'\nNEW GMSET /AFTER',base.replace('LOCK','DELETE ALL',1),
               'INPUT FINISH','OLD GMSET /EXTERNAL\nLOCK',
               base.replace('NEW GMSET /DEMO-ALP-SHAPES','NEW GMSET /DEMO-ALP-SHAPES\nNEW GMSET /SECOND')]
        for source in cases:
            with self.subTest(source=source[:100]),self.assertRaises(ValueError):mi.parse(source)

    def test_multi_set_output_omits_envelopes_and_automatic_locks(self):
        records=mi.parse('NEW PTSET /POINTS\nNEW PTAXI\nNUMB 1\nEND\nEND\nNEW GMSET /SHAPES\nNEW SCYL\nPAXI P1\nEND\nEND').definitions
        output=me.creation_text(records)
        self.assertNotIn('INPUT ', output)
        self.assertNotIn('LOCK', output)
        self.assertNotIn('OLD ', output)
        parsed=mi.parse(output).definitions
        self.assertEqual(len(parsed),2)
        self.assertTrue(all(not r.get('macro_locked', False) for r in parsed))
