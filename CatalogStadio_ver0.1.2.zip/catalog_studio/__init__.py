"""Catalog Studio desktop mockup."""
