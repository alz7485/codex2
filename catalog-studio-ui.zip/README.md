# Catalog Studio — E3D カタログ編集ツールのたたき台

Python / Tkinter で、CATE・SCOM、ポイント・形状定義、SPEC、説明・材質、共通テーブル、PDF カタログ本を管理するデスクトップツールです。SCOM に部品ごとの数値・文字列を登録し、定義側ではパラメータ参照と式を編集します。

[最新版 ZIP をダウンロード](https://github.com/alz7485/codex2/raw/refs/heads/main/catalog-studio-integrated.zip)

## 起動

Python 3.10 以降と Tkinter が必要です。Windows は Tcl/Tk を含む公式 Python を使ってください。

```sh
python main.py
```

Windows は `start.bat` でも起動できます。PDF 出力を使う場合は次を実行します。

```sh
python -m pip install -r requirements.txt
```

Windows 用 `install.bat` も同梱しています。Linux のシステム Python は `python3-tk` が必要な場合があります。

## 今回反映した操作

- **PTSET**：PTAXI・PTCAR・PTMIX・PTPOS の属性編集。PTCD と PTCDIR は表示を統一し、保存時は元の属性名を維持。セットの DESC・GTYP・SKEY・PURP は「親属性」から設定。P0 は自動生成される編集不可の基準点として案内します。PSKEY・DESC・PURP は詳細タブで新規値 unset。
- **GMSET / NGMSET**：18 種の正形状・15 種の負形状を日本語説明と併記。固有属性・共通属性・追加属性を分けて表示します。同名の属性も要素ごとに意味を表示します。
- **NAPP**：「NAPP 適用先」で Attached / Owner / Self を選択。1・2・4 の組み合わせで 0〜7 を保存し、6 なども扱えます。実際の対象は設計側の文脈に依存します。以前の仮項目 PJOI などは新規属性から除き、既存データの追加属性として保持します。
- **共通属性**：LEVEL は下限・上限、CLFLA・TUFLA・TVISI・BVISI は TRUE / FALSE、OBST は 0 対象外／1 ソフト／2 ハード。描画フラグだけで実機の表示状態が決まるとは扱いません。
- **輪郭**：SEXT / SREV → SLOO → SVER、SPRO → SPVE の子要素を追加し、↑↓で順番を変更。頂点の PRAD、構造断面の差分属性を編集できます。以前の親 PRAD は削除せず追加属性で保持します。
- **寸法モード**：LSNO / NLSN は上面・底面ごとに直径または半径を選択。変更前の値は履歴に残します。
- **LINE**：「LINE の点列」で P / T の順序付き参照を最大6個編集。SLINE は始点・終点の位置式を保持します。
- **構造材**：PTSSET / PLINE の基準線と NAREF、GMSSET の SREC・SANN・SPRO を管理。P 系は開始側、D 系は終端までの差として説明します。
- **説明・材質**：SDTE / SMTE を独立レコードで管理。SPEC の登録行で SCOM・SDTE・SMTE を別々に参照できます。SDTE は「ISODRAFT 用」を選んだ場合だけ RTEX と4文字 SKEY の不足を確認します。
- **共通テーブル**：接続コードの組、説明、ボルト関連、標準長さ、公称径・分岐表のレコードと親階層を管理。未確定の属性は「属性 JSON」で保持できます。BTHK はボルト長さ、NUMBER は穴番号として表示します。

![GMSET 編集画面](docs/gmset-create.png)

![輪郭・頂点の編集](docs/outline-create.png)

## PARAM プリセットと式

日本語説明は全コンポーネント共通の規則にせず、登録時期やコンポーネントごとにプリセットとして管理します。

1. 「PARAM プリセット」で、プリセットを追加・複製し、名前・登録時期・対象コンポーネント・適用範囲を登録。
2. プリセット内の番号ごとに、表示名・式用の役割名、日本語説明、単位、値型（number / word）を編集。
3. PTSET／GMSET 作成画面の「PARAM プリセット」で、その定義の規則を選択。
4. カタログ画面の「PARAM プリセットを割り当て」で、各 SCOM の規則を選択。

管理画面で選択したプリセットは新規作成用です。選択するだけでは既存 SCOM や定義の割り当てを変更しません。過去の規則を残す場合は複製して新規用を作成します。使用中のプリセットは削除できません。プリセットの編集は、そのプリセットを使うデータだけへ反映します。

番号と SCOM の登録値を自動で入れ替えたり、単位を変換したりしません。定義に別のプリセットを割り当てる際は、役割名の式を元の番号表記に置き換えて、同名の説明による誤解釈を防ぎます。割り当て前の式は履歴に残ります。SCOM と定義の規則が異なる場合は不一致を表示し、計算を止めます。

SCOM 編集・参照の説明表示・貼り付け・確認には、各レコードに割り当てたプリセットを使います。同じ CATE に複数の規則を混在させられます。旧データの規則は「既存規則（従来データ）」として扱い、明示的に割り当てるまで保持します。プリセットはプロジェクト JSON に保存します。

PARAM / IPARAM / APARAM / OPARAM / DES PARAM / DES APARAM / DES OPARAM を区別します。「参照種類別の役割」もプリセットごとに管理できます。PARAM の値は確認用 SCOM から読み取り、他の種類は「確認用の参照コンテキスト」で明示的に与えます。他の種類へ SCOM の値を自動流用しません。

![PARAM プリセット管理](docs/parameter-presets.png)

[プリセットの混在サンプル JSON](examples/parameter-presets-sample.json)と[サンプル PDF](examples/parameter-presets-book.pdf)を同梱しています。サンプルは架空の説明で、AVEVA の標準パラメータ規則を示すものではありません。

四則演算・括弧・役割名・番号、PARAM 系の複数表記、ATTRIB、SUM、TIMES、TAN に対応。「式を読みやすく整理」で画面用表記へ統一し、整理前の入力も保持します。ANGL は SCOM のコンポーネント属性として度で設定します。数値演算に文字列を使用した場合や、参照値が不足する場合は理由を表示します。

式評価には Python の eval を使いません。複合方向・位置式は原文保持のみです。XYZ を基本とし、E/W/U/D も保持できます。

## 保存と PDF

Ctrl+S で JSON 保存、Ctrl+O で読み込み。旧 v1 データは数値を SCOM へ移して読み込み、既存 v2 の追加属性や未対応要素も保持します。拡張データの編集には最新版を使用してください。

「カタログ本・PDF」で掲載する SCOM と SPEC を選ぶと、参照先の定義・輪郭・構造材・テキスト、SCOM の値と確認用コンテキスト、参照種類の役割・使用した PARAM プリセットを発行時点で固定します。共通テーブルはプロジェクト全体を固定します。以後の編集で発行済みの内容は変わりません。PDF に表と式・属性の役割を掲載し、SCOM の寸法表はプリセットごとに分けます。発行後の説明編集も冊子へ影響しません。

[新しいサンプル JSON](examples/catalogue-rules-sample.json)を「読み込み」から開くと、今回の機能を試せます。すべて架空の自作データです。[サンプル PDF](examples/catalogue-rules-book.pdf)も同梱しています。起動時には以前の参考データを表示し、新しい PTSET / GMSET は未連携の編集例として追加しています。

## 現段階の範囲

画面の構成プレビューは寸法・方向を反映しない模式図です。正式要素の正確な CAD 表示、設計側の Attached / Owner の自動解決、実機出力ファイルの解析、PMSET、実行用カタログ・SPEC マクロは未実装です。「構成確認出力」の `.mac` は全行コメントです。画面用の式整理は実機コマンドへの変換ではありません。

NSRU の固有属性、複合方向・位置式の詳細、SDSH の PDIS 基準面、公称径・分岐表の一部の階層名は確認待ちとして扱います。接続の自動反転やボルト長さ計算も未実装です。正確な実機動作は作成例で確認してから追加します。

提供されたマニュアル写真、ページの転載、原図はリポジトリ・ZIP・PDF に含めません。画面画像と掲載データはツールで作成したサンプルです。

## Windows onedir EXE 化

`build_onedir.bat` と [手動ビルド手順](BUILD_ONEDIR.md)を同梱しています。Windows でビルド後、`dist\CatalogStudio\CatalogStudio.exe` を起動します。配布にはフォルダー全体が必要です。Windows EXE 自体は未ビルド・未同梱です。

## 開発・検証

```sh
python -m pip install -r requirements.txt pypdf
python -m unittest discover -s tests -v
```

GUI は表示環境、PDF 内容の検証は pypdf が必要です。クラウドの仮想ディスプレイで、GUI・PDF を含む77件を検証しています。Windows 実機は未確認です。
